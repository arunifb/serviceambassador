package technician.ifb.com.ifptecnician.stock;

public class StockModel {


    String Component,ComponentDescription,FGDescription,FGProduct,FrCodes,MaterialCategory,good_stock,refurbished_stock;

    public String getComponent() {
        return Component;
    }

    public String getComponentDescription() {
        return ComponentDescription;
    }

    public String getFGDescription() {
        return FGDescription;
    }

    public String getFGProduct() {
        return FGProduct;
    }

    public String getFrCodes() {
        return FrCodes;
    }

    public String getMaterialCategory() {
        return MaterialCategory;
    }

    public String getGood_stock() {
        return good_stock;
    }

    public String getRefurbished_stock() {
        return refurbished_stock;
    }
}
