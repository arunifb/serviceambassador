package technician.ifb.com.ifptecnician.fragment.dummy;

public class OfflineModel {

    private String  RefId,TicketNo,Branch,Franchise,CallType,Status,Product,Model,SerialNo,MachinStatus,DOP,DOI,
            PendingReason,CallBookDate,AssignDate,ClosedDate,CancelledDate,ChangeDate,TechnicianCode,
            TechName,CustomerCode,CustomerName,PinCode,TelePhone,RCNNo,MobileNo,Street,City,State,
            Address,ServiceType,Email,Priority,Quantity,scheduledate,FromDate,Todate,Ageing,odu_ser_no,
            FGCode,ProblemDescription,Additive,AdditiveDesc;

    public String getRefId() {
        return RefId;
    }

    public void setRefId(String refId) {
        RefId = refId;
    }

    public String getTicketNo() {
        return TicketNo;
    }

    public void setTicketNo(String ticketNo) {
        TicketNo = ticketNo;
    }

    public String getBranch() {
        return Branch;
    }

    public void setBranch(String branch) {
        Branch = branch;
    }

    public String getFranchise() {
        return Franchise;
    }

    public void setFranchise(String franchise) {
        Franchise = franchise;
    }

    public String getCallType() {
        return CallType;
    }

    public void setCallType(String callType) {
        CallType = callType;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public String getProduct() {
        return Product;
    }

    public void setProduct(String product) {
        Product = product;
    }

    public String getModel() {
        return Model;
    }

    public void setModel(String model) {
        Model = model;
    }

    public String getSerialNo() {
        return SerialNo;
    }

    public void setSerialNo(String serialNo) {
        SerialNo = serialNo;
    }

    public String getMachinStatus() {
        return MachinStatus;
    }

    public void setMachinStatus(String machinStatus) {
        MachinStatus = machinStatus;
    }

    public String getDOP() {
        return DOP;
    }

    public void setDOP(String DOP) {
        this.DOP = DOP;
    }

    public String getDOI() {
        return DOI;
    }

    public void setDOI(String DOI) {
        this.DOI = DOI;
    }

    public String getPendingReason() {
        return PendingReason;
    }

    public void setPendingReason(String pendingReason) {
        PendingReason = pendingReason;
    }

    public String getCallBookDate() {
        return CallBookDate;
    }

    public void setCallBookDate(String callBookDate) {
        CallBookDate = callBookDate;
    }

    public String getAssignDate() {
        return AssignDate;
    }

    public void setAssignDate(String assignDate) {
        AssignDate = assignDate;
    }

    public String getClosedDate() {
        return ClosedDate;
    }

    public void setClosedDate(String closedDate) {
        ClosedDate = closedDate;
    }

    public String getCancelledDate() {
        return CancelledDate;
    }

    public void setCancelledDate(String cancelledDate) {
        CancelledDate = cancelledDate;
    }

    public String getChangeDate() {
        return ChangeDate;
    }

    public void setChangeDate(String changeDate) {
        ChangeDate = changeDate;
    }

    public String getTechnicianCode() {
        return TechnicianCode;
    }

    public void setTechnicianCode(String technicianCode) {
        TechnicianCode = technicianCode;
    }

    public String getTechName() {
        return TechName;
    }

    public void setTechName(String techName) {
        TechName = techName;
    }

    public String getCustomerCode() {
        return CustomerCode;
    }

    public void setCustomerCode(String customerCode) {
        CustomerCode = customerCode;
    }

    public String getCustomerName() {
        return CustomerName;
    }

    public void setCustomerName(String customerName) {
        CustomerName = customerName;
    }

    public String getPinCode() {
        return PinCode;
    }

    public void setPinCode(String pinCode) {
        PinCode = pinCode;
    }

    public String getTelePhone() {
        return TelePhone;
    }

    public void setTelePhone(String telePhone) {
        TelePhone = telePhone;
    }

    public String getRCNNo() {
        return RCNNo;
    }

    public void setRCNNo(String RCNNo) {
        this.RCNNo = RCNNo;
    }

    public String getMobileNo() {
        return MobileNo;
    }

    public void setMobileNo(String mobileNo) {
        MobileNo = mobileNo;
    }

    public String getStreet() {
        return Street;
    }

    public void setStreet(String street) {
        Street = street;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String city) {
        City = city;
    }

    public String getState() {
        return State;
    }

    public void setState(String state) {
        State = state;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getServiceType() {
        return ServiceType;
    }

    public void setServiceType(String serviceType) {
        ServiceType = serviceType;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getPriority() {
        return Priority;
    }

    public void setPriority(String priority) {
        Priority = priority;
    }

    public String getQuantity() {
        return Quantity;
    }

    public void setQuantity(String quantity) {
        Quantity = quantity;
    }

    public String getScheduledate() {
        return scheduledate;
    }

    public void setScheduledate(String scheduledate) {
        this.scheduledate = scheduledate;
    }

    public String getFromDate() {
        return FromDate;
    }

    public void setFromDate(String fromDate) {
        FromDate = fromDate;
    }

    public String getTodate() {
        return Todate;
    }

    public void setTodate(String todate) {
        Todate = todate;
    }

    public String getAgeing() {
        return Ageing;
    }

    public void setAgeing(String ageing) {
        Ageing = ageing;
    }

    public String getOdu_ser_no() {
        return odu_ser_no;
    }

    public void setOdu_ser_no(String odu_ser_no) {
        this.odu_ser_no = odu_ser_no;
    }

    public String getFGCode() {
        return FGCode;
    }

    public void setFGCode(String FGCode) {
        this.FGCode = FGCode;
    }

    public String getProblemDescription() {
        return ProblemDescription;
    }

    public void setProblemDescription(String problemDescription) {
        ProblemDescription = problemDescription;
    }

    public String getAdditive() {
        return Additive;
    }

    public void setAdditive(String additive) {
        Additive = additive;
    }

    public String getAdditiveDesc() {
        return AdditiveDesc;
    }

    public void setAdditiveDesc(String additiveDesc) {
        AdditiveDesc = additiveDesc;
    }
}
