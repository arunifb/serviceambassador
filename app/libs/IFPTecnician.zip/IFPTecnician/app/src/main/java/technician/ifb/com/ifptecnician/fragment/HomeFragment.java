package technician.ifb.com.ifptecnician.fragment;

import android.app.ActivityManager;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.v4.app.Fragment;

import android.support.v4.widget.SwipeRefreshLayout;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;


import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.github.mikephil.charting.utils.MPPointF;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import technician.ifb.com.ifptecnician.LeadActivity;
import technician.ifb.com.ifptecnician.LoginActivity;
import technician.ifb.com.ifptecnician.MyApplication;
import technician.ifb.com.ifptecnician.R;
import technician.ifb.com.ifptecnician.TaskListActivity;
import technician.ifb.com.ifptecnician.TodaySale;
import technician.ifb.com.ifptecnician.VolleyRespondsListener;
import technician.ifb.com.ifptecnician.alert.Alert;
import technician.ifb.com.ifptecnician.allurl.AllUrl;
import technician.ifb.com.ifptecnician.exchange.ExchangeList;
import technician.ifb.com.ifptecnician.internet.CheckConnectivity;
import technician.ifb.com.ifptecnician.internet.InternetSpeed;
import technician.ifb.com.ifptecnician.model.TasklistModel;
import technician.ifb.com.ifptecnician.negative_response.NegativeResponse;
import technician.ifb.com.ifptecnician.offlinedata.Dbhelper;
import technician.ifb.com.ifptecnician.service.CallNoticatication;
import technician.ifb.com.ifptecnician.service.ErrorDetails;
import technician.ifb.com.ifptecnician.session.SessionManager;
import technician.ifb.com.ifptecnician.stock.StockActivity;
import technician.ifb.com.ifptecnician.troublesehoot.Troublesehooting;
import technician.ifb.com.ifptecnician.utility.DateTimeFilter;
import technician.ifb.com.ifptecnician.utility.GetVolleyRequest;

import static android.os.Looper.getMainLooper;
import static android.provider.ContactsContract.CommonDataKinds.Website.URL;

public class HomeFragment extends Fragment implements
        OnChartValueSelectedListener ,View.OnClickListener,SwipeRefreshLayout.OnRefreshListener {

    private static final String TAG="Home%20Fragment";
    VolleyRespondsListener listener;
    private SwipeRefreshLayout swipeView;
    Dbhelper dbhelper;
    Context context;
    Cursor cursor;
    SessionManager sessionManager;
    String PartnerId;
    String responsedata;
    Map<String, Integer> citys = new HashMap<>();
    RelativeLayout ll_todaytask,ll_assign,ll_pending,ll_closed,ll_cancel,ll_nr,rl_resolved,rl_lead,rl_requestcancellation,rl_exchangelist,rl_trouble,rl_stock;
    TextView tv_todaytask,tv_assign,tv_pending,tv_closed,tv_cancel,tv_nr,tv_resolved,tv_lead,tv_requestcancellation_count;
    boolean refreshToggle = true;
    String currentdate,beforedate;
    int total_todaytask=0,ascount=0,pencount=0,cancount=0,clocount=0,nrcount=0,rsccount=0,rccount=0;
    String mobile_no="";
    ErrorDetails errorDetails;
    int no=1;
    String [] CallType={"ZSER07","ZMAN07","ZFOC07","ZINT07","ZDD07","ZRIN07","ZREW07"};
    String mobile_details;
    SharedPreferences sharedPreferences;
    String remarkurl;

    LinearLayout ll_nointernet;
    TextView tv_error;

    Date c = Calendar.getInstance().getTime();
    SimpleDateFormat dfs = new SimpleDateFormat("dd-MMM-yyyy", Locale.ENGLISH);
    String tss = dfs.format(c);

    View view;
    ProgressBar progressBar;

    Alert alert=new Alert();

    String dbversion="";



    Cursor pcursor,check_date_cursor;
    public HomeFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view=inflater.inflate(R.layout.fragment_home,container,false);
        view.setClickable(false);

        sessionManager=new SessionManager(getContext());
        errorDetails=new ErrorDetails();

        dbhelper=new Dbhelper(getContext());
        dbversion=dbhelper.getappversion();
        sharedPreferences= getActivity().getSharedPreferences(AllUrl.MOBILE_DETAILS,0);
        mobile_details=sharedPreferences.getString("Mobile_details","");
        HashMap<String, String> user = sessionManager.getUserDetails();
        PartnerId=user.get(SessionManager.KEY_PartnerId);
        mobile_no=user.get(SessionManager.KEY_mobileno);

        tv_error=view.findViewById(R.id.tv_error_message);

        progressBar=view.findViewById(R.id.pbProcessing);

        ll_todaytask=view.findViewById(R.id.rl_todaytask);

        ll_assign=view.findViewById(R.id.rl_assigned);
        ll_pending=view.findViewById(R.id.rl_pending);
        ll_closed=view.findViewById(R.id.rl_closed);
        ll_cancel=view.findViewById(R.id.rl_cancelled);
        ll_nr=view.findViewById(R.id.rl_nr);
        rl_resolved=view.findViewById(R.id.rl_resolved);
        rl_lead=view.findViewById(R.id.rl_lead);
        rl_exchangelist=view.findViewById(R.id.rl_exchange);
        rl_trouble=view.findViewById(R.id.rl_trouble);
        rl_requestcancellation=view.findViewById(R.id.rl_requestcancellation);
        rl_requestcancellation.setOnClickListener(this);

        rl_stock=view.findViewById(R.id.rl_stock);
        rl_stock.setOnClickListener(this);
        swipeView=view.findViewById(R.id.swipe_view);
        swipeView.setOnRefreshListener(this);
        swipeView.setColorSchemeColors(Color.GRAY, Color.GREEN, Color.BLUE,
                Color.RED, Color.CYAN);
        swipeView.setDistanceToTriggerSync(20);// in dips
        swipeView.setSize(SwipeRefreshLayout.DEFAULT);// LARGE also can be used
        ll_nointernet=view.findViewById(R.id.ll_nointernet);
        tv_todaytask=view.findViewById(R.id.tv_today_count);
        tv_assign=view.findViewById(R.id.tv_assign_count);
        tv_pending=view.findViewById(R.id.tv_pending_count);
        tv_closed=view.findViewById(R.id.tv_closed_count);
        tv_cancel=view.findViewById(R.id.tv_cancel_count);
        tv_nr=view.findViewById(R.id.tv_nr_count);
        tv_resolved=view.findViewById(R.id.tv_resolved_count);
        tv_lead=view.findViewById(R.id.tv_lead_count);






        tv_requestcancellation_count=view.findViewById(R.id.tv_requestcancellation_count);

        ll_todaytask.setOnClickListener(this);
        ll_assign.setOnClickListener(this);
        ll_pending.setOnClickListener(this);
        ll_closed.setOnClickListener(this);
        ll_cancel.setOnClickListener(this);
        ll_nr.setOnClickListener(this);
        rl_resolved.setOnClickListener(this);
        rl_lead.setOnClickListener(this);
        rl_exchangelist.setOnClickListener(this);
        rl_trouble.setOnClickListener(this);

        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 20);

        if (CheckConnectivity.getInstance(getActivity()).isOnline()){


           ll_nointernet.setVisibility(View.GONE);
            getAllData();
            get_pending_reason();
        }
        else{

            ll_nointernet.setVisibility(View.VISIBLE);

            Beforeload();
        }
        return  view;
    }


    public void get_pending_reason(){

      try{

        if (!Boolean.valueOf(dbhelper.ISDateExsits(tss)).booleanValue()) {

            dbhelper.delete_pending_reasone();

            for(int p=0 ; p < CallType.length ; p++){

                getremarkdata(CallType[p]);
            }

        }
        else {

        }

      }catch (Exception e){
          e.printStackTrace();
      }

    }



    @Override
    public void onValueSelected(Entry e, Highlight h) {

    }

    @Override
    public void onNothingSelected() {

    }

    @Override
    public void onClick(View v) {

        switch (v.getId()){

           // total_todaytask=0,ascount=0,pencount=0,cancount=0,clocount=0,nrcount=0;
            case R.id.rl_todaytask:

                if(total_todaytask== 0){


                    showpop("No records found");
                }
                else{

                    try{

                        errorDetails.Errorlog(getContext(),"Click%20On%20Open%20Task%20Button", TAG,"Total%20No%20Of%20Tickets%20"+total_todaytask,"Total%20Tickets%20"+total_todaytask,mobile_no,"0000000000","C",mobile_details,dbversion,tss);
                        startActivity(new Intent(getActivity(), TaskListActivity.class)
                                .putExtra("status","todaytask"));
                    }catch (Exception e){
                        e.printStackTrace();
                    }

                }
                break;
            case R.id.rl_assigned:
                if (ascount==0){

                    errorDetails.Errorlog(getContext(),"Click%On%20Assign%20Button", TAG,"Total%20No%20Of%20Tickets","Total%20Tickets",mobile_no,"0000000000","C",mobile_details,dbversion,tss);

                    showpop("No records found");
                }
                else{
                    if (CheckConnectivity.getInstance(getActivity()).isOnline()) {
                        errorDetails.Errorlog(getContext(), "Click%On%20Assign%20Button", TAG, "Total%20No%20Of%20Tickets" + ascount, "Total%20Tickets" + ascount, mobile_no, "0000000000", "C", mobile_details, dbversion, tss);
                    }

                        startActivity(new Intent(getContext(), TaskListActivity.class)
                                .putExtra("status","assign"));
                }

                break;
            case R.id.rl_pending:

                if (pencount==0){
                    errorDetails.Errorlog(getContext(),"Click%On%20Pending%20Button", TAG,"Total%20No%20Of%20Ticket%20"+pencount,"Total%20Ticket%20"+pencount,mobile_no,"0000000000","C",mobile_details,dbversion,tss);

                    showpop("No records found");
                }
                else{
                    errorDetails.Errorlog(getContext(),"Click%On%20Pending%20Button", TAG,"Total%20No%20Of%20Tickets"+pencount,"Total%20Tickets"+pencount,mobile_no,"0000000000","C",mobile_details,dbversion,tss);
                      startActivity(new Intent(getContext(), TaskListActivity.class)
                            .putExtra("status","pending"));
                }


                break;
            case R.id.rl_cancelled:

                if (cancount == 0){
                    errorDetails.Errorlog(getContext(),"Click%On%20Cancelled%20Button", TAG,"Total%20No%20Of%20Ticket%20"+cancount,"Total%20Tickets%20"+cancount,mobile_no,"0000000000","C",mobile_details,dbversion,tss);
                    showpop("No records found");
                }
                else{
                    errorDetails.Errorlog(getContext(),"Click%On%20Cancelled%20Button", TAG,"Total%20No%20Of%20Tickets%20"+cancount,"Total%20Tickets%20"+cancount,mobile_no,"0000000000","C",mobile_details,dbversion,tss);
                    startActivity(new Intent(getContext(), TaskListActivity.class)
                            .putExtra("status","cancel"));
                }

                break;
            case R.id.rl_closed:
                if (clocount==0){
                    errorDetails.Errorlog(getContext(),"Click%On%20Closed%20Button", TAG,"Total%20No%20Of%20Tickets%20"+clocount,"Total%20Ticket%20"+clocount,mobile_no,"0000000000","C",mobile_details,dbversion,tss);
                    showpop("No records found");
                }
                else {

                    errorDetails.Errorlog(getContext(),"Click%On%20Closed%20Button", TAG,"Total%20No%20Of%20Tickets%20"+clocount,"Total%20Of%20Tickets%20"+clocount,mobile_no,"0000000000","C",mobile_details,dbversion,tss);
                    startActivity(new Intent(getContext(), TaskListActivity.class)
                            .putExtra("status","close"));
                }

                break;

            case R.id.rl_nr:
                if (nrcount==0){
                    errorDetails.Errorlog(getContext(),"Click%On%20Negative%20Response%20Button", TAG,"Total%20No%20Of%20Tickets%20"+nrcount,"Total%20Tickets%20"+nrcount,mobile_no,"0000000000","C",mobile_details,dbversion,tss);


                    showpop("No records found");
                }
               else {
                    errorDetails.Errorlog(getContext(),"Click%On%20Negative%20Response%20Button", TAG,"Total%20No%20Of%20Tickets%20"+nrcount,"Total%20Tickets%20"+nrcount,mobile_no,"0000000000","C",mobile_details,dbversion,tss);
                    startActivity(new Intent(getContext(), TaskListActivity.class)
                            .putExtra("status", "nr"));

                }
                break;

            case R.id.rl_resolved:
                if (rsccount==0){
                    errorDetails.Errorlog(getContext(),"Click%On%20Soft%20Closure%20Button", TAG,"Total%20No%20Of%20Tickets%20"+rsccount,"Total%20Tickets%20"+rsccount,mobile_no,"0000000000","C",mobile_details,dbversion,tss);
                    showpop("No records found");
                }
                else {
                    errorDetails.Errorlog(getContext(),"Click%On%20Soft%20Closure", TAG,"Total%20No%20Of%20Tickets%20"+rsccount,"Total%20Tickets%20"+rsccount,mobile_no,"0000000000","C",mobile_details,dbversion,tss);
                    startActivity(new Intent(getContext(), TaskListActivity.class)
                            .putExtra("status", "resolved"));
                }
                break;

            case R.id.rl_requestcancellation:
                if (rsccount==0){


                    showpop("No records found");
                }
                else {

                    startActivity(new Intent(getContext(), TaskListActivity.class)
                            .putExtra("status", "Request%20Cancellation"));
                }
                break;


            case R.id.rl_lead:

                errorDetails.Errorlog(getContext(),"Click%On%20Todaysales", TAG,"Total%20","Total%20",mobile_no,"0000000000","C",mobile_details,dbversion,tss);
               // startActivity(new Intent(getContext(), LeadActivity.class));
                startActivity(new Intent(getContext(), TodaySale.class));

                break;
            case R.id.rl_exchange:
                startActivity(new Intent(getContext(), ExchangeList.class));
                break;

            case R.id.rl_trouble:
                startActivity(new Intent(getContext(), Troublesehooting.class));
                break;

            case R.id.rl_stock:
                startActivity(new Intent(getContext(), StockActivity.class));
                break;

                default:

                    break;

        }
    }


    @Override
    public void onRefresh() {

        if (CheckConnectivity.getInstance(getActivity()).isOnline()) {

            ll_nointernet.setVisibility(View.GONE);

            getAllData();
        }

        else {

            ll_nointernet.setVisibility(View.VISIBLE);

            swipeView.setRefreshing(false);

        }
    }

    public void  getremarkdata(String Callcode){

        remarkurl=AllUrl.baseUrl+"Reasons/pendingReasons?pendingReasone.CodeGroup="+Callcode;
        RequestQueue queue = Volley.newRequestQueue(getContext());

        StringRequest stringRequests = new StringRequest(Request.Method.GET, remarkurl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {


                        try {

                               try{

                                   boolean status= dbhelper.insert_pending_reasone_data(Callcode,response,tss);

                               }catch (Exception e){
                                   e.printStackTrace();
                               }


                        } catch (Exception e) {

                            e.printStackTrace();

                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });

// Add the request to the RequestQueue.
        queue.add(stringRequests);

    }

    public void Beforeload(){

        try{

            cursor=dbhelper.getalldashboard();

            if (cursor != null) {

                if (cursor.moveToFirst()) {

                    do {

                        final int recordid = cursor.getInt(cursor.getColumnIndex("recordid"));
                        String Name = cursor.getString(cursor.getColumnIndex("Name"));
                        String Count = cursor.getString(cursor.getColumnIndex("Count"));

                        switch (Name) {

                            case "Total":
                                tv_todaytask.setText(Count);
                                total_todaytask=Integer.parseInt(Count);
                                break;

                            case "Assigned":
                                tv_assign.setText(Count);
                                ascount=Integer.parseInt(Count);
                                break;

                            case "Pending":
                                pencount=Integer.parseInt(Count);
                                tv_pending.setText(Count);

                                break;

                            case "Closed":
                                tv_closed.setText(Count);
                                clocount=Integer.parseInt(Count);
                                break;

                            case "Cancelled":
                                tv_cancel.setText(Count);
                                cancount=Integer.parseInt(Count);
                                break;

                            case "Negative Response":
                                tv_nr.setText(Count);
                                nrcount=Integer.parseInt(Count);
                                break;

                            case "Resolved(softclosure)":
                                tv_resolved.setText(Count);
                                rsccount=Integer.parseInt(Count);
                                break;

                            case "RequestCancellation":
                                tv_requestcancellation_count.setText(Count);
                                rccount=Integer.parseInt(Count);
                                break;

                            default:

                                break;

                        }
                    } while (cursor.moveToNext());

                    cursor.close();


                }
            } else {


                Toast.makeText(getContext(), "No Record Found", Toast.LENGTH_SHORT).show();
            }
        }catch (Exception e){
            e.printStackTrace();
        }

    }

    public void getAllData(){

        dbhelper.deletedashboard();

        String url= AllUrl.baseUrl+"DashBoard/getDashBoardCount?model.dashboard.PartnerId="+PartnerId+"";

        progressBar.setVisibility(View.VISIBLE);

        RequestQueue queue = Volley.newRequestQueue(getContext());

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

//                        hideProgressDialog();

                        progressBar.setVisibility(View.GONE);
                        swipeView.setRefreshing(false);

                        try {

                            JSONObject object=new JSONObject(response);

                            String status=object.getString("Status");
                            String Message=object.getString("Message");
                            if (status.equals("true")){

                                JSONArray jsonArray = new JSONArray(object.getString("Data"));

                                for (int i = 0; i < jsonArray.length(); i++) {

                                    JSONObject objs = jsonArray.getJSONObject(i);

                                    tv_todaytask.setText(objs.getString("Total"));
                                    tv_assign.setText(objs.getString("Assigned"));
                                    tv_pending.setText( objs.getString("Pending"));
                                    tv_requestcancellation_count.setText(objs.getString("ReqCan"));
                                    //objs.getString("ReqForReAllocation");
                                    tv_resolved.setText(objs.getString("SoftClosed"));
                                    tv_closed.setText(objs.getString("Closed"));
                                    tv_cancel.setText(objs.getString("Cancelled"));
                                    tv_nr.setText(objs.getString("NegResFrCut"));

                                    total_todaytask=Integer.parseInt(objs.getString("Total"));
                                    ascount=Integer.parseInt(objs.getString("Assigned"));


                                    pencount=Integer.parseInt(objs.getString("Pending"));

                                    rsccount=Integer.parseInt(objs.getString("SoftClosed"));

                                    rccount=Integer.parseInt(objs.getString("ReqCan"));

                                    cancount=Integer.parseInt(objs.getString("Cancelled"));

                                    clocount = Integer.parseInt(objs.getString("Closed"));

                                    nrcount=Integer.parseInt(objs.getString("NegResFrCut"));

                                    dbhelper.insert_dashboarddata("Total",objs.getString("Total"));
                                    dbhelper.insert_dashboarddata("Assigned",objs.getString("Assigned"));
                                    dbhelper.insert_dashboarddata("Pending",objs.getString("Pending"));
                                    dbhelper.insert_dashboarddata("Resolved(softclosure)",objs.getString("SoftClosed"));
                                    dbhelper.insert_dashboarddata("Closed",objs.getString("Closed"));
                                    dbhelper.insert_dashboarddata("RequestCancellation",objs.getString("ReqCan"));
                                    dbhelper.insert_dashboarddata("Cancelled",objs.getString("Cancelled"));
                                    dbhelper.insert_dashboarddata("Negative Response",objs.getString("NegResFrCut"));

                                }


                            }
                            else{

                                showpop("Please Try Again Later");
                               // Toast.makeText(getContext(), "Please Try Again Later", Toast.LENGTH_SHORT).show();


                            }


                        } catch (Exception e) {
                            e.printStackTrace();

                        }

                        progressBar.setVisibility(View.GONE);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                alert.showDialog(getActivity(),"Timeout Error","Please Try Again Later");

                progressBar.setVisibility(View.GONE);
                swipeView.setRefreshing(false);
            }
        });
// Add the request to the RequestQueue.
        int socketTimeout = 10000; //10 seconds - change to what you want
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        stringRequest.setRetryPolicy(policy);
        queue.add(stringRequest);


    }

    private boolean isMyServiceRunning(Class<?> serviceClass) {
        try{
        ActivityManager manager = (ActivityManager)getContext().getSystemService(getContext().ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                Log.i ("isMyServiceRunning?", true+"");
                return true;
            }
        }
        Log.i ("isMyServiceRunning?", false+"");
        return false;

        }catch (Exception e){
            e.printStackTrace();
        }

        return false;
    }

    public void showpop(String text){

        tv_error.setText(text);
        tv_error.setVisibility(View.VISIBLE);
        Animation animation;
        animation = AnimationUtils.loadAnimation(getContext(), R.anim.slide_down);
        tv_error.startAnimation(animation);

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            public void run() {
                tv_error.setAnimation(null);
                tv_error.setVisibility(View.GONE);
            }
        }, 5000);
    }
}
