//package ifb.arodek.com.technician.barcode;
//
//import android.os.Bundle;
//
//import ifb.arodek.com.technician.R;
//
//public class SimpleScannerFragmentActivity extends BaseScannerActivity {
//    @Override
//    public void onCreate(Bundle state) {
//        super.onCreate(state);
//        setContentView(R.layout.activity_simple_scanner_fragment);
//        setupToolbar();
//    }
//}