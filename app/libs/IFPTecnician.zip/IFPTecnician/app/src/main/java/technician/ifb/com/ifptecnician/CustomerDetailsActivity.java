package technician.ifb.com.ifptecnician;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.NumberPicker;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.TimePicker;
import com.airbnb.lottie.LottieAnimationView;
import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import com.github.chrisbanes.photoview.PhotoView;

import com.google.gson.Gson;
import com.squareup.picasso.Picasso;
import com.toptoche.searchablespinnerlibrary.SearchableSpinner;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.xml.validation.Validator;

import technician.ifb.com.ifptecnician.adapter.AddProductadapter;
import technician.ifb.com.ifptecnician.adapter.Add_item_adapter;
import technician.ifb.com.ifptecnician.adapter.Essential_add_adapter;
import technician.ifb.com.ifptecnician.adapter.Pending_item_adapter;
import technician.ifb.com.ifptecnician.alert.Alert;
import technician.ifb.com.ifptecnician.allurl.AllUrl;
import technician.ifb.com.ifptecnician.barcode.FullScannerActivity;
import technician.ifb.com.ifptecnician.customersign.CustomerSign;
import technician.ifb.com.ifptecnician.ebill.CreateBill;
import technician.ifb.com.ifptecnician.exchange.ExchangeMain;
import technician.ifb.com.ifptecnician.internet.CheckConnectivity;
import technician.ifb.com.ifptecnician.model.Add_Product_Model;
import technician.ifb.com.ifptecnician.model.Add_item_model;
import technician.ifb.com.ifptecnician.model.Add_spare_item_model;
import technician.ifb.com.ifptecnician.model.Essential_add_model;
import technician.ifb.com.ifptecnician.model.PendingSpare;
import technician.ifb.com.ifptecnician.offlinedata.Dbhelper;
import technician.ifb.com.ifptecnician.service.ErrorDetails;
import technician.ifb.com.ifptecnician.session.SessionManager;
import technician.ifb.com.ifptecnician.utility.AsyncFindmodel;
import technician.ifb.com.ifptecnician.utility.NumberPickerDialog;
import technician.ifb.com.ifptecnician.utility.Valuefilter;

import static com.android.volley.Request.Method.POST;

public class CustomerDetailsActivity extends AppCompatActivity implements
         AdapterView.OnItemSelectedListener,
         NumberPicker.OnValueChangeListener,
         View.OnClickListener, AsyncFindmodel.AsyncResponse {

  private static final String TAG = CustomerDetailsActivity.class.getSimpleName();
    static final int I_SNO=1;
    static final int PICK_CONTACT=2;
    static final int ODU_NO=5;
    static final int SCAN_PART=6;
    static final int SPARE_SNO=3;
    static final int SCAN_ESS_NO=4;
    static final int SCANSERIALNO=115;
    public static final int INVOICE_IMAGE_CAPTURE = 7;
    public static final int SERIALNO_IMAGE_CAPTURE = 9;
    public static final int ODU_SERIALNO_IMAGE_CAPTURE = 10;

    public static final int CUSTOMER_SIGNATURE=11;
    String serialnourl="",oduurl="",invioceurl="";
    public static final int REQUEST_IMAGE = 8;
    String FrCode,FGProducts;
    Alert alert=new Alert();
    String Component,ComponentDescription,FGDescription,FGProduct,FrCodes,MaterialCategory,good_stock,refurbished_stock;
    Dbhelper dbhelper;
    String proces_type;

    String mobile_details;
    SharedPreferences sharedPreferences;
    //csv file create

    private RequestQueue rQueue;

    Cursor bom_cursor, ess_cursor;
    TextView tv_calltype, tv_ticketno, tv_address, tv_callbook, tv_status, tv_rcnno, tv_servicetype, tv_custname;
    String TicketNo,Franchise,CallType,Status,
            Product,SerialNo="000000000000000000",DOP="00000000",DOI="00000000",CallBookDate,AssignDate,
            CustomerCode,CustomerName,PinCode,TelePhone,RCNNo,ProblemDescription,PendingReason,
            Street, City, State, Address, ServiceType,ChangeDate,flagstatus="";
    public ArrayList<Add_item_model> models = new ArrayList<Add_item_model>();
    public ArrayList<Add_spare_item_model> add_spare_item_models=new ArrayList<Add_spare_item_model>();
    public Add_spare_item_model add_spare_item_model;
    TextView tv_modelname;

    public static String serialno_scan="";

    Add_item_adapter add_item_adapter;
    SessionManager sessionManager;
    String PartnerId;
    String work_status="";

    String eta="00000000";
    String rechaeck_date="00000000";
    int bom_qty=0;
    TextView tv_bom_qty;
    CheckBox checkBox;
    String spare_not_found="";
    public Add_item_model model;
    SharedPreferences prefdetails;
    //Part section
    SearchableSpinner spinner;
    List<String> itemlist;
    TextView tv_part_code;
    //        Button btn_savepart;
    TextView tv_quentity;
    String quentity = "1";
    ListView lv_additem;
    String partname, partcode;
    Map<String, String> mappartcode;


    //        Button btn_scan_part;
    LinearLayout ll_add_part, ll_scan_part;
    ListView lv_pending_item;
    public PendingSpare pendingSpare;
    public ArrayList<PendingSpare> pendingSpares=new ArrayList<PendingSpare>();
    String CodeGroup;
    //customer details
    TextView tv_mobile,tv_addresss, tv_PinCode, tv_TelePhone, tv_Street, tv_City, tv_State, tv_pending_status;
    TextView tv_tel,tv_ageing;
    ImageView iv_iv_priorit,iv_alt_call;
    TextView tv_escal,tv_problemdescription;
    Button btn_openmap;
    //Machine Details
    TextView tv_Product, tv_Model, tv_SerialNo, tv_MachinStatus, tv_DOP, tv_DOI, tv_problem_details, tv_CallBookDate, tv_AssignDate;
    String datestatus,oduserno;
    ImageView iv_doi, iv_dop;
    LottieAnimationView scan_serialno;
    final Calendar myCalendar = Calendar.getInstance();
    //Amc detaills
    LinearLayout ll_amc_view;
    TextView  tv_amcno,tv_amcdate, tv_amcduration;

    TextView tv_fgproduct,ess_tv_shelflife;

    //TAb layout
    LinearLayout ll_customer, ll_spare, ll_essential, ll_sales, ll_machine, ll_status;
    ImageView iv_info, iv_part, iv_ess, iv_note, iv_machine, iv_status;
    TextView t_cus, t_mach, t_spare, t_essen, t_status, t_note;

    //View section
    LinearLayout ll_details, ll_part, ll_esential, ll_notes, ll_machine_details, ll_status_details;

    //essential
    List<String> essspinerlist;
    Map<String, String> map_ess_code;
    SearchableSpinner ess_spiner;
    String accessories_stock,additives_stock;
    TextView tv_ess_sqty;
    int accstock=0,addstock=0,ess_stock=0;

    // Button btn_scan_ecc,ess_btn_add;
    TextView tv_ess_component, tv_ess_quentity;
    public ArrayList<Essential_add_model> essential_add_models = new ArrayList<>();
    public Essential_add_model essential_add_model;
    Essential_add_adapter essential_add_adapter;
    String essComponentDescription, essComponent,ItemType;
    ListView lv_ess_add_item;
    LinearLayout ll_add_ess, ll_scan_ess;

    //status

    String rescheduledate;
    EditText et_icr_no;
    LinearLayout ll_icr_date;
    Bitmap customer_sign_bitmap;
    TextView tv_icr_date;
    String st_icr_no="";
    String st_icr_date="00000000";
    Spinner snpr_status;
   // EditText et_status;
    Button btn_status;
    String spnr_status;
    String DIRECTORY = Environment.getExternalStorageDirectory().getPath() + "/Signature/";
    String pic_name = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
    String StoredPath = DIRECTORY + pic_name + ".png";
    private Button  btnSave;

    private File file;

    ImageView iv_call;
    String remarkurl;
    SearchableSpinner spnr_remark;
    List<String> remarklist;
    Map<String,String> remarkmap;
    String remark,remarkcode;

    TextView tv_sdate,tv_stime;
    String sdate="00000000",stime="000000";
    LinearLayout ll_select_date,ll_select_time;
    LinearLayout ll_change;
    TextView tv_select_date,tv_select_time;

    //notes
    Spinner spnr_product,spnr_machine,spnr_member,spnr_residence;
    Switch aSwitch;
    LinearLayout ll_add_details;
    String product_name,machine_name,years,switch_status;

    String [] product_list={"FL","TL","MW","DW","CD","AC","BIH","BIO"};
    String [] machine_list={"SAMSUNG","CARRIER","DAIKIN","HITACHI","BLUESTAR","PHILIPS","IFB","LG","WHIRLPOOL","GODREJ","SONY","PANASONIC","HAIER","BOSCH","VOLTAS","OTHERS"};
    String [] residence_list={"Residence","1 BHK","2 BHK","3 BHK","4 BHK","BUNGLOW"};

    EditText et_contact;
    HashMap<String,String> map_residence=new HashMap<>();
    HashMap<String,String> map_machine=new HashMap<>();
    ListView lv_product;
    ArrayList<Add_Product_Model> add_product_models=new ArrayList<>();
//    RecyclerView rv_product;
//    Add_Product_Adapter add_product_adapter;
    Add_Product_Model add_product_model;
    AddProductadapter addProductadapter;
    String no_of_member,residence;
    String nomen="",residen="";
    EditText et_feedback;
    String st_feedback;
    String zz_fl="",zz_flbrand="",zz_mt5fl="",zz_tl="",zz_tlbrand="",zz_mt5tl="",zz_mw="",zz_mwbrand="",zz_mt5mw="",zz_dw="",zz_dwbrand="",zz_mt5dw="",zz_cd="",zz_cdbrand="",zz_mt5cd="",zz_ac="",zz_acbrand="",zz_mt5ac="",zz_bih="",zz_bihbrand="",zz_mt5bih="",zz_bio="",zz_biobrand="",zz_mt5bio="";
    String tss;

    List<String> All_click=new ArrayList<>();
    String validNumber = "[0-9]+";
    ErrorDetails errorDetails;
    String mobile_no;
    TextView tv_odu_ser_no;
    LottieAnimationView btn_scan_odu_serial_no;
    ImageView lv_camera_invioce,view_invioce;
    ImageView lv_camera_serialno,lv_camera_oduserialno,view_serialno,view_oduserialno;
    List<String> imagelist=new ArrayList<>();
    String serialno_image="%20",oduserialno_image="%20",invoice_image="%20";
    byte[] seraialno_image_data = null ,oduserialno_image_data= null ,invoice_image_data=null,customersign_data=null;

    ImageView iv_message;

    LinearLayout ll_serial_no_image,ll_odu_serial_no_image,ll_invioce_no_image;

    TextView tv_rating,tv_rating_point;
    String name;
    //image upload layout
    SharedPreferences ratingperf;
    Bitmap imagebitmap;
    Boolean imagestatus=false;
    Button btn_updateaddress;
    ImageView img_exchange;

    //essential value
    String shelflife="",essuses="1/day";
    Spinner spnr_ess_value;
    TextView tv_ess_calculation;
    LinearLayout ll_ess_cal;
    TextView tv_sign;
    ImageView iv_customersign;
    LinearLayout lv_custsign;
    List<String[]> data = new ArrayList<String[]>();
    JSONArray finaljsonArray;
    int totallinecount=0;
    String ticketdetails;
    TextView tv_error_message;
    ProgressBar progressBar;
    String dbversion="",Medium="";
    LinearLayout ll_medium;
    ImageView img_map;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_details);

        prefdetails = getSharedPreferences("details", 0);
        ratingperf=getSharedPreferences("rating",0);
        dbhelper = new Dbhelper(getApplicationContext());
       
        dbversion=dbhelper.getappversion();

        errorDetails=new ErrorDetails();
        sharedPreferences=getSharedPreferences(AllUrl.MOBILE_DETAILS,0);
        mobile_details=sharedPreferences.getString("Mobile_details","");

//        Date c = Calendar.getInstance().getTime();
//        SimpleDateFormat dfs = new SimpleDateFormat("dd-MMM-yyyy", Locale.ENGLISH);
//        tss = dfs.format(c);

        tss= Valuefilter.getdate();

        System.out.println("Current date"+tss);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


        // ------------------------- get user session value --------------------------
        sessionManager=new SessionManager(getApplicationContext());
        try{

            HashMap<String, String> user = sessionManager.getUserDetails();
            PartnerId=user.get(SessionManager.KEY_PartnerId);
            FrCode=user.get(SessionManager.KEY_FrCode);

            System.out.println("FrCode-->>>> "+FrCode);
            mobile_no=user.get(SessionManager.KEY_mobileno);
            name=user.get(SessionManager.KEY_Name);
        }
        catch (Exception e){

            e.printStackTrace();
        }

        // Method to create Directory, if the Directory doesn't exists
        file = new File(DIRECTORY);
        if (!file.exists()) {
            file.mkdir();
        }

        progressBar=findViewById(R.id.taskProcessing);

        init();

    }

    public void getess() {

        try {

            essspinerlist = new ArrayList<>();
            map_ess_code = new HashMap<>();
            if (dbhelper.isessdataEmpty()) {

                ess_cursor = dbhelper.getallessdata();

                if (ess_cursor != null) {

                    if (ess_cursor.moveToFirst()) {

                        do {

                            final int recordid = ess_cursor.getInt(ess_cursor.getColumnIndex("recordid"));

                            String ComponentDescription = ess_cursor.getString(ess_cursor.getColumnIndex("ComponentDescription"));
                            String Component = ess_cursor.getString(ess_cursor.getColumnIndex("Component"));
                            essspinerlist.add(ComponentDescription);
                            map_ess_code.put(ComponentDescription, Component);
                            //   System.out.println(ComponentDescription + "    " + Component);

                        } while (ess_cursor.moveToNext());

                        ess_cursor.close();

                        ArrayAdapter<String> essAdapter = new ArrayAdapter<>(CustomerDetailsActivity.this, android.R.layout.simple_spinner_dropdown_item, essspinerlist);
                        ess_spiner.setAdapter(essAdapter);
                       // ess_spiner.setSelection(0,false);
                        ess_spiner.setOnItemSelectedListener(CustomerDetailsActivity.this);
                    }
                } else {

                }
            }

        } catch (Exception e) {
            e.printStackTrace();

        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        hideSoftKeyboard(CustomerDetailsActivity.this);

        if (parent.getId() == R.id.spinner) {

            partname = parent.getItemAtPosition(position).toString();
            Cursor bcursor;
            System.out.println("partname-->"+partname);

            try{

                bcursor=dbhelper.get_Single_Bom_Data(partname);

                if (bcursor != null) {

                    if (bcursor.moveToFirst()) {

                        do {

                            partcode = mappartcode.get(partname);
                            tv_part_code.setText(partcode);
                          //  All_click.add("SpareList%20Selected%20spare%20"+partname.replace(" ","%20")+"%20"+partcode);
                            final int recordid = bcursor.getInt(bcursor.getColumnIndex("recordid"));
                          //  System.out.println("recordid-->" + recordid);

                            String ComponentDescription = bcursor.getString(bcursor.getColumnIndex("ComponentDescription"));
                            String good_stock=bcursor.getString(bcursor.getColumnIndex("good_stock"));
                            String refurbished_stock=bcursor.getString(bcursor.getColumnIndex("refurbished_stock"));

                            int goodstock=string_to_int(good_stock);
                            int refurbishedstock=string_to_int(refurbished_stock);

                            if (goodstock < refurbishedstock){

                                tv_bom_qty.setText(refurbished_stock);
                                bom_qty=refurbishedstock;
                            }
                            else {
                                tv_bom_qty.setText(good_stock);
                                bom_qty=goodstock;
                            }

                            errorDetails.Errorlog(CustomerDetailsActivity.this,"Click%20On%20Spare%20List", TAG,partname.replace(" ","%20")+"%20"+partcode,"Spare%20Tab",mobile_no,TicketNo,"C",mobile_details,dbversion,tss);


                        } while (bcursor.moveToNext());

                        bcursor.close();
                    }
                } else {

                }


            }catch (Exception e){

                  e.printStackTrace();
            }

        }
        else if (parent.getId() == R.id.ess_spinner) {

            essComponentDescription = parent.getItemAtPosition(position).toString();
            Cursor cursor;

            try{

                cursor=dbhelper.getesstype(essComponentDescription);

                if (cursor != null) {

                    if (cursor.moveToFirst()) {

                        do {

                            final int recordid = cursor.getInt(cursor.getColumnIndex("recordid"));
                         //   System.out.println("recordid-->" + recordid);
                            String ComponentDescription = cursor.getString(cursor.getColumnIndex("ComponentDescription"));
                            essComponent  =cursor.getString(cursor.getColumnIndex("Component"));
                            ItemType=cursor.getString(cursor.getColumnIndex("ItemType"));
                         //   System.out.println(ComponentDescription + "    " +essComponent + "  "+ItemType);

                            shelflife=cursor.getString(cursor.getColumnIndex("ShelfLife"));
                            ess_tv_shelflife.setText(shelflife);


                            System.out.println("shelflife-->"+shelflife);
                            tv_ess_component.setText(essComponent);

                            accessories_stock = cursor.getString(cursor.getColumnIndex("accessories_stock"));
                            additives_stock =   cursor.getString(cursor.getColumnIndex("additives_stock"));

                             accstock=string_to_int(accessories_stock);
                             addstock=string_to_int(additives_stock);

                             if (accstock < addstock){
                                 tv_ess_sqty.setText(additives_stock);
                                 ess_stock=addstock;
                             }
                             else {
                                 ess_stock=accstock;
                                 tv_ess_sqty.setText(accessories_stock);
                             }

                            getcal();
                          } while (cursor.moveToNext());
                        cursor.close();

                    }
                } else {

                }
            }catch (Exception e){

                e.printStackTrace();
            }


        }
        else if (parent.getId() == R.id.spnr_status) {

            spnr_status = parent.getItemAtPosition(position).toString();
            if (spnr_status.equals("Pending")){

                ll_change.setVisibility(View.VISIBLE);

                getremarkdata(CallType);
                spnr_remark.setVisibility(View.VISIBLE);

            }
            else if(spnr_status.equals("Resolved (soft closure)")){
                spnr_remark.setVisibility(View.GONE);
                ll_change.setVisibility(View.GONE);

               // errorDetails.Errorlog(CustomerDetailsActivity.this,"Click%20On%20Status%20List", TAG,"Status%20Tab",spnr_status.replace(" ","%20"),mobile_no,TicketNo,"",mobile_details,dbversion,tss);
            }

            else
            {

                spnr_remark.setVisibility(View.GONE);
                ll_change.setVisibility(View.GONE);
            }


            if (spnr_status.equals("Select status")) {

             //   System.out.println("Nothing selected");
                spnr_remark.setVisibility(View.GONE);
                ll_change.setVisibility(View.GONE);

            }

        }
        else if (parent.getId() == R.id.spnr_remark){

            remark= parent.getItemAtPosition(position).toString();
            remarkcode=remarkmap.get(remark);

        }
        else if (parent.getId() == R.id.spnr_machine){

           machine_name= parent.getItemAtPosition(position).toString();

        }
        else if (parent.getId() == R.id.spnr_product){
            product_name= parent.getItemAtPosition(position).toString();

        }
        else if (parent.getId() == R.id.spnr_member) {

            no_of_member= parent.getItemAtPosition(position).toString();

            if(no_of_member.equals("No. of Members")){
                nomen=""  ;

            }
            else{

                nomen=parent.getItemAtPosition(position).toString();
               // All_click.add("Selected%20no_of_member%20"+   nomen);
            }

        }
        else if (parent.getId() == R.id.spnr_residence) {

            residence= parent.getItemAtPosition(position).toString();

            if(residence.equals("Residence")){

                residen="";
            }
            else{

                residen= getresi(parent.getItemAtPosition(position).toString());
               // All_click.add("Selected%20Residence%20"+   residen.replace(" ","%20"));
            }
        }
        else if(parent.getId() == R.id.spnr_ess_value){
            essuses= parent.getItemAtPosition(position).toString();
           getcal();

        }

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onValueChange(NumberPicker picker, int oldVal, int newVal) {

        quentity = String.valueOf(picker.getValue());
        tv_quentity.setText(quentity);
        tv_ess_quentity.setText(quentity);

       getcal();

    }

    public void showNumberPicker(View view) {
        NumberPickerDialog newFragment = new NumberPickerDialog();
        newFragment.setValueChangeListener(this);
        newFragment.show(getSupportFragmentManager(), "time picker");
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    public class Loadallbom extends AsyncTask<String, String, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressBar.setVisibility(View.VISIBLE);
        }

        protected String doInBackground(String... params) {


            try {

                itemlist = new ArrayList<>();
                mappartcode = new HashMap<>();

                if (dbhelper.isbomdataEmpty()) {

                    bom_cursor = dbhelper.getallbomdata();

                    if (bom_cursor != null) {

                        if (bom_cursor.moveToFirst()) {

                            do {

                                 final int recordid = bom_cursor.getInt(bom_cursor.getColumnIndex("recordid"));
                                // System.out.println("recordid-->" + recordid);
                                 String ComponentDescription = bom_cursor.getString(bom_cursor.getColumnIndex("ComponentDescription"));
                                 String Component = bom_cursor.getString(bom_cursor.getColumnIndex("Component"));
                                 itemlist.add(ComponentDescription);
                                  mappartcode.put(ComponentDescription, Component);

                            } while (bom_cursor.moveToNext());
                            bom_cursor.close();

                        }
                    } else {

                    }
                }


            } catch (Exception e) {
                //    Log.e("LoadNextActivity in SplashActivity", e.toString());
            }
            return null;
        }

        protected void onPostExecute(String v) {

           progressBar.setVisibility(View.GONE);

            ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(CustomerDetailsActivity.this, android.R.layout.simple_spinner_dropdown_item, itemlist);
            spinner.setAdapter(arrayAdapter);
           // spinner.setSelection(0,false);
            spinner.setOnItemSelectedListener(CustomerDetailsActivity.this);

        }
    }

    public static void hideSoftKeyboard(Activity activity) {

        try {

            if (activity != null) {
                InputMethodManager manager = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
                if (manager != null) {
                    manager.hideSoftInputFromWindow(activity.findViewById(android.R.id.content).getWindowToken(), 0);
                }
            }
        }
        catch (Exception e){

            e.printStackTrace();


        }

    }

    DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {

        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear,
                              int dayOfMonth) {
            // TODO Auto-generated method stub
            myCalendar.set(Calendar.YEAR, year);
            myCalendar.set(Calendar.MONTH, monthOfYear);
            myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            updateLabel();
        }

    };

    private void updateLabel() {
        String myFormat = "dd-MMM-yyyy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);


        if (datestatus.equals("doi")) {

            tv_DOI.setText(sdf.format(myCalendar.getTime()));
            errorDetails.Errorlog(CustomerDetailsActivity.this,"Change%20DOI%20Data", TAG,"Product%20Tab",tv_DOI.getText().toString(),mobile_no,TicketNo,"U",mobile_details,dbversion,tss);
            String dataformet="yyyyMMdd";
            SimpleDateFormat dateFormats=new SimpleDateFormat(dataformet,Locale.ENGLISH);

            DOI= dateFormats.format(myCalendar.getTime());

        }
        else if(datestatus.equals("redate")){

            tv_select_date.setText(sdf.format(myCalendar.getTime()));

            errorDetails.Errorlog(CustomerDetailsActivity.this,"Change%20Re_scheduled%20Date", TAG,"Status%20Tab",tv_select_date.getText().toString(),mobile_no,TicketNo,"U",mobile_details,dbversion,tss);

            String dataformet="yyyyMMdd";
            SimpleDateFormat dateFormat=new SimpleDateFormat(dataformet,Locale.ENGLISH);

            sdate= dateFormat.format(myCalendar.getTime());

            ll_select_time.setClickable(true);

        }

        else if(datestatus.equals("icrdate")){

            tv_icr_date.setText(sdf.format(myCalendar.getTime()));

            errorDetails.Errorlog(CustomerDetailsActivity.this,"Change%20ICR%20Date", TAG,"Status%20Tab",tv_icr_date.getText().toString(),mobile_no,TicketNo,"U",mobile_details,dbversion,tss);
            String dataformet="yyyyMMdd";
            SimpleDateFormat dateFormat=new SimpleDateFormat(dataformet,Locale.ENGLISH);
            st_icr_date= dateFormat.format(myCalendar.getTime());

        }
            else if(datestatus.equals("dop")){

            tv_DOP.setText(sdf.format(myCalendar.getTime()));

            errorDetails.Errorlog(CustomerDetailsActivity.this,"Change%20DOP%20Date", TAG,"Product%20Tab",tv_DOP.getText().toString(),mobile_no,TicketNo,"U",mobile_details,dbversion,tss);
            String dataformet="yyyyMMdd";
            SimpleDateFormat dateFormats=new SimpleDateFormat(dataformet,Locale.ENGLISH);
            DOP= dateFormats.format(myCalendar.getTime());

        }

    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {

            case (SCAN_ESS_NO):

                if (resultCode == RESULT_OK) {

                    if(dbhelper.IS_ess_Component_exits(data.getStringExtra("serialno"))){

                        get_ess_name(data.getStringExtra("serialno"));
                        tv_ess_component.setText(data.getStringExtra("serialno"));
                        errorDetails.Errorlog(CustomerDetailsActivity.this,"Essential%20Scan%20Result", TAG,"Essential%20Found%20In%20List",data.getStringExtra("serialno"),mobile_no,TicketNo,"U",mobile_details,dbversion,tss);

                    }

                    else{
                        errorDetails.Errorlog(CustomerDetailsActivity.this,"Essential%20Scan%20Result", TAG,"Essential%20Not%20Found%20In%20List",data.getStringExtra("serialno"),mobile_no,TicketNo,"E",mobile_details,dbversion,tss);
                        showerror("Essential Not Found");

                    }
                }
                break;

            case (SCANSERIALNO):

                if (resultCode == RESULT_OK) {
                    String no = data.getStringExtra("serialno");

                    try {

                        if (checkSerialNo(no)) {
                            System.out.println(no);
                            tv_SerialNo.setText(no);
                            serialno_scan = no;
                            SerialNo = no;

                            if (CheckConnectivity.getInstance(this).isOnline()) {
                                new AsyncFindmodel(CustomerDetailsActivity.this, this).execute("");

                            }

                            errorDetails.Errorlog(CustomerDetailsActivity.this, "Serial%20No%20Scan%20Result", TAG, "Serial%20No", no, mobile_no, TicketNo, "U", mobile_details, dbversion, tss);

                        } else {
                            errorDetails.Errorlog(CustomerDetailsActivity.this, "Serial%20No%20Scan%20Result", TAG, "Serial%20No%20Error", no, mobile_no, TicketNo, "E", mobile_details, dbversion, tss);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                break;
            case (PICK_CONTACT):
                if (resultCode == RESULT_OK) {
                    Uri uri = data.getData();
                    String[] projection = { ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME };

                    Cursor cursor = getContentResolver().query(uri, projection,
                            null, null, null);
                    cursor.moveToFirst();
                    int numberColumnIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
                    String numbe = cursor.getString(numberColumnIndex);

                    int nameColumnIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);
                    String name = cursor.getString(nameColumnIndex);

                    String number=numbe.replace(" ","");
                    Log.d(TAG, "ZZZ number : " + number +" , name : "+name);
                     String lastten;
                            if (number.length() > 10 || number.length() == 10)
                            {
                                lastten = number.substring(number.length() - 10);
                                et_contact.setText(lastten);
                            }
                            else{

                                showerror("Invaid Mobile No !");

                              //  Toast.makeText(this, "Invaid Mobile No", Toast.LENGTH_SHORT).show();
                            }

                }
                break;
            case ODU_NO:

                if (resultCode == RESULT_OK) {
                        String odu_no = data.getStringExtra("serialno");
                        if (checkSerialNo(odu_no)) {
                            System.out.println(odu_no);
                            tv_odu_ser_no.setText(odu_no);

                            oduserno = odu_no;

                            errorDetails.Errorlog(CustomerDetailsActivity.this, "Odu%20Serial%20No%20Change", TAG, "Product%20TAB", "Scan%20Odu%20No%20"+odu_no, mobile_no, TicketNo, "U", mobile_details, dbversion, tss);

                        } else {
                            errorDetails.Errorlog(CustomerDetailsActivity.this, "Odu%20Serial%20No%20Scan%20Result", TAG, "Serail%20No%20Error", "Scan%20Odu%20No%20"+odu_no, mobile_no, TicketNo, "E", mobile_details, dbversion, tss);

                            showerror("Serial No Always 18 digit !");
                          //  Toast.makeText(this, "Seral no Always 18 digit !", Toast.LENGTH_SHORT).show();
                        }

                    }
                    break;

            case SCAN_PART:

                if (resultCode == RESULT_OK) {

                    if ( dbhelper.IS_Component_exits(data.getStringExtra("serialno"))){

                        getSinglepartdetails(data.getStringExtra("serialno"));
                        errorDetails.Errorlog(CustomerDetailsActivity.this,"Spare%20Item%20Scan%20Result", TAG,"Serial%20No%20%20"+data.getStringExtra("serialno"),"Spare%20Found%20In%20List",mobile_no,TicketNo,"U",mobile_details,dbversion,tss);
                    }

                    else{
                        errorDetails.Errorlog(CustomerDetailsActivity.this,"Spare%20Item%20Scan%20Result", TAG,"Serial%20No%20%20"+data.getStringExtra("serialno"),"PartCode%20Not%20Found",mobile_no,TicketNo,"E",mobile_details,dbversion,tss);

                        showerror("Spare Not Found In List");
                    }
                }
                break;

            case INVOICE_IMAGE_CAPTURE:
               if (resultCode == Activity.RESULT_OK) {
                    Uri uri = data.getParcelableExtra("path");
                    try {


                        Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), uri);
                        // Bitmap converetdImage = getResizedBitmap(bitmap, 80);

                        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                        bitmap.compress(Bitmap.CompressFormat.PNG, 80, byteArrayOutputStream);
                        invoice_image_data= byteArrayOutputStream.toByteArray();
                        errorDetails.Errorlog(CustomerDetailsActivity.this,"INVOICE_IMAGE_CAPTURE", TAG,"INVOICE_IMAGE_CAPTURE","INVOICE_IMAGE_CAPTURE",mobile_no,TicketNo,"C",mobile_details,dbversion,tss);


                        view_invioce.setImageBitmap(bitmap);

                        invioceurl="";

                        imagestatus=true;


                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                break;

            case SERIALNO_IMAGE_CAPTURE:
                if (resultCode == Activity.RESULT_OK) {
                    Uri uri = data.getParcelableExtra("path");
                    try {
                        // You can update this bitmap to your server
                        Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), uri);
                       // Bitmap converetdImage = getResizedBitmap(bitmap, 80);

                        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                        bitmap.compress(Bitmap.CompressFormat.PNG, 80, byteArrayOutputStream);
                        seraialno_image_data= byteArrayOutputStream.toByteArray();
                        imagestatus=true;
                        errorDetails.Errorlog(CustomerDetailsActivity.this,"SERIALNO_IMAGE_CAPTURE", TAG,"SERIALNO_IMAGE_CAPTURE","SERIALNO_IMAGE_CAPTURE",mobile_no,TicketNo,"C",mobile_details,dbversion,tss);

                        serialnourl="";
                        view_serialno.setImageBitmap(bitmap);

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                break;

            case ODU_SERIALNO_IMAGE_CAPTURE:
                if (resultCode == Activity.RESULT_OK) {
                    Uri uri = data.getParcelableExtra("path");
                    try {
                        // You can update this bitmap to your server
                        Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), uri);
                       // Bitmap converetdImage = getResizedBitmap(bitmap, 80);
                        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                        bitmap.compress(Bitmap.CompressFormat.PNG, 80, byteArrayOutputStream);
                        oduserialno_image_data= byteArrayOutputStream.toByteArray();
                        view_oduserialno.setImageBitmap(bitmap);
                        imagestatus=true;
                        errorDetails.Errorlog(CustomerDetailsActivity.this,"ODU_SERIALNO_IMAGE_CAPTURE", TAG,"ODU_SERIALNO_IMAGE_CAPTURE","ODU_SERIALNO_IMAGE",mobile_no,TicketNo,"C",mobile_details,dbversion,tss);

                        oduurl="";

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                break;

            case CUSTOMER_SIGNATURE:

                if (resultCode == Activity.RESULT_OK){
                    String signpath = data.getStringExtra("signpath");

                    if (!signpath.equals("")){

                        try{
                            Bitmap bitmap = BitmapFactory.decodeFile(signpath);
                          //  customer_sign_bitmap= BitmapFactory.decodeFile(signpath);
                            iv_customersign.setImageBitmap(bitmap);
                            iv_customersign.setVisibility(View.VISIBLE);
                            imagestatus=true;
                            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                            bitmap.compress(Bitmap.CompressFormat.PNG, 80, byteArrayOutputStream);
                            customersign_data= byteArrayOutputStream.toByteArray();

                        }catch (Exception e){
                           e.printStackTrace();
                        }

                    }

                }

                break;
            }
    }

    @Override
    protected void onStart() {
        super.onStart();

    }

    public void  getremarkdata(String CallType){

        if (CheckConnectivity.getInstance(this).isOnline()) {

            if (CallType.equals("SERVICE CALL")) {
                remarkurl = AllUrl.baseUrl + "Reasons/pendingReasons?pendingReasone.CodeGroup=ZSER07";
            } else if (CallType.equals("MANDATORY CALLS")) {
                remarkurl = AllUrl.baseUrl + "Reasons/pendingReasons?pendingReasone.CodeGroup=ZMAN07";
            } else if (CallType.equals("COURTESY VISIT")) {
                remarkurl = AllUrl.baseUrl + "Reasons/pendingReasons?pendingReasone.CodeGroup=ZFOC07";
            } else if (CallType.equals("INSTALLATION CALL")) {
                remarkurl = AllUrl.baseUrl + "Reasons/pendingReasons?pendingReasone.CodeGroup=ZINT07";
            } else if (CallType.equals("DEALER DEFECTIVE REQUEST")) {
                remarkurl = AllUrl.baseUrl + "Reasons/pendingReasons?pendingReasone.CodeGroup=ZDD07";
            } else if (CallType.equals("REINSTALLLATION ORDER")) {
                remarkurl = AllUrl.baseUrl + "Reasons/pendingReasons?pendingReasone.CodeGroup=ZRIN07";
            } else if (CallType.equals("REWORK ORDER")) {
                remarkurl = AllUrl.baseUrl + "Reasons/pendingReasons?pendingReasone.CodeGroup=ZREW07";
            }

           progressBar.setVisibility(View.VISIBLE);
            RequestQueue queue = Volley.newRequestQueue(this);

            StringRequest stringRequest = new StringRequest(Request.Method.GET, remarkurl,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            //   System.out.println("remark-->"+response);
                           progressBar.setVisibility(View.GONE);

                            try {
                                JSONArray jsonArray = new JSONArray(response);
                                remarklist = new ArrayList<>();

//                            remarklist.add("select pending cause");
                                remarkmap = new HashMap<>();

                                for (int i = 0; i < jsonArray.length(); i++) {

                                    JSONObject rmobj = jsonArray.getJSONObject(i);
                                    CodeGroup = rmobj.getString("CodeGroup");
                                    String Code = rmobj.getString("Code");
                                    String Reason = rmobj.getString("Reason");

                                    remarklist.add(Reason);
                                    remarkmap.put(Reason, Code);
                                }
                                ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(CustomerDetailsActivity.this, android.R.layout.simple_spinner_dropdown_item, remarklist);
                                spnr_remark.setAdapter(arrayAdapter);
                                // spnr_remark.setSelection(0,false);
                                spnr_remark.setOnItemSelectedListener(CustomerDetailsActivity.this);

                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                   progressBar.setVisibility(View.GONE);
                }
            });

// Add the request to the RequestQueue.
            queue.add(stringRequest);

        }
        else {

            get_offline_pendingReasons(CallType);
            System.out.println("Offline pending reason");

        }
    }

    public void checkproduct(){

        try{
            if(machine_name.equals("Select Machine")){

                showerror("Select Machine");

            }

            else if(product_name.equals("Select product")){

                showerror("Select Product");
            }
            else{

                if (aSwitch.isChecked()){
                    years="> 5";
                }

                else {

                    years = "< 5";
                }
                    add_product_model = new Add_Product_Model();
                    add_product_model.setMachine(machine_name);
                    add_product_model.setProduct(product_name);
                    add_product_model.setYear(years);
                    add_product_models.add(add_product_model);
                    addProductadapter = new AddProductadapter(add_product_models, CustomerDetailsActivity.this);
                    addProductadapter.notifyDataSetChanged();
                    lv_product.setAdapter(addProductadapter);
                    lv_product.setSelection(addProductadapter.getCount() - 1);

            }

        }catch (Exception e){
            e.printStackTrace();

        }

    }

    @Override
    public void onClick(View v) {

        switch (v.getId()){
            case R.id.ll_select_date:
                choose_re_date();
                errorDetails.Errorlog(CustomerDetailsActivity.this,"Click%20On%20Resedule%20Date%20Icon", TAG,"Status%20Tab","Status%20Tab",mobile_no,TicketNo,"C",mobile_details,dbversion,tss);

                break;
            case R.id.ll_select_time:
                choose_time();
                errorDetails.Errorlog(CustomerDetailsActivity.this,"Click%20On%20Resedule%20Time%20Icon", TAG,"Status%20Tab","Status%20Tab",mobile_no,TicketNo,"C",mobile_details,dbversion,tss);

                break;
            case R.id.tv_quentity:
                showNumberPicker(v);
                errorDetails.Errorlog(CustomerDetailsActivity.this,"Click%20On%20Spare%20Quantity", TAG,"Spare%20Tab","Spare%20Tab",mobile_no,TicketNo,"C",mobile_details,dbversion,tss);

                break;

            case  R.id.ll_scan_part:
                ScanPart();
                errorDetails.Errorlog(CustomerDetailsActivity.this,"Click%20On%20Scan%20SpareItem%20Icon", TAG,"Spare%20Tab","For%20Scan%20Spare%Item",mobile_no,TicketNo,"C",mobile_details,dbversion,tss);

                break;

            case R.id.ll_icr_date:
                choose_icr_date();
              //  All_click.add("Click%20On%20ICRDate");
                errorDetails.Errorlog(CustomerDetailsActivity.this,"Click%20On%20ICR%20Date%20Icon", TAG,"Status%20Tab","Status%20Tab",mobile_no,TicketNo,"C",mobile_details,dbversion,tss);

                break;

//            case R.id.iv_whatsapp:
//                callwhatsapp();
//                break;
            case R.id.ll_customer:

                ActiveCustomerTab();
            //    All_click.add("Click%20On%20CustomerTab");
                errorDetails.Errorlog(CustomerDetailsActivity.this,"Click%20On%20CustomerTab", TAG,"Customer%20Tab","Customer%20Tab",mobile_no,TicketNo,"C",mobile_details,dbversion,tss);


                break;
            case R.id.ll_spare:
                ActiveSpareTab();
                errorDetails.Errorlog(CustomerDetailsActivity.this,"Click%20On%20SpareTab", TAG,"Spare%20Tab","Spare%20Tab",mobile_no,TicketNo,"C",mobile_details,dbversion,tss);

                break;
            case R.id.ll_sales:

                ActiveNotesPage();

                errorDetails.Errorlog(CustomerDetailsActivity.this,"Click%20On%20Notes%20Tab", TAG,"Notes%20Tab","Notes%20Tab",mobile_no,TicketNo,"C",mobile_details,dbversion,tss);


                 break;
            case R.id.ll_essential:
                ActiveEssTab();

                errorDetails.Errorlog(CustomerDetailsActivity.this,"Click%20On%20Essential%20Tab", TAG,"Essential%20Tab","Essential%20Tab",mobile_no,TicketNo,"C",mobile_details,dbversion,tss);

                break;

            case R.id.ll_status:

                errorDetails.Errorlog(CustomerDetailsActivity.this,"Click%20On%20StatusTab", TAG,"Click%20On%20StatusTab","Click%20On%20StatusTab",mobile_no,TicketNo,"C",mobile_details,dbversion,tss);
                ActiveStatusPage();
                break;

            case R.id.ll_machine:

                ActiveProductTab();
                errorDetails.Errorlog(CustomerDetailsActivity.this,"Click%20On%20MachineTab", TAG,"Machine%20Tab","Machine%20Tab",mobile_no,TicketNo,"C",mobile_details,dbversion,tss);
                break;

//            case R.id.btnclear:
 //               clear_Signature();
//                errorDetails.Errorlog(CustomerDetailsActivity.this,"Click%20On%20Customer%20Signature%20Clear%20Button", TAG,"Status%20Tab","Status%20Tab",mobile_no,TicketNo,"C",mobile_details,dbversion,tss);
//
//                break;
            case R.id.ll_scan_ess:

                errorDetails.Errorlog(CustomerDetailsActivity.this,"Click%20On%20Scan%20Essential%20Icon", TAG,"Essential%20Tab","Essential%20Tab",mobile_no,TicketNo,"C",mobile_details,dbversion,tss);
                scan_essential();

                break;
            case R.id.btn_status:

                errorDetails.Errorlog(CustomerDetailsActivity.this,"Click%20On%20Submit%20Button", TAG,"Status%20Tab","Status%20Tab",mobile_no,TicketNo,"C",mobile_details,dbversion,tss);

                submit_Value();

                break;
            case R.id.ll_add_part:

                add_part();
                errorDetails.Errorlog(CustomerDetailsActivity.this,"Click%20On%20Add%20Spare%20Icon", TAG,"Spare%20Tab","Spare%20Tab",mobile_no,TicketNo,"C",mobile_details,dbversion,tss);
                break;
            case R.id.iv_doi:

                errorDetails.Errorlog(CustomerDetailsActivity.this,"Click%20On%20Doi%20Date%20Icon", TAG,"Product%20Tab","Product%20Tab",mobile_no,TicketNo,"C",mobile_details,dbversion,tss);

                update_doi();

                break;
            case R.id.iv_dop:
                errorDetails.Errorlog(CustomerDetailsActivity.this,"Click%20On%20Dop%20Date%20Icon", TAG,"Product%20Tab","Product%20Tab",mobile_no,TicketNo,"C",mobile_details,dbversion,tss);
                update_dop();

                break;
            case R.id.tv_ess_quentity:

                errorDetails.Errorlog(CustomerDetailsActivity.this,"Click%20On%20Essential%20Quantity", TAG,"Essential%20Tab","Essential%20Tab",mobile_no,TicketNo,"C",mobile_details,dbversion,tss);
                update_ess_quantity(v);
                break;

            case R.id.ll_add_ess:

                errorDetails.Errorlog(CustomerDetailsActivity.this,"Click%20On%20Add%20Essential%20Icon", TAG,"Essential%20Tab","Essential%20Tab",mobile_no,TicketNo,"C",mobile_details,dbversion,tss);
                add_ess();
                break;
            case R.id.btn_scan_serial_no:

                errorDetails.Errorlog(CustomerDetailsActivity.this,"Click%20On%20Product%20SerialNo%20Scan%20Icon", TAG,"Product%20Tab","Product%20Tab",mobile_no,TicketNo,"C",mobile_details,dbversion,tss);
                scan_serialNo();
                break;

            case R.id.btn_openmap:

                openGoolgemap();
                errorDetails.Errorlog(CustomerDetailsActivity.this,"Click%20On%20Get%20Direction%20Button", TAG,"Customer%20Tab","For%20Open%20Google%20Map",mobile_no,TicketNo,"C",mobile_details,dbversion,tss);
                break;

            case R.id.ll_add_details:
                errorDetails.Errorlog(CustomerDetailsActivity.this,"Click%20On%20Add%20Customer%20Details%20Add%20Icon", TAG,"Notes%20Tab","For%20Add%20Customer%20Details",mobile_no,TicketNo,"C",mobile_details,dbversion,tss);
                checkproduct();

                break;
            case R.id.btn_scan_odu_serial_no:
                errorDetails.Errorlog(CustomerDetailsActivity.this,"Click%20On%20Scan%20Odu%20SertialNo%20%20Icon", TAG,"Notes%20Tab","For%20Add%20Customer%20Details",mobile_no,TicketNo,"C",mobile_details,dbversion,tss);
                scanoduno();
                break;
            case R.id.lv_camera_invioce:
                launchCameraIntent("invoice");
                errorDetails.Errorlog(CustomerDetailsActivity.this,"Click%20On%20Camera%20Invoice%20Icon", TAG,"Product%20Tab","Take%20Invioce%20Picture",mobile_no,TicketNo,"C",mobile_details,dbversion,tss);

                break;
            case R.id.lv_camera_serialno:
                launchCameraIntent("serialno");
                errorDetails.Errorlog(CustomerDetailsActivity.this,"Click%20On%20Camera%20Serialno%20Icon", TAG,"Product%20Tab","Take%20Serial%20No%20Picture",mobile_no,TicketNo,"C",mobile_details,dbversion,tss);

                break;
            case R.id.lv_camera_oduserialno:
                launchCameraIntent("oduserialno");
                errorDetails.Errorlog(CustomerDetailsActivity.this,"Click%20On%20Camera%20Odu%20Serialno%20Icon", TAG,"Product%20Tab","Take%20Odu%20Serial%No%20Picture",mobile_no,TicketNo,"C",mobile_details,dbversion,tss);
                break;

            case R.id.iv_message:
                send_sms_to_customer();
                errorDetails.Errorlog(CustomerDetailsActivity.this,"Click%20On%20Message%20Icon", TAG,"Header_Section","Click%20On%20Message",mobile_no,TicketNo,"C",mobile_details,dbversion,tss);
                break;

            case  R.id.view_invioce:
                view_image("invioce");
                errorDetails.Errorlog(CustomerDetailsActivity.this,"Click%20On%20View%20Invioce%20Image", TAG,"view_Invoice","view_Invoice",mobile_no,TicketNo,"C",mobile_details,dbversion,tss);

                break;

            case R.id.view_oduserialno:
                view_image("oduserialno");
                errorDetails.Errorlog(CustomerDetailsActivity.this,"Click%20On%20View%20ODU%20SerialNo%20Image", TAG,"view_oduserialno","view_oduserialno",mobile_no,TicketNo,"C",mobile_details,dbversion,tss);

                break;

            case R.id.view_serialno:
                view_image("serialno");
                errorDetails.Errorlog(CustomerDetailsActivity.this,"Click%20On%20view_serialno", TAG,"view_serialno","view_serialno",mobile_no,TicketNo,"C",mobile_details,dbversion,tss);

                break;

            case R.id.btn_updateaddress:
                startActivity(new Intent(CustomerDetailsActivity.this,UpdateAddress.class));
                break;
            case R.id.img_exchange:
                startActivity(new Intent(CustomerDetailsActivity.this, ExchangeMain.class));
                break;

            case R.id.tv_custsign:
                lunchSignIntent();
                break;

            case R.id.lv_custsign:
                lunchSignIntent();
                break;


        }
    }

    public void send_sms_to_customer(){

    }

    public void choose_re_date(){

        datestatus = "redate";
        DatePickerDialog datePickerDialog = new DatePickerDialog(CustomerDetailsActivity.this, date, myCalendar
                .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                myCalendar.get(Calendar.DAY_OF_MONTH));

        datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis());
        datePickerDialog.show();
    }

    public void choose_icr_date(){
        datestatus = "icrdate";
        DatePickerDialog datePickerDialog = new DatePickerDialog(CustomerDetailsActivity.this, date, myCalendar
                .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                myCalendar.get(Calendar.DAY_OF_MONTH));

        //following line to restrict future date selection
        datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis());
        // datePickerDialog.getDatePicker().setMinDate();
        datePickerDialog.show();

    }

    public void choose_time(){

        Calendar mcurrentTime = Calendar.getInstance();
        int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
        int minute = mcurrentTime.get(Calendar.MINUTE);

        TimePickerDialog mTimePicker;
        mTimePicker = new TimePickerDialog(CustomerDetailsActivity.this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {


                try{

                    String minut,hours;

                    if (selectedHour < 10){

                        hours="0"+selectedHour;
                    }
                    else
                    {
                        hours=""+selectedHour;
                    }
                    if (selectedMinute < 10){

                        minut="0"+selectedMinute;
                    }
                    else
                    {
                        minut=""+selectedMinute;
                    }

                    stime=hours+""+minut+"00";

                    errorDetails.Errorlog(CustomerDetailsActivity.this,"Click%20On%20Re_scheduled%20Time", TAG,"Status%20Tab",stime,mobile_no,TicketNo,"U",mobile_details,dbversion,tss);


                    tv_select_time.setText( hours + ":" + minut);



                //    All_click.add("Select%20Re_scheduled%20Time"+hours + ":" + minut);
                }
                catch (Exception e){

                    e.printStackTrace();
                }

            }
        }, hour, minute, true);//Yes 24 hour time
        mTimePicker.setTitle("Select Time");
        mTimePicker.show();
    }

    public void getpendingdata(){

        if ( CheckConnectivity.getInstance(this).isOnline()) {

           progressBar.setVisibility(View.VISIBLE);
            RequestQueue queue = Volley.newRequestQueue(this);
          //  String url= AllUrl.baseUrl+"spares/getspare?spareaccadd.Ticketno=2002374814&spareaccadd.Status=Pending&spareaccadd.ItemType=ZACC";
            String url=AllUrl.baseUrl+"spares/getspare?spareaccadd.Ticketno="+TicketNo;
            StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {


                            try {

                                JSONObject object=new JSONObject(response);

                                String status=object.getString("Status");
                                if (status.equals("true")){
                                   // JSONArray jsonArray=new JSONArray(response);
                                    JSONArray jsonArray = object.getJSONArray("Data");
                                  //  System.out.println(jsonArray.toString());

                                    for (int i = 0; i < jsonArray.length(); i++) {

                                        JSONObject essobj = jsonArray.getJSONObject(i);
                                        pendingSpare=new PendingSpare();

                                        if (essobj.getString("ItemType").equals("ZSPP"))

                                        {

                                            pendingSpare.setItemType(essobj.getString("ItemType"));
                                            pendingSpare.setStatus(essobj.getString("Status"));
                                            pendingSpare.setItemno(essobj.getString("itemno"));
                                            pendingSpare.setETA(essobj.getString("ETA"));
                                            pendingSpare.setPartCode(essobj.getString("PartCode"));
                                            pendingSpare.setPartName(essobj.getString("PartName"));
                                            pendingSpare.setQty(essobj.getString("Qty"));
                                            pendingSpare.setFlags("U");
                                            String penflag=essobj.getString("pending_fla");
                                            if (penflag.equals("N") ){
                                                pendingSpare.setPending_fla("No");
                                            }
                                            else if(penflag.equals("X")){

                                                pendingSpare.setPending_fla("Yes");
                                            }
                                            else if (penflag.equals("")){

                                                pendingSpare.setPending_fla("No");
                                            }

                                            pendingSpares.add(pendingSpare);

                                        }

                                        else {

                                            essential_add_model=new Essential_add_model();
                                            essential_add_model.setEname(essobj.getString("EssName")+""+essobj.getString("AccName"));
                                            essential_add_model.setEcode(essobj.getString("EssCode")+""+essobj.getString("AccCode"));
                                            essential_add_model.setEquentity(essobj.getString("Qty"));
                                            essential_add_model.setItemtype(essobj.getString("ItemType"));
                                            essential_add_model.setFlag("U");
                                            essential_add_models.add(essential_add_model);

                                        }
                                    }


                                    essential_add_adapter = new Essential_add_adapter(essential_add_models, CustomerDetailsActivity.this);
                                    essential_add_adapter.notifyDataSetChanged();
                                    lv_ess_add_item.setAdapter(essential_add_adapter);


                                    Pending_item_adapter pending_item_adapter=new Pending_item_adapter(pendingSpares,CustomerDetailsActivity.this);
                                    pending_item_adapter.notifyDataSetChanged();
                                    lv_pending_item.setAdapter(pending_item_adapter);

                                }


                            } catch (Exception e) {
                                e.printStackTrace();


                            }

                            progressBar.setVisibility(View.GONE);
                        }

                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                }
            });

            queue.add(stringRequest);

        } else {

          //  Toast.makeText(this, "Ooops! Internet Connection Error", Toast.LENGTH_SHORT).show();
        }

    }

    public String Parsedate(String time){
        String inputPattern = "dd-MMM-yyyy";
        String outputPattern = "yyyyMMdd";
        SimpleDateFormat inputFormat = new SimpleDateFormat(inputPattern,Locale.ENGLISH);
        SimpleDateFormat outputFormat = new SimpleDateFormat(outputPattern,Locale.ENGLISH);
        Date date = null;
        String str = null;
        try {
            date = inputFormat.parse(time);
            str = outputFormat.format(date);
           // System.out.println(str);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return  str;
    }

    public String Parsedates(String time){

     //   1\/1\/1900 12:00:00 AM
        String inputPattern = "dd/MM/yyyy hh:mm:ss a";
        String outputPattern = "yyyyMMdd";
        SimpleDateFormat inputFormat = new SimpleDateFormat(inputPattern,Locale.ENGLISH);
        SimpleDateFormat outputFormat = new SimpleDateFormat(outputPattern,Locale.ENGLISH);
        Date date = null;
        String str = null;
        try {
            date = inputFormat.parse(time);
            str = outputFormat.format(date);
          //  System.out.println(str);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return  str;
    }

    public void ScanPart() {

        Intent i = new Intent(CustomerDetailsActivity.this, FullScannerActivity.class);
        startActivityForResult(i, SCAN_PART);
    }

    public void updateicrlayout(){

        et_icr_no.setVisibility(View.VISIBLE);
        ll_icr_date.setVisibility(View.VISIBLE);

    }

    public String getbrand(String brand){

        String brandcode;
        brandcode = map_machine.get(brand);
       // System.out.println(brandcode);
        return brandcode;
    }

    public String getyear(String gyear){

        String yearcode;

        if(gyear.equals("> 5")){
            yearcode="X";
        }
        else
        {
            yearcode="";
        }
        return yearcode;
     }

    public String getresi(String types){

        String resicode;

        resicode=map_residence.get(types);

        return resicode;
    }

    public void  callwhatsapp(){

        String wno=et_contact.getText().toString();

        if(wno.length()==10){

            String contact = "+91 "+wno; // use country code with your phone number
            String url = "https://api.whatsapp.com/send?phone=" + contact;
            try {
                PackageManager pm = getPackageManager();
                pm.getPackageInfo("com.whatsapp", PackageManager.GET_ACTIVITIES);
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            } catch (PackageManager.NameNotFoundException e) {
               // Toast.makeText(CustomerDetailsActivity.this, "Whatsapp app not installed in your phone", Toast.LENGTH_SHORT).show();

                showerror("Whatsapp app not installed in your phone");
                e.printStackTrace();
            }

        }
        else{

            showerror("Please Enter valid Mobile No");
          //  Toast.makeText(this, "Please Enter valid Mobile No", Toast.LENGTH_SHORT).show();
        }
   }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.productdetailsmenu, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_video_call) {
            openpopup();
           // startActivity(new Intent(CustomerDetailsActivity.this, ContactlistActivity.class));
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void  openpopup(){

        final Dialog dialog = new Dialog(CustomerDetailsActivity.this);

        dialog.setContentView(R.layout.videocalldialog);
        // Set dialog title
        dialog.setTitle("Whatsapp Call");

        et_contact=dialog.findViewById(R.id.vdialog_et_mobile);
        ImageView iv_no=dialog.findViewById(R.id.vdialog_iv_getcontact);
        Button btn_call=dialog.findViewById(R.id.vdialog_btn_call);

        iv_no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Uri uri = Uri.parse("content://contacts");
                Intent intent = new Intent(Intent.ACTION_PICK, uri);
                intent.setType(ContactsContract.CommonDataKinds.Phone.CONTENT_TYPE);
                startActivityForResult(intent, PICK_CONTACT);

            }
        });

       dialog.show();

       btn_call.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               callwhatsapp();
           }
       });


    }

    public String processtype(String ptype){

        String processtype="";

        switch (ptype){

            case "SERVICE CALL":
                processtype="ZSER";
                break;
            case "INSTALLATION CALL":
                processtype="ZINT";
                break;
            case "MANDATORY CALLS":
                processtype="ZMAN";
                break;
            case "REINSTALLLATION ORDER":
                 processtype="ZRIN";
                 break;
            case "COURTESY VISIT":
                processtype="ZFOC";
                break;

            case "DEALER DEFECTIVE REQUEST":
                processtype="ZDD";
                break;
            case "REWORK ORDER" :
                processtype="ZREW";
                break;
             default:
                 break;
        }
        return processtype;
    }

   public boolean check_part_In_List(String partcode){

        long status=0;

        for(int i=0;i< models.size();i++){
            if ( models.get(i).getDescription().equals(partcode)){
                status = 1;

                showerror("Spare Already Added");

             //   alert.showDialog(CustomerDetailsActivity.this, "Alert", "Spare Already Added Please Change Quantity");

                break;
            }
        }

        for (int j=0;j< pendingSpares.size();j++){

            if ( pendingSpares.get(j).getPartCode().equals(partcode)){

                if (pendingSpares.get(j).getFlags().equals("D")){

                }
                else {

                    status = 1;

                    showerror("Please Click on Delete Icon Then Add Same Spare");
                  //  alert.showDialog(CustomerDetailsActivity.this,"Alert ","Please Click on Delete Icon Then Add Same Spare");

                }

                break;
            }
        }
        if (status > 0){

            return true;
        }

        return false;
   }

    public boolean checkesscode(String essname){

        long status=0;

        for(int i=0;i< essential_add_models.size();i++){
            if ( essential_add_models.get(i).getEname().equals(essname)){

                status = 1;
                break;
            }
        }
        if (status > 0){

            return true;
        }
        return false;
    }

    public int string_to_int(String Numbers){
        int no=0;
       no= Integer.parseInt(Numbers);

      return no;
    }

    public void getBomdata(String FrCode,String Product,String FGProductg){

        if ( CheckConnectivity.getInstance(this).isOnline()) {

            progressBar.setVisibility(View.VISIBLE);
            RequestQueue queue = Volley.newRequestQueue(this);

           String urls= AllUrl.baseUrl+"bom?bom.FrCode="+FrCode+"&bom.MaterialCategory="+Product+"&bom.FGProduct="+FGProductg;

            System.out.println("Customer page--> get all Spare"+TicketNo+" "+ urls);


            StringRequest stringRequest = new StringRequest(Request.Method.GET, urls,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            try {

                                JSONArray jsonArray=new JSONArray(response);

                                dbhelper.delete_offline_spare_data(FGProductg);
                                dbhelper.insert_offline_spare(Product,FGProductg,FrCode,response,tss);
;
                                dbhelper.deletebom();


                                dbhelper.insert_bom_data("-- select spare --","","","","","","0","0","");

                                for (int i = 0; i < jsonArray.length(); i++) {

                                    JSONObject obj = jsonArray.getJSONObject(i);
                                    Component=obj.getString("Component");
                                    ComponentDescription=obj.getString("ComponentDescription");
                                    FGDescription=obj.getString("FGDescription");
                                    FGProduct=obj.getString("FGProduct");
                                    FrCodes=obj.getString("FrCode");
                                    MaterialCategory=obj.getString("MaterialCategory");
                                    good_stock=obj.getString("good_stock");
                                    refurbished_stock=obj.getString("refurbished_stock");

                                    if (Boolean.valueOf(dbhelper.insert_bom_data(ComponentDescription,Component,FGDescription,FGProduct,FrCodes,MaterialCategory,good_stock,refurbished_stock,tss)).booleanValue())
                                    {

                                    }
                                }

                                new Loadallbom().execute();

                            } catch (Exception e) {
                                e.printStackTrace();

                              //  Errorlog("get_spare",urls,e.getMessage().replace(" ","%20"),tss);
                            }

                            progressBar.setVisibility(View.GONE);
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {


                    progressBar.setVisibility(View.GONE);
                }
            });
// Add the request to the RequestQueue.

            int socketTimeout = 10000; //10 seconds - change to what you want
            RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
            stringRequest.setRetryPolicy(policy);
            queue.add(stringRequest);

        }

        else {

            //Toast.makeText(this, "Ooops! Internet Connection Error", Toast.LENGTH_SHORT).show();

           // showerror("No internet connection");


            dbhelper.get_offline_spare_data(FGProductg);

            String offlinespare=  dbhelper.get_offline_spare_by_fgproduct();

            try {

                JSONArray jsonArray=new JSONArray(offlinespare);

                dbhelper.deletebom();
                dbhelper.insert_bom_data("-- select spare --","","","","","","0","0","");

                for (int i = 0; i < jsonArray.length(); i++) {

                    JSONObject obj = jsonArray.getJSONObject(i);
                    Component=obj.getString("Component");
                    ComponentDescription=obj.getString("ComponentDescription");
                    FGDescription=obj.getString("FGDescription");
                    FGProduct=obj.getString("FGProduct");
                    FrCodes=obj.getString("FrCode");
                    MaterialCategory=obj.getString("MaterialCategory");
                    good_stock=obj.getString("good_stock");
                    refurbished_stock=obj.getString("refurbished_stock");

                    if (Boolean.valueOf(dbhelper.insert_bom_data(ComponentDescription,Component,FGDescription,FGProduct,FrCodes,MaterialCategory,good_stock,refurbished_stock,tss)).booleanValue())
                    {

                    }
                }

                new Loadallbom().execute();

            } catch (Exception e) {
                e.printStackTrace();

            }

        }

    }

    public void add_part_item(String partname,String partcode,String quentity,String flag,String spare_not_found,int stockqty){

        model=new Add_item_model();
        model.setItemname(partname);
        model.setDescription(partcode);
        model.setCount(quentity);
        model.setFlag(flag);
        model.setCheck(spare_not_found);
        model.setStockqty(stockqty);
        models.add(model);
        add_item_adapter = new Add_item_adapter(models, CustomerDetailsActivity.this);
        add_item_adapter.notifyDataSetChanged();
        lv_additem.setAdapter(add_item_adapter);

    }

    public String check_spare_pending(){

            String status="";

            for(int p=0;p<pendingSpares.size();p++){
                try{

                    if (pendingSpares.get(p).getPending_fla().equals("Yes")){
                        status="true";
                        break;
                    }

                }catch(Exception e){

                    e.printStackTrace();
                }

            }

            for(int m=0;m<models.size();m++){

                try{
                if (models.get(m).getCheck().equals("Yes")){
                    status="true";
                    break;
                }

                }catch (Exception e){
                    e.printStackTrace();
                }

            }

            return status;




    }

    public void  get_ess_name(String component){

        try {

              Cursor ess_name_cursor;

                ess_name_cursor = dbhelper.get_ess_Name(component);

                if (ess_name_cursor != null) {

                    if (ess_name_cursor.moveToFirst()) {

                        do {

                            final int recordid = ess_name_cursor.getInt(ess_name_cursor.getColumnIndex("recordid"));
                           // System.out.println("recordid-->" + recordid);
                            String ComponentDescription = ess_name_cursor.getString(ess_name_cursor.getColumnIndex("ComponentDescription"));

                          //  All_click.add("Scan%20Essential%20Name%20"+ComponentDescription);

                            essComponent  =ess_name_cursor.getString(ess_name_cursor.getColumnIndex("Component"));
                            ItemType=ess_name_cursor.getString(ess_name_cursor.getColumnIndex("ItemType"));
                         //   System.out.println(ComponentDescription + "    " +essComponent + "  "+ItemType);
                            tv_ess_component.setText(essComponent);
                            essComponentDescription=ComponentDescription;
                            accessories_stock = ess_name_cursor.getString(ess_name_cursor.getColumnIndex("accessories_stock"));
                            additives_stock =  ess_name_cursor.getString(ess_name_cursor.getColumnIndex("additives_stock"));

                            accstock=string_to_int(accessories_stock);
                            addstock=string_to_int(additives_stock);

                            if (accstock < addstock){
                                tv_ess_sqty.setText(additives_stock);
                                ess_stock=addstock;
                            }
                            else {
                                ess_stock=accstock;
                                tv_ess_sqty.setText(accessories_stock);
                            }

                            int position = -1;
                            position =essspinerlist.indexOf(ComponentDescription);

                            ess_spiner.setSelection(position);

                        } while (ess_name_cursor.moveToNext());

                        ess_name_cursor.close();

                    }
                }


        } catch (Exception e) {
            e.printStackTrace();

           // Errorlog("get%20offline%20essential","Essential%20Tab",e.getMessage().replace(" ","%20"),tss);
        }

    }

    public void showConfirmDialog(Context context,String title,String message) {

        AlertDialog.Builder builder = new AlertDialog.Builder(context, R.style.MyAlertDialogStyle);
        builder.setTitle(title);
        builder.setMessage(message);
        String positiveText = context.getString(android.R.string.ok);
        builder.setPositiveButton(positiveText,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // positive button logic

                        check_delete_spare_list();

                        try{

                          if (imagestatus){

                              uploadImage();
                          }

                        }catch (Exception e){

                            e.printStackTrace();
                        }

                          if (spnr_status.equals("Resolved (soft closure)")) {

                            if (check_spare_pending().equals("true")){

                                showerror("Added Spare is Pending");
                             //   Toast.makeText(CustomerDetailsActivity.this, "Spare pending ", Toast.LENGTH_SHORT).show();
                                errorDetails.Errorlog(CustomerDetailsActivity.this,"Spare%20Pending", TAG,"Spare%20Item%20Pending","Spare%20Pending",mobile_no,TicketNo,"E",mobile_details,dbversion,tss);

                            }

                            else{

                                    try {
                                        work_status="E0008";
                                        createcsv("success",0);
                                    } catch (Exception e) {
                                        e.printStackTrace();


                                    }
                            }
                        }

                        else {

                            work_status="E0007";

                             createcsv("success",0);
                              flagstatus="";
                            // sendsoftclosedata(spnr_status);
                        }
                        dialog.dismiss();
                    }


                });

        String negativeText = context.getString(android.R.string.cancel);
        builder.setNegativeButton(negativeText,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // negative button logic
                        dialog.dismiss();
                        errorDetails.Errorlog(CustomerDetailsActivity.this,"Click%20On%20Alert%20Cancel%20Button", TAG,"Popup%20Close","Popup%20Close",mobile_no,TicketNo,"U",mobile_details,dbversion,tss);

                    }
                });

        AlertDialog dialog = builder.create();
        // display dialog
        dialog.show();
    }

   // ---------------------------  declear all layout --------------------------------------
    public void init() {

        tv_error_message=findViewById(R.id.tv_error_message);
        tv_ess_calculation=findViewById(R.id.tv_ess_calculation);
        ll_ess_cal=findViewById(R.id.ll_ess_cal);
        ll_ess_cal.setVisibility(View.GONE);
        spinner = (SearchableSpinner) findViewById(R.id.spinner);
        lv_additem = (ListView) findViewById(R.id.lv_add_item);
        spnr_remark=findViewById(R.id.spnr_remark);
        ll_details = (LinearLayout) findViewById(R.id.ll_details);
        ll_part = (LinearLayout) findViewById(R.id.ll_part);
        ll_esential = (LinearLayout) findViewById(R.id.ll_esential);
        ll_notes = (LinearLayout) findViewById(R.id.ll_note);
        ll_machine_details = (LinearLayout) findViewById(R.id.ll_machine_details);
        ll_status_details = (LinearLayout) findViewById(R.id.ll_status_details);
        tv_bom_qty=findViewById(R.id.tv_bom_qty);
        ess_tv_shelflife=findViewById(R.id.ess_tv_shelflife);
        tv_addresss = (TextView) findViewById(R.id.tv_addresss);
        iv_iv_priorit = (ImageView) findViewById(R.id.iv_priorit);
        iv_alt_call=findViewById(R.id.iv_alt_call);
        iv_call = findViewById(R.id.iv_call);
        tv_escal=findViewById(R.id.tv_escal);
        tv_problemdescription=findViewById(R.id.tv_problemdescription);
        tv_calltype = (TextView) findViewById(R.id.tv_calltype);
        tv_ticketno = (TextView) findViewById(R.id.tv_ticketno);
        tv_address = (TextView) findViewById(R.id.tv_address);
        tv_callbook = (TextView) findViewById(R.id.tv_callbookdate);
        tv_status = (TextView) findViewById(R.id.tv_status);
        tv_rcnno = (TextView) findViewById(R.id.tv_rcnno);
        tv_servicetype = (TextView) findViewById(R.id.tv_servicetype);
        tv_custname = (TextView) findViewById(R.id.tv_custname);
        tv_TelePhone = (TextView) findViewById(R.id.tv_telePhone);

        tv_pending_status = findViewById(R.id.tv_pending_status);

        tv_sdate=findViewById(R.id.tv_sdate);
        tv_stime=findViewById(R.id.tv_stime);
        tv_ageing=findViewById(R.id.tv_ageing);
        tv_tel=findViewById(R.id.tv_tel);

        btn_openmap=findViewById(R.id.btn_openmap);
        btn_openmap.setOnClickListener(this);

        tv_part_code = findViewById(R.id.tv_part_code);
        tv_quentity = (TextView) findViewById(R.id.tv_quentity);
        tv_quentity.setOnClickListener(this);

        ll_scan_part = findViewById(R.id.ll_scan_part);
        ll_scan_part.setOnClickListener(this);
        //Machine details
        tv_Product = findViewById(R.id.tv_product);
        tv_Model = findViewById(R.id.tv_model);
        tv_SerialNo = findViewById(R.id.tv_serial_no);
        tv_MachinStatus = findViewById(R.id.tv_machine_status);
        tv_DOP = findViewById(R.id.tv_dop);
        tv_DOI = findViewById(R.id.tv_doi);
        ll_amc_view = findViewById(R.id.ll_amc_view);
        tv_amcno=findViewById(R.id.tv_amcno);
        tv_amcdate =findViewById(R.id.tv_amcdate);
        tv_amcduration=findViewById(R.id.tv_amcduration);
        tv_problem_details = findViewById(R.id.tv_problem_details);

        iv_doi = findViewById(R.id.iv_doi);
        iv_doi.setOnClickListener(this);
        iv_dop = findViewById(R.id.iv_dop);
        iv_dop.setOnClickListener(this);
        btn_scan_odu_serial_no=findViewById(R.id.btn_scan_odu_serial_no);
        btn_scan_odu_serial_no.setOnClickListener(this);

        scan_serialno = findViewById(R.id.btn_scan_serial_no);
        scan_serialno.setOnClickListener(this);
        tv_fgproduct=findViewById(R.id.tv_fgproduct);

        // status sction
        tv_icr_date=findViewById(R.id.tv_icr_date);
        et_icr_no=findViewById(R.id.et_icr_no);
        ll_icr_date=findViewById(R.id.ll_icr_date);
        ll_icr_date.setOnClickListener(this);
        snpr_status = findViewById(R.id.spnr_status);
        snpr_status.setOnItemSelectedListener(this);
       // et_status = findViewById(R.id.et_status);
        btn_status = findViewById(R.id.btn_status);
        btn_status.setOnClickListener(this);
        tv_select_date=findViewById(R.id.tv_select_date);
        tv_select_time=findViewById(R.id.tv_select_time);

        ll_select_date=findViewById(R.id.ll_select_date);
        ll_select_date.setOnClickListener(this);
        ll_select_time=findViewById(R.id.ll_select_time);
        ll_select_time.setOnClickListener(this);
        ll_select_time.setClickable(false);
        ll_customer = (LinearLayout) findViewById(R.id.ll_customer);
        ll_customer.setOnClickListener(this);

        ll_spare =findViewById(R.id.ll_spare);
        ll_spare.setOnClickListener(this);

        ll_essential = findViewById(R.id.ll_essential);
        ll_essential.setOnClickListener(this);

        ll_sales = findViewById(R.id.ll_sales);
        ll_sales.setOnClickListener(this);
        ll_machine = findViewById(R.id.ll_machine);
        ll_machine.setOnClickListener(this);
        ll_status =  findViewById(R.id.ll_status);
        ll_status.setOnClickListener(this);

        iv_info = findViewById(R.id.iv_info);
        iv_part =  findViewById(R.id.iv_part);
        iv_ess =  findViewById(R.id.iv_ess);
        iv_note =  findViewById(R.id.iv_note);
        iv_machine = findViewById(R.id.iv_machine);
        iv_status =  findViewById(R.id.iv_status);

        t_cus = (TextView) findViewById(R.id.t_customer);
        t_mach = (TextView) findViewById(R.id.t_machine);
        t_spare = (TextView) findViewById(R.id.t_spare);
        t_essen = (TextView) findViewById(R.id.t_essential);
        t_status = (TextView) findViewById(R.id.t_status);
        t_note = (TextView) findViewById(R.id.t_notes);

        // textView.setTextColor(getResources().getColor(R.color.errorColor));
        t_cus.setTextColor(getResources().getColor(R.color.apptextcolor));
        t_mach.setTextColor(getResources().getColor(R.color.black));
        t_spare.setTextColor(getResources().getColor(R.color.black));
        t_essen.setTextColor(getResources().getColor(R.color.black));
        t_status.setTextColor(getResources().getColor(R.color.black));
        t_note.setTextColor(getResources().getColor(R.color.black));

        iv_info.setBackgroundResource(R.drawable.account_blue);
        iv_part.setBackgroundResource(R.drawable.ic_download_black);
        iv_ess.setBackgroundResource(R.drawable.ic_essential_black);
        iv_note.setBackgroundResource(R.drawable.ic_note_add_black_24dp);
        iv_machine.setBackgroundResource(R.drawable.ic_machine_details);
        iv_status.setBackgroundResource(R.drawable.ic_status_black);

        // tab  view section

        ll_details.setVisibility(View.VISIBLE);
        ll_part.setVisibility(View.GONE);
        ll_esential.setVisibility(View.GONE);
        ll_notes.setVisibility(View.GONE);
        ll_machine_details.setVisibility(View.GONE);
        ll_status_details.setVisibility(View.GONE);
        ll_change=findViewById(R.id.ll_change);
        ll_add_part = findViewById(R.id.ll_add_part);
        ll_add_part.setOnClickListener(this);

        lv_ess_add_item = findViewById(R.id.lv_ess_add_item);
        tv_ess_quentity = findViewById(R.id.tv_ess_quentity);
        tv_ess_quentity.setOnClickListener(this);
        ll_add_ess = findViewById(R.id.ll_add_ess);
        ll_add_ess.setOnClickListener(this);
        ll_add_details=findViewById(R.id.ll_add_details);
        ll_add_details.setOnClickListener(this);
        spnr_product=findViewById(R.id.spnr_product);
        spnr_machine=findViewById(R.id.spnr_machine);
        spnr_member=findViewById(R.id.spnr_member);
        spnr_residence=findViewById(R.id.spnr_residence);
        aSwitch=findViewById(R.id.simpleswitch);
        lv_product=findViewById(R.id.lv_product_list);

        ll_scan_ess = findViewById(R.id.ll_scan_ess);
        ll_scan_ess.setOnClickListener(this);
        ess_spiner = findViewById(R.id.ess_spinner);
        tv_ess_component = findViewById(R.id.tv_ess_component);
        tv_ess_sqty=findViewById(R.id.tv_ess_sqty);

        lv_pending_item=findViewById(R.id.lv_pending_item);
        checkBox=findViewById(R.id.sp_not_found);
        lv_camera_invioce=findViewById(R.id.lv_camera_invioce);
        lv_camera_invioce.setOnClickListener(this);
        tv_odu_ser_no=findViewById(R.id.tv_odu_ser_no);
        view_invioce=findViewById(R.id.view_invioce);
        view_invioce.setOnClickListener(this);

        lv_camera_serialno=findViewById(R.id.lv_camera_serialno);
        lv_camera_serialno.setOnClickListener(this);
        lv_camera_oduserialno=findViewById(R.id.lv_camera_oduserialno);
        lv_camera_oduserialno.setOnClickListener(this);
        view_serialno=findViewById(R.id.view_serialno);
        view_serialno.setOnClickListener(this);
        view_oduserialno=findViewById(R.id.view_oduserialno);
        view_oduserialno.setOnClickListener(this);
        iv_message=findViewById(R.id.iv_message);
        iv_message.setOnClickListener(this);

        ll_serial_no_image=findViewById(R.id.ll_serial_no_image);
        ll_odu_serial_no_image=findViewById(R.id.ll_odu_serial_no_image);
        ll_invioce_no_image=findViewById(R.id.ll_invioce_no_image);
        tv_rating=findViewById(R.id.tv_rating);
        tv_rating_point=findViewById(R.id.tv_rating_point);
        btn_updateaddress=findViewById(R.id.btn_updateaddress);
        btn_updateaddress.setOnClickListener(this);

        ll_medium=findViewById(R.id.ll_medium);
        spnr_ess_value=findViewById(R.id.spnr_ess_value);
        spnr_ess_value.setOnItemSelectedListener(this);


        img_map=findViewById(R.id.img_map);

        //image upload layout


        checkBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (((CheckBox) v).isChecked()) {
                  spare_not_found="X";
                }
            }
        });
        img_exchange=findViewById(R.id.img_exchange);
        img_exchange.setOnClickListener(this);

        tv_sign=findViewById(R.id.tv_custsign);
        tv_sign.setOnClickListener(this);
        lv_custsign=findViewById(R.id.lv_custsign);
        lv_custsign.setOnClickListener(this);
        iv_customersign=findViewById(R.id.imgv_custsign);
        tv_modelname=findViewById(R.id.tv_modelname);

      //  set all value
        update_All_TextBox_Value();

        // add notes section spinner value
        update_notes_Spinner();
        // add value into residence array list
        update_map_residence();
        // add value into machine array list
        update_map_machine();
        // create  member list and add into spinner
        update_Members();

        // get all esstional from localdb or sqlite

        getess();
//       compress no imege value
        new Compressimage().execute();
    }


    //------------------- add residanse value into hasmap residence ---------------------
    public void update_map_residence(){

        map_residence.put("1 BHK","Z1");
        map_residence.put("2 BHK","Z2");
        map_residence.put("3 BHK","Z3");
        map_residence.put("4 BHK","Z4");
        map_residence.put("BUNGLOW","Z5");
    }

    //------------------- add machine value into hasmap machine ---------------------
    public void update_map_machine(){

        map_machine.put("SAMSUNG","Z1");
        map_machine.put("CARRIER","Z10");
        map_machine.put("DAIKIN","Z11");
        map_machine.put("HITACHI","Z12");
        map_machine.put("BLUESTAR","Z13");
        map_machine.put("PHILIPS","Z14");
        map_machine.put("IFB","Z15");
        map_machine.put("OTHERS","Z16");
        map_machine.put("LG","Z2");
        map_machine.put("WHIRLPOOL","Z3");
        map_machine.put("GODREJ","Z4");
        map_machine.put("SONY","Z5");
        map_machine.put("PANASONIC","Z6");
        map_machine.put("HAIER","Z7");
        map_machine.put("BOSCH","Z8");
        map_machine.put("VOLTAS","Z9");
    }


    // ----------------- add member value and member spinner dec ---------------------
    public void update_Members(){

        List memberlist=new ArrayList<Integer>();

        memberlist.add("No. of Members");

        for(int i=0;i<50;i++){

            memberlist.add(Integer.toString(i));
        }

        // add  member list into spinner adapter

        ArrayAdapter member_adapter = new ArrayAdapter(this, R.layout.spinner_item, memberlist);
        member_adapter.setDropDownViewResource(R.layout.spinner_dropdown_item);
        //Setting the ArrayAdapter data on the Spinner
        spnr_member.setAdapter(member_adapter);
        spnr_member.setOnItemSelectedListener(this);

    }


    // -----------------   change layout as per button  click

    public void ActiveCustomerTab(){

        ll_details.setVisibility(View.VISIBLE);
                ll_part.setVisibility(View.GONE);
                ll_esential.setVisibility(View.GONE);
                ll_notes.setVisibility(View.GONE);
                ll_machine_details.setVisibility(View.GONE);
                ll_status_details.setVisibility(View.GONE);

                iv_info.setBackgroundResource(R.drawable.account_blue);
                t_cus.setTextColor(getResources().getColor(R.color.apptextcolor));
                iv_part.setBackgroundResource(R.drawable.ic_download_black);
                iv_ess.setBackgroundResource(R.drawable.ic_essential_black);
                iv_note.setBackgroundResource(R.drawable.ic_note_add_black_24dp);
                iv_machine.setBackgroundResource(R.drawable.ic_machine_details);
                iv_status.setBackgroundResource(R.drawable.ic_status_black);

                t_mach.setTextColor(getResources().getColor(R.color.black));
                t_spare.setTextColor(getResources().getColor(R.color.black));
                t_essen.setTextColor(getResources().getColor(R.color.black));
                t_status.setTextColor(getResources().getColor(R.color.black));
                t_note.setTextColor(getResources().getColor(R.color.black));
                hideSoftKeyboard(CustomerDetailsActivity.this);

    }

    public void ActiveProductTab(){
                iv_machine.setBackgroundResource(R.drawable.ic_machine_blue);
                t_mach.setTextColor(getResources().getColor(R.color.apptextcolor));

                ll_details.setVisibility(View.GONE);
                ll_part.setVisibility(View.GONE);
                ll_esential.setVisibility(View.GONE);
                ll_notes.setVisibility(View.GONE);
                ll_machine_details.setVisibility(View.VISIBLE);
                ll_status_details.setVisibility(View.GONE);

                iv_info.setBackgroundResource(R.drawable.account_circle_black_24dp);
                iv_part.setBackgroundResource(R.drawable.ic_download_black);
                iv_ess.setBackgroundResource(R.drawable.ic_essential_black);
                iv_note.setBackgroundResource(R.drawable.ic_note_add_black_24dp);

                iv_status.setBackgroundResource(R.drawable.ic_status_black);
                t_cus.setTextColor(getResources().getColor(R.color.black));

                t_spare.setTextColor(getResources().getColor(R.color.black));
                t_essen.setTextColor(getResources().getColor(R.color.black));
                t_status.setTextColor(getResources().getColor(R.color.black));
                t_note.setTextColor(getResources().getColor(R.color.black));
                hideSoftKeyboard(CustomerDetailsActivity.this);
    }

    public void ActiveSpareTab(){

                iv_part.setBackgroundResource(R.drawable.ic_download);
                t_spare.setTextColor(getResources().getColor(R.color.apptextcolor));

                ll_details.setVisibility(View.GONE);
                ll_part.setVisibility(View.VISIBLE);
                ll_esential.setVisibility(View.GONE);
                ll_notes.setVisibility(View.GONE);
                ll_machine_details.setVisibility(View.GONE);
                ll_status_details.setVisibility(View.GONE);

                iv_info.setBackgroundResource(R.drawable.account_circle_black_24dp);

                iv_ess.setBackgroundResource(R.drawable.ic_essential_black);
                iv_note.setBackgroundResource(R.drawable.ic_note_add_black_24dp);
                iv_machine.setBackgroundResource(R.drawable.ic_machine_details);
                iv_status.setBackgroundResource(R.drawable.ic_status_black);

                t_cus.setTextColor(getResources().getColor(R.color.black));
                t_mach.setTextColor(getResources().getColor(R.color.black));

                t_essen.setTextColor(getResources().getColor(R.color.black));
                t_status.setTextColor(getResources().getColor(R.color.black));
                t_note.setTextColor(getResources().getColor(R.color.black));

                hideSoftKeyboard(CustomerDetailsActivity.this);


        if (FGProducts.equals("")){

          //  Toast.makeText(this, "Spare List Not Found", Toast.LENGTH_SHORT).show();
            showerror("Spare List Not Found");
        }
    }

    public void ActiveEssTab(){


        ll_details.setVisibility(View.GONE);
                ll_part.setVisibility(View.GONE);
                ll_esential.setVisibility(View.VISIBLE);
                ll_notes.setVisibility(View.GONE);
                ll_machine_details.setVisibility(View.GONE);
                ll_status_details.setVisibility(View.GONE);

                iv_info.setBackgroundResource(R.drawable.account_circle_black_24dp);
                iv_part.setBackgroundResource(R.drawable.ic_download_black);
                iv_ess.setBackgroundResource(R.drawable.ic_essential_blue);
                iv_note.setBackgroundResource(R.drawable.ic_note_add_black_24dp);
                iv_machine.setBackgroundResource(R.drawable.ic_machine_details);
                iv_status.setBackgroundResource(R.drawable.ic_status_black);

                t_cus.setTextColor(getResources().getColor(R.color.black));
                t_mach.setTextColor(getResources().getColor(R.color.black));
                t_spare.setTextColor(getResources().getColor(R.color.black));
                t_essen.setTextColor(getResources().getColor(R.color.apptextcolor));
                t_status.setTextColor(getResources().getColor(R.color.black));
                t_note.setTextColor(getResources().getColor(R.color.black));
                hideSoftKeyboard(CustomerDetailsActivity.this);
    }

    public void ActiveNotesPage(){


                ll_details.setVisibility(View.GONE);
                ll_part.setVisibility(View.GONE);
                ll_esential.setVisibility(View.GONE);
                ll_notes.setVisibility(View.VISIBLE);
                ll_machine_details.setVisibility(View.GONE);
                ll_status_details.setVisibility(View.GONE);

                iv_info.setBackgroundResource(R.drawable.account_circle_black_24dp);
                iv_part.setBackgroundResource(R.drawable.ic_download_black);
                iv_ess.setBackgroundResource(R.drawable.ic_essential_black);
                iv_note.setBackgroundResource(R.drawable.note_add_blue);
                iv_machine.setBackgroundResource(R.drawable.ic_machine_details);
                iv_status.setBackgroundResource(R.drawable.ic_status_black);

                t_cus.setTextColor(getResources().getColor(R.color.black));
                t_mach.setTextColor(getResources().getColor(R.color.black));
                t_spare.setTextColor(getResources().getColor(R.color.black));
                t_essen.setTextColor(getResources().getColor(R.color.black));
                t_status.setTextColor(getResources().getColor(R.color.black));
                t_note.setTextColor(getResources().getColor(R.color.apptextcolor));
                hideSoftKeyboard(CustomerDetailsActivity.this);

    }

    public void ActiveStatusPage(){

                ll_details.setVisibility(View.GONE);
                ll_machine_details.setVisibility(View.GONE);
                ll_status_details.setVisibility(View.VISIBLE);
                ll_part.setVisibility(View.GONE);
                ll_esential.setVisibility(View.GONE);
                ll_notes.setVisibility(View.GONE);

                iv_info.setBackgroundResource(R.drawable.account_circle_black_24dp);
                iv_part.setBackgroundResource(R.drawable.ic_download_black);
                iv_ess.setBackgroundResource(R.drawable.ic_essential_black);
                iv_note.setBackgroundResource(R.drawable.ic_note_add_black_24dp);
                iv_machine.setBackgroundResource(R.drawable.ic_machine_details);
                iv_status.setBackgroundResource(R.drawable.ic_status_blue);

                t_cus.setTextColor(getResources().getColor(R.color.black));
                t_mach.setTextColor(getResources().getColor(R.color.black));
                t_spare.setTextColor(getResources().getColor(R.color.black));
                t_essen.setTextColor(getResources().getColor(R.color.black));
                t_status.setTextColor(getResources().getColor(R.color.apptextcolor));
                t_note.setTextColor(getResources().getColor(R.color.black));

    }


    // update all value in to  layout

    public void update_All_TextBox_Value(){

        try {


            // getting value from share pref
             prefdetails = getSharedPreferences("details", 0);
             ticketdetails = prefdetails.getString("details", "");

             System.out.println(ticketdetails);

            JSONObject object1 = new JSONObject(ticketdetails);

            TicketNo = object1.getString("TicketNo");
            tv_modelname.setText(object1.getString("Model"));
            tv_Model.setText(object1.getString("Model"));

            String exchange= object1.getString("potential_exchange_flag");

            if (exchange.equals("X")){

                img_exchange.setVisibility(View.VISIBLE);
            }
            else {
              // img_exchange.setVisibility(View.VISIBLE);
                img_map.setVisibility(View.VISIBLE);
            }

            All_click.add("TicketNo%20"+TicketNo);
            CallType = object1.getString("CallType");
            Street=object1.getString("Street");
            City=object1.getString("City");
            State=object1.getString("State");
            DOP=Parsedate(object1.getString("DOP"));
            Product=object1.getString("Product");
            SerialNo=object1.getString("serial_no");
            Medium=object1.getString("Medium");

            if(Medium.equals("Phone") || Medium.equals("CSR Portal")  ){

                ll_medium.setVisibility(View.VISIBLE);
            }

            if(DOP.equals("19000101")){
                DOP="00000000";
            }

            DOI=Parsedate(object1.getString("DOI"));

            if(DOI.equals("19000101")){
                DOI="00000000";
            }
            CustomerCode=object1.getString("CustomerCode");

            FGProducts=object1.getString("FGCode");

            tv_fgproduct.setText(FGProducts);

            ChangeDate=object1.getString("ChangeDate");


            // getting spare data using fgproduct name

            if (FGProducts.equals("")){

             //  Toast.makeText(this, "Spare List Not Found", Toast.LENGTH_SHORT).show();
            }
            else{

                // getting spare value
                getBomdata(FrCode,Product,FGProducts);
            }
            // if installation call update layout

            if (CallType.equals("INSTALLATION CALL")){
              scan_serialno.setVisibility(View.VISIBLE);
              iv_dop.setVisibility(View.VISIBLE);
              iv_doi.setVisibility(View.VISIBLE);




              // if installation call is ac update odu serialno scan active

              if (Product.equals("AC")){

                  btn_scan_odu_serial_no.setVisibility(View.VISIBLE);

              }
              else {

                  btn_scan_odu_serial_no.setVisibility(View.GONE);
              }

          }

            // for otthers call update layout ( dop , doi, serial no , oduseral no update button)
          else{
                scan_serialno.setVisibility(View.GONE);
                btn_scan_odu_serial_no.setVisibility(View.GONE);
              iv_dop.setVisibility(View.GONE);
              iv_doi.setVisibility(View.GONE);
              tv_SerialNo.setVisibility(View.VISIBLE);
          }

            Address = object1.getString("Address");
            PinCode=object1.getString("PinCode");
            CallBookDate = object1.getString("CallBookDate");
            Status = object1.getString("Status");
            Franchise=object1.getString("Franchise");
            AssignDate=object1.getString("AssignDate");

            SimpleDateFormat formats=new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a",Locale.ENGLISH);
            Date dts=formats.parse(AssignDate);
            DateFormat dayfrmat=new SimpleDateFormat("EEEE",Locale.ENGLISH);
            DateFormat maothfor=new SimpleDateFormat("MMM dd yyyy",Locale.ENGLISH);
            DateFormat timef=new SimpleDateFormat("hh:mm a",Locale.ENGLISH);
            String finalDay= dayfrmat.format(dts);
            String mon=maothfor.format(dts);
            String times=timef.format(dts);
            tv_sdate.setText(finalDay + "  "+ mon);
            tv_stime.setText(times);

            if (object1.getString("TelePhone").equals(""))
            {
            iv_alt_call.setVisibility(View.GONE);

            }
            else{
                tv_tel.setText(object1.getString("TelePhone"));
                TelePhone=object1.getString("TelePhone");
            }



            // if user click on alt. mobile no
            iv_alt_call.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    errorDetails.Errorlog(CustomerDetailsActivity.this,"Click%20On%20Call%20Icon", TAG,"Click%20On%20Call%20Icon","AltNo__"+TelePhone,mobile_no,TicketNo,"C",mobile_details,dbversion,tss);
                    // open calling apps
                    Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" +TelePhone));// Initiates the Intent
                    startActivity(intent);

                }
            });

          tv_ageing.setText("/"+object1.getString("Ageing") + "  Days");

       // if  ticket status others like closed,cancel,negative response ,soft close hide notes and submit tab
            if(  Status.equals("Closed") || Status.equals("Cancelled") || Status.equals("Negative Response from Custome") || Status.equals("Resolved (soft closure)") || Status.equals("Request Cancellation")){

              ll_status.setClickable(false);
              ll_sales.setClickable(false);

              lv_camera_serialno.setVisibility(View.GONE);
              lv_camera_oduserialno.setVisibility(View.GONE);
              lv_camera_invioce.setVisibility(View.GONE);
              scan_serialno.setVisibility(View.GONE);
              iv_dop.setVisibility(View.GONE);
              iv_doi.setVisibility(View.GONE);
              btn_scan_odu_serial_no.setVisibility(View.GONE);

            }


//          getting prevois added spare and sales essential

            getpendingdata();

            if (Status.equals("Pending")) {

                String[] sta = {"Select status","Pending","Resolved (soft closure)"};

              //  et_status.setHint("");

                ArrayAdapter aa = new ArrayAdapter(this, android.R.layout.simple_spinner_item, sta);
                aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                //Setting the ArrayAdapter data on the Spinner
                snpr_status.setAdapter(aa);
            } else if (Status.equals("Assigned")) {

                String[] sta = {"Select status","Pending","Resolved (soft closure)"};

              //  et_status.setHint("");

                ArrayAdapter aa = new ArrayAdapter(this, android.R.layout.simple_spinner_item, sta);
                aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                //Setting the ArrayAdapter data on the Spinner
                snpr_status.setAdapter(aa);
            }

            RCNNo = object1.getString("RCNNo");
            ServiceType = object1.getString("ServiceType");
            CustomerName = object1.getString("CustomerName");

            String priorit = object1.getString("Priority");

              if (priorit.equals("")){
                  tv_escal.setText("");
              }
              else {
                  tv_escal.setText("Escalate ");
              }


            ProblemDescription=object1.getString("ProblemDescription");
            if (!ProblemDescription.equals("")){

                tv_problemdescription.setText(object1.getString("ProblemDescription"));
            }
            else
            {
               // tv_problemdescription.setVisibility(View.GONE);
               // tv_modelname.setText();

            }

            tv_calltype.setText(CallType.substring(0, 1));

            proces_type=processtype(CallType);
            tv_ticketno.setText(TicketNo);
            PinCode=object1.getString("PinCode");

             String fulladress=Address.replace("\\s+", "");
             tv_addresss.setText(fulladress+" , "+PinCode);

            tv_callbook.setText(CallBookDate);
            tv_status.setText(Status);
            tv_rcnno.setText(RCNNo);
            tv_servicetype.setText(ServiceType);
            tv_custname.setText(CustomerName);


            // if customer mobile no is null hode call button

            if (RCNNo.equals("")){

                iv_call.setVisibility(View.GONE);
            }

            // call to customer
            iv_call.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                    errorDetails.Errorlog(CustomerDetailsActivity.this,"Click%20On%20Call%20Icon", TAG,"Click%20On%20Call%20Icon","callto__"+RCNNo,mobile_no,TicketNo,"C",mobile_details,dbversion,tss);

                    Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + RCNNo));// Initiates the Intent
                    startActivity(intent);
                }
            });


            PendingReason=object1.getString("PendingReason");

            if (!PendingReason.equals("")){

                tv_pending_status.setText(object1.getString("PendingReason"));
            }

            else{
                tv_pending_status.setVisibility(View.GONE);

            }

            tv_Product.setText(object1.getString("Product"));

            String product=object1.getString("Product");

            if (product.equals("AC"))
            {
                tv_modelname.setText("Air Conditioner");
            }
            else  if (product.equals("CD"))
            {
                tv_modelname.setText("Clothes Dryer");
            }
            else  if (product.equals("DW"))
            {
                tv_modelname.setText("Dish Washer");
            }
            else  if (product.equals("IND"))
            {
                tv_modelname.setText("Industrial Dish washer");
            }
            else  if (product.equals("KA"))
            {
                tv_modelname.setText("Kitchen Appliances");
            }

            else  if (product.equals("RF"))
            {
                tv_modelname.setText("Refrigerator");
            }
            else  if (product.equals("ST"))
            {
                tv_modelname.setText("Stabilizer");
            }
            else  if (product.equals("WD"))
            {
                tv_modelname.setText("Washer Dryer");
            }
            else  if (product.equals("WM"))
            {
                tv_modelname.setText("Washing Machine");
            }
            else  if (product.equals("WP"))
            {
                tv_modelname.setText("Water Purifier");
            }

            else  if (product.equals("MW"))
            {
                tv_modelname.setText("Microwave Oven");
            }


            else {

                tv_modelname.setText(product);
            }



          //  tv_Model.setText(object1.getString("Model"));
            tv_SerialNo.setText(object1.getString("serial_no"));
            String mc=object1.getString("MachinStatus");


//            getamcdetails(SerialNo);
//
//            ll_amc_view.setVisibility(View.VISIBLE);

            // update machine status

            if (mc.equals("SW")){
                tv_MachinStatus.setText("Warranty");
            }
            else if (mc.equals("EW")){
                tv_MachinStatus.setText("Ex-Warranty");
            }
            else if(mc.equals("OG"))
            {
                tv_MachinStatus.setText("Out of Warranty");


            }
            // if machine is in Amc then get amc details

            else if (mc.equals("AMC")){
                tv_MachinStatus.setText("AMC");

                getamcdetails(SerialNo);

                ll_amc_view.setVisibility(View.VISIBLE);

            }
            else {

                tv_MachinStatus.setText(mc);
                ll_amc_view.setVisibility(View.GONE);
            }

            tv_DOP.setText(object1.getString("DOP"));
            tv_DOI.setText(object1.getString("DOI"));
            oduserno=object1.getString("odu_ser_no");
            tv_odu_ser_no.setText(oduserno);

            tv_problem_details.setText("");

            String machinestatus = object1.getString("MachinStatus");

            if (!machinestatus.equals("AMC")) {

               ll_amc_view.setVisibility(View.GONE);

            }

            if(mc.equals("OG")){

              // updateicrlayout();
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        // getting all pevois image

        getuploaddoc();

    }

    // if user click in essentiall scan button

    public void scan_essential(){
         Intent i = new Intent(CustomerDetailsActivity.this, FullScannerActivity.class);
         startActivityForResult(i, SCAN_ESS_NO);
    }


    // for sumit all value
    public void submit_Value(){


        boolean essstatus=check_essential_empty();

        if (essstatus){
            popupessential();
        }
        else{
            try{

                if (spnr_status.equals("Select status")) {
                    showerror("Please Select Status");
                  //  Toast.makeText(CustomerDetailsActivity.this, "Please Select status", Toast.LENGTH_SHORT).show();
                }
                else{
                    showConfirmDialog(CustomerDetailsActivity.this,"Service Order Update","Do you want to submit");
                }
            }catch (Exception e){
                e.printStackTrace();
            }
        }
     }


     // adding any spare into list
    public void add_part(){

                if (checkBox.isChecked()){

                  spare_not_found="Yes";
                }
                else{
                    spare_not_found="No";
                }

                if (!quentity.equals("0")) {

                    checkBox.setChecked(false);

                     model = new Add_item_model();
                     Boolean check_part_In=check_part_In_List(partcode);


                     if(check_part_In){

                         showerror("Already Exist");
                        // Toast.makeText(CustomerDetailsActivity.this, "Already Exist", Toast.LENGTH_SHORT).show();
                     }

                     else{

                         try{

                             int bqty=string_to_int(quentity);

                             if (spare_not_found.equals("Yes")){

                                 if (bqty > bom_qty){

                                   //  add_part_item(partname,partcode,quentity,"I",spare_not_found);
                                     model = new Add_item_model();
                                     model.setItemname(partname);
                                     model.setDescription(partcode);
                                     model.setCount(quentity);
                                     model.setFlag("I");
                                     model.setCheck(spare_not_found);
                                     model.setStockqty(bom_qty);
                                     models.add(model);

                                     errorDetails.Errorlog(CustomerDetailsActivity.this,"Click%20On%20Add%20Spare%20Item", TAG,partname.replace(" ","%20" )+"%20"+partcode+"%20"+quentity+"%20"+spare_not_found,"Spare%20Item%20Add%20In%20List",mobile_no,TicketNo,"S",mobile_details,dbversion,tss);
                                     add_item_adapter = new Add_item_adapter(models, CustomerDetailsActivity.this);
                                     add_item_adapter.notifyDataSetChanged();
                                     lv_additem.setAdapter(add_item_adapter);

                                 }

                                 else{

                                     if (partname.equals("-- select spare --")){

                                         showerror("Please select spare");
                                     }
                                     else {
                                         showerror("Stock Available");
                                     }
                                     //Toast.makeText(CustomerDetailsActivity.this, "Stock Available", Toast.LENGTH_SHORT).show();

                                 }
                             }
                             else if (bqty <= bom_qty){
                                 model = new Add_item_model();
                                 model.setItemname(partname);
                                 model.setDescription(partcode);
                                 model.setCount(quentity);
                                 model.setFlag("I");
                                 model.setCheck(spare_not_found);
                                 model.setStockqty(bom_qty);
                                 models.add(model);
                                 errorDetails.Errorlog(CustomerDetailsActivity.this,"Click%20On%20Add%20Spare%20Item", TAG,partname.replace(" ","%20" )+"%20"+partcode+"%20"+quentity+"%20"+spare_not_found,"Spare%20Add%20In%20List",mobile_no,TicketNo,"S",mobile_details,dbversion,tss);
                                 add_item_adapter = new Add_item_adapter(models, CustomerDetailsActivity.this);
                                 add_item_adapter.notifyDataSetChanged();
                                 lv_additem.setAdapter(add_item_adapter);
                             }
                             else {


                                 if (partname.equals("-- select spare --")){
                                     showerror("Please select spare");
                                 }
                                 else {
                                     showerror("Stock Available");
                                 }

                              //   Toast.makeText(CustomerDetailsActivity.this, "Stock Mismatch", Toast.LENGTH_SHORT).show();
                             }


                         }catch (Exception e){
                             e.printStackTrace();
                           }

                     }

                } else {

                    showerror("Please select quantity");

                   // Toast.makeText(CustomerDetailsActivity.this, "Please select quantity", Toast.LENGTH_SHORT).show();
                }

            }

    // adding doi
    public void update_doi(){

                datestatus = "doi";
                DatePickerDialog datePickerDialog = new DatePickerDialog(CustomerDetailsActivity.this, date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH));
                //following line to restrict future date selection
                datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
                // datePickerDialog.getDatePicker().setMinDate();
                datePickerDialog.show();

    }

    // adding dop
    public void update_dop(){

                datestatus = "dop";
                DatePickerDialog datePickerDialog = new DatePickerDialog(CustomerDetailsActivity.this, date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                myCalendar.get(Calendar.DAY_OF_MONTH));

                //following line to restrict future date selection
                datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
                // datePickerDialog.getDatePicker().setMinDate();
                datePickerDialog.show();
    }

    // open number picker
    public void update_ess_quantity(View v){
        showNumberPicker(v);
    }

    // add essential into essential added list

    public void add_ess(){


        int eqty=string_to_int(quentity);

                if (!quentity.equals("0")  ){

                        essential_add_model = new Essential_add_model();
                        Boolean status=checkesscode(essComponentDescription);

                        if (status){
                            showerror("Essential Already Exists");
                          //  Toast.makeText(CustomerDetailsActivity.this, "Already Exists", Toast.LENGTH_SHORT).show();
                        }
                        else{

                            if (eqty <= ess_stock){
                                essential_add_model.setEname(essComponentDescription);
                                essential_add_model.setEcode(essComponent);
                                essential_add_model.setEquentity(quentity);
                                essential_add_model.setItemtype(ItemType);
                                essential_add_model.setFlag("I");
                                essential_add_models.add(essential_add_model);

                                errorDetails.Errorlog(CustomerDetailsActivity.this,"Click%20On%20Essential%20Add", TAG,essComponentDescription.replace(" ","%20" )+"%20"+essComponent+"%20"+quentity+"%20"+ItemType,"Essential%20Tab",mobile_no,TicketNo,"",mobile_details,dbversion,tss);


                            }

                            else {

                                if (essComponentDescription.equals("-- select essential --")){
                                    showerror("Please select essential");

                                }
                                else {
                                    showerror("Stock Mismatch");
                                }


                             //   Toast.makeText(CustomerDetailsActivity.this, "Stock Mismatch", Toast.LENGTH_SHORT).show();
                            }
                        }
//                    }


                    for (int e=0;e < essential_add_models.size();e++){

                        String value=essential_add_models.get(e).getFlag();
                    //    System.out.println(value);
                    }


                    essential_add_adapter = new Essential_add_adapter(essential_add_models, CustomerDetailsActivity.this);
                    essential_add_adapter.notifyDataSetChanged();
                    lv_ess_add_item.setAdapter(essential_add_adapter);

                } else {

                    showerror("Please Select quantity");
                 //   Toast.makeText(CustomerDetailsActivity.this, "Please select quantity", Toast.LENGTH_SHORT).show();
                }

            }


    // open scanner layout for seral no scan
    public void scan_serialNo(){
           Intent i = new Intent(CustomerDetailsActivity.this, FullScannerActivity.class);
           startActivityForResult(i, SCANSERIALNO);

            }

   // open google map for get direction
    public void openGoolgemap(){

        errorDetails.Errorlog(CustomerDetailsActivity.this,"Open%20Google%20Map", TAG,Street+","+City+","+State+","+PinCode,"Map%20Direction%20Addresss",mobile_no,TicketNo,"",mobile_details,dbversion,tss);

        Uri gmmIntentUri = Uri.parse("geo:0,0?q="+Street+","+City+","+State+","+PinCode+"");
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                startActivity(mapIntent);

    }

  // add residence,  product and machine adapter value into spinner
    public void update_notes_Spinner(){

        ArrayAdapter residence_adapter = new ArrayAdapter(this, R.layout.spinner_item, residence_list);
        residence_adapter.setDropDownViewResource(R.layout.spinner_dropdown_item);
        //Setting the ArrayAdapter data on the Spinner
        spnr_residence.setAdapter(residence_adapter);
        spnr_residence.setOnItemSelectedListener(this);

        ArrayAdapter product_adapter = new ArrayAdapter(this, R.layout.spinner_item, product_list);
        product_adapter.setDropDownViewResource(R.layout.spinner_dropdown_item);
        //Setting the ArrayAdapter data on the Spinner
        spnr_product.setAdapter(product_adapter);
        spnr_product.setOnItemSelectedListener(this);

        ArrayAdapter machine_adapter = new ArrayAdapter(this, R.layout.spinner_item, machine_list);
        machine_adapter.setDropDownViewResource(R.layout.spinner_dropdown_item);
        //Setting the ArrayAdapter data on the Spinner
        spnr_machine.setAdapter( machine_adapter);
        spnr_machine.setOnItemSelectedListener(this);
        et_feedback=findViewById(R.id.et_feedback);

    }

    // after scan serial no is valid or not
    public boolean checkSerialNo(String scanres){
        boolean suc;

       if (scanres.length()==18 && scanres.matches(validNumber)){
           suc=true;
       }
       else{

           suc=false;
           alert.showDialog(CustomerDetailsActivity.this,"Serial no scan error !!!","Serial No Always 18 Digit. \n Scan result - "+scanres);
        }

        return suc;
    }

    // open scanner value for scan odu serial no
    public void scanoduno(){

        Intent i = new Intent(CustomerDetailsActivity.this, FullScannerActivity.class);
        startActivityForResult(i, ODU_NO);
    }

    // getting spare single value from local db
    public void  getSinglepartdetails(String scanpartcode){

        Cursor partname_cur;

        try {

            partname_cur = dbhelper.get_partName(scanpartcode);
            if (partname_cur != null) {

                if (partname_cur.moveToFirst()) {

                   do{
                       for(int i=0;i<1;i++) {
                           final int recordid = partname_cur.getInt(partname_cur.getColumnIndex("recordid"));
                           String ComponentDescription = partname_cur.getString(partname_cur.getColumnIndex("ComponentDescription"));
                           String good_stock = partname_cur.getString(partname_cur.getColumnIndex("good_stock"));
                           String refurbished_stock = partname_cur.getString(partname_cur.getColumnIndex("refurbished_stock"));
                           partname = partname_cur.getString(partname_cur.getColumnIndex("ComponentDescription"));
                           int goodstock = string_to_int(good_stock);
                           int refurbishedstock = string_to_int(refurbished_stock);

                           String Component=partname_cur.getString(partname_cur.getColumnIndex("Component"));

                           if (goodstock < refurbishedstock) {

                               tv_bom_qty.setText(refurbished_stock);
                               bom_qty = refurbishedstock;
                           } else {
                               tv_bom_qty.setText(good_stock);
                               bom_qty = goodstock;
                           }


                           int position = -1;
                           position =itemlist.indexOf(ComponentDescription);
                           spinner.setSelection(position);

                           Boolean result=check_part_In_List(scanpartcode);

                           if (result.equals(false)){
                               if (bom_qty > 0) {

                                  // errorDetails.Errorlog(CustomerDetailsActivity.this,"Spare%20Add%20After%20Scan", TAG,"Auto%20Add%20after%20Part%20Scan","Pname--"+partname+"Pcode--"+scanpartcode+ "AddQty--1%20Pend--No%20"+"Sqty"+ bom_qty,""+mobile_no,""+TicketNo,"",""+mobile_details,""+dbversion,""+tss);
                                   add_part_item(partname, scanpartcode, "1", "I", "No", bom_qty);

                               } else {
                                   add_part_item(partname, scanpartcode, "1", "I", "Yes", bom_qty);

                                 //  errorDetails.Errorlog(CustomerDetailsActivity.this,"Spare%20Add%20After%20Scan", TAG,"Auto%20Add%20after%20Part%20Scan","Pname--"+partname+"Pcode--"+scanpartcode+ "AddQty--1%20Pend--Yes%20"+"Sqty"+ bom_qty,mobile_no,TicketNo,"",mobile_details,dbversion,tss);
//                                   Alert alert = new Alert();
//                                   alert.showDialog(CustomerDetailsActivity.this, "Stock Quantity", "Total Stock : " + bom_qty + " Spare Add in Pending");
//
                             //   showerror("Spare Added with Pending flag");

                               }
                           }

                           else{
                               errorDetails.Errorlog(CustomerDetailsActivity.this,"Spare%20Add%20After%20Scan", TAG,"Spare%20Already%20Added%20%In%20List","Pname_"+partname,mobile_no,TicketNo,"E",mobile_details,dbversion,tss);
                           }
                       }
                    } while (partname_cur.moveToNext());

                    partname_cur.close();
                }
            }

            else {
                errorDetails.Errorlog(CustomerDetailsActivity.this,"Spare%20Add%20After%20Scan", TAG,"Spare%20Name%20Not%20Found%20In%20List","Pname--"+partname,mobile_no,TicketNo,"E",mobile_details,dbversion,tss);
                showerror("Spare Not Found In List");
                partname="";
            }
        }
        catch(Exception e){

            e.printStackTrace();
        }
    }

    // for take any type of photo  open image picker
    private void launchCameraIntent(String type) {
        Intent intent = new Intent(CustomerDetailsActivity.this, ImagePickerActivity.class);
        intent.putExtra(ImagePickerActivity.INTENT_IMAGE_PICKER_OPTION, ImagePickerActivity.REQUEST_IMAGE_CAPTURE);

        // setting aspect ratio
        intent.putExtra(ImagePickerActivity.INTENT_LOCK_ASPECT_RATIO, true);
        intent.putExtra(ImagePickerActivity.INTENT_ASPECT_RATIO_X, 16); // 16x9, 1x1, 3:4, 3:2
        intent.putExtra(ImagePickerActivity.INTENT_ASPECT_RATIO_Y, 9);

        // setting maximum bitmap width and height
        intent.putExtra(ImagePickerActivity.INTENT_SET_BITMAP_MAX_WIDTH_HEIGHT, true);
        intent.putExtra(ImagePickerActivity.INTENT_BITMAP_MAX_WIDTH, 500);
        intent.putExtra(ImagePickerActivity.INTENT_BITMAP_MAX_HEIGHT, 500);

        if (type.equals("invoice")){
            startActivityForResult(intent, INVOICE_IMAGE_CAPTURE);
        }
        else if(type.equals("serialno")){
            startActivityForResult(intent, SERIALNO_IMAGE_CAPTURE);
        }
        else if(type.equals("oduserialno")){
            startActivityForResult(intent, ODU_SERIALNO_IMAGE_CAPTURE);
        }

    }

    // go to customer siignaturw page for customer signature
    public void lunchSignIntent(){
        Intent intent = new Intent(CustomerDetailsActivity.this, CustomerSign.class);
        startActivityForResult(intent,CUSTOMER_SIGNATURE);
    }

    // upload all image serialno,odu serialno invoice and cust sign image upload to server
    private void uploadImage(){

        if (CheckConnectivity.getInstance(this).isOnline()) {
        String  upload_URL=AllUrl.baseUrl+"doc/uploaddoc?";

        progressBar.setVisibility(View.VISIBLE);
        VolleyMultipartRequest volleyMultipartRequest = new VolleyMultipartRequest(POST, upload_URL,
                new Response.Listener<NetworkResponse>() {
                    @Override
                    public void onResponse(NetworkResponse response) {

                        rQueue.getCache().clear();

                     //   System.out.println(response.statusCode);
                       progressBar.setVisibility(View.GONE);

                        if (response.statusCode==200){

                            errorDetails.Errorlog(CustomerDetailsActivity.this,"image%20upload", TAG,"Image%20upload",""+response.statusCode,mobile_no,TicketNo,"U",mobile_details,dbversion,tss);
                            dbhelper.insert_offline_image_data(TicketNo,seraialno_image_data,oduserialno_image_data,invoice_image_data,customersign_data,tss,"upload");

                        }
                        else {

                            dbhelper.insert_offline_image_data(TicketNo,seraialno_image_data,oduserialno_image_data,invoice_image_data,customersign_data,tss,"notupload");
                            errorDetails.Errorlog(CustomerDetailsActivity.this,"image%20upload", TAG,"Image%20upload",""+response.statusCode,mobile_no,TicketNo,"E",mobile_details,dbversion,tss);

                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        errorDetails.Errorlog(CustomerDetailsActivity.this,"image%20upload", TAG,"Image%20upload","error",mobile_no,TicketNo,"E",mobile_details,dbversion,tss);

                        // Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                        dbhelper.insert_offline_image_data(TicketNo,seraialno_image_data,oduserialno_image_data,invoice_image_data,customersign_data,tss,"notupload");
                        progressBar.setVisibility(View.GONE);
                    }
                }) {


            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                //model.AppDocUpload.
                params.put("TicketNo",TicketNo);
                params.put("UploadDate",tss);
                params.put("ClientDocs", "ClientDocs");
                System.out.println(params);
                return params;
            }

            @Override
            protected Map<String, DataPart> getByteData() {
                Map<String, DataPart> params = new HashMap<>();
                long imagename = System.currentTimeMillis();
                params.put("InvoicePhto", new DataPart("invoicephoto_" + TicketNo +".jpeg", invoice_image_data));
                params.put("ODUSerialPhoto", new DataPart("oduserialno_" + TicketNo + ".jpeg", oduserialno_image_data));
                params.put("SerialPhoto", new DataPart("serialno_" +TicketNo+ ".jpeg", seraialno_image_data));
                params.put("SignaturePhoto", new DataPart("signature_" +TicketNo+ ".jpeg",customersign_data ));

               // System.out.println(params);
                return params;
            }
        };


        volleyMultipartRequest.setRetryPolicy(new DefaultRetryPolicy(
                0,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
         rQueue = Volley.newRequestQueue(CustomerDetailsActivity.this);
        rQueue.add(volleyMultipartRequest);

        }
        else {

            dbhelper.insert_offline_image_data(TicketNo,seraialno_image_data,oduserialno_image_data,invoice_image_data,customersign_data,tss,"notupload");

        }
    }

    // check any prevois spare is deleted or not
    public void check_delete_spare_list(){

        for (int pres=0;pres<pendingSpares.size();pres++){

            try{

                if (pendingSpares.get(pres).getFlags().equals("D")){
                    String Spare=pendingSpares.get(pres).getPartCode();
                    String Quentity=pendingSpares.get(pres).getQty();
                    String itemno=(pendingSpares.get(pres).getItemno());
                    String Itemtype=(pendingSpares.get(pres).getItemType());
                    String Status=(pendingSpares.get(pres).getStatus());
                    upload_deleted_spare(Spare,Quentity,itemno,Itemtype,Status,"","");
                }

            }catch (Exception e){

                e.printStackTrace();
            }
        }

    }

    // upload deleted spare in to server
    public void upload_deleted_spare(String Spare,String Quentity,String itemno,String Itemtype,String Status,String Accessssories,String Additive) {

        if (CheckConnectivity.getInstance(this).isOnline()) {

            String url = AllUrl.baseUrl+"spareEssetial/update?model.sapreeEssential.OrderId="+TicketNo
                    +"&model.sapreeEssential.Spare="+ Spare
                    +"&model.sapreeEssential.Accessssories="+Accessssories
                    +"&model.sapreeEssential.Additive="+Additive
                    +"&model.sapreeEssential.Status="+Status
                    +"&model.sapreeEssential.Itemtype="+Itemtype
                    +"&model.sapreeEssential.itemno="+itemno
                    +"&model.sapreeEssential.Quentity="+Quentity;


            RequestQueue queue = Volley.newRequestQueue(this);

            StringRequest postRequest = new StringRequest(POST, url,
                    new Response.Listener<String>()
                    {
                        @Override
                        public void onResponse(String response) {

                        }
                    },
                    new Response.ErrorListener()
                    {
                        @Override
                        public void onErrorResponse(VolleyError error) {

                        }
                    }
            ) {
                @Override
                protected Map<String, String> getParams()
                {
                    Map<String, String>  params = new HashMap<String, String>();

                    return params;
                }
            };
            queue.add(postRequest);


        } else {

            String url = AllUrl.baseUrl+"spareEssetial/update?model.sapreeEssential.OrderId="+TicketNo
                    +"&model.sapreeEssential.Spare="+ Spare
                    +"&model.sapreeEssential.Accessssories="+Accessssories
                    +"&model.sapreeEssential.Additive="+Additive
                    +"&model.sapreeEssential.Status="+Status
                    +"&model.sapreeEssential.Itemtype="+Itemtype
                    +"&model.sapreeEssential.itemno="+itemno
                    +"&model.sapreeEssential.Quentity="+Quentity;

             Boolean sta= dbhelper.insert_offline_deletespare_data(TicketNo,url,tss);

        }
    }


    // view iamge in popup with zoom
    public void  view_image(String type){

       // android.R.style.Theme_Black_NoTitleBar_Fullscreen
        // android.R.style.Theme_Black_NoTitleBar_Fullscreen
        final Dialog image_dialog = new Dialog(CustomerDetailsActivity.this);
        image_dialog.setContentView(R.layout.item_view_fillsizeimage);
        ImageView image_cancel;
        TextView textView;
        textView =image_dialog.findViewById(R.id.item_text_image);
        PhotoView item_image_view;
        image_cancel=image_dialog.findViewById(R.id.image_cancel);
        item_image_view=image_dialog.findViewById(R.id.item_image_view);

        image_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                image_dialog.dismiss();
            }
        });

        try{

            if(seraialno_image_data != null && type.equals("serialno")){

                textView.setText("Serial No Photo");

                if(!serialnourl.equals("")){
//                    Glide.with(CustomerDetailsActivity.this)
//                            .load(serialnourl)
//                            .into(item_image_view);

                    Picasso.get()
                            .load(serialnourl)
//                            .placeholder(R.drawable.user_placeholder)
//                            .error(R.drawable.user_placeholder_error)
                            .into(item_image_view);


                }

                else{

                    Bitmap bmp = BitmapFactory.decodeByteArray(seraialno_image_data, 0, seraialno_image_data.length);
                    item_image_view.setImageBitmap(bmp);

                }


            }
            else if (oduserialno_image_data!=null && type.equals("oduserialno")){

                textView.setText("ODU Serial No Photo");

                if (!oduurl.equals("")){

                    Picasso.get()
                            .load(oduurl)
//                            .placeholder(R.drawable.user_placeholder)
//                            .error(R.drawable.user_placeholder_error)
                            .into(item_image_view);


                }
                else
                {
                    Bitmap bmp = BitmapFactory.decodeByteArray(oduserialno_image_data, 0, oduserialno_image_data.length);
                    item_image_view.setImageBitmap(bmp);
                }
            }
            else if(invoice_image_data!=null && type.equals("invioce")){
                textView.setText("Invoice Photo");

                if (!invioceurl.equals("")){
//                    Glide.with(CustomerDetailsActivity.this)
//                            .load(invioceurl)
//                            .into(item_image_view);



                    Picasso.get()
                            .load(invioceurl)
//                            .placeholder(R.drawable.user_placeholder)
//                            .error(R.drawable.user_placeholder_error)
                            .into(item_image_view);
                }
                else {

                    Bitmap bmp = BitmapFactory.decodeByteArray(invoice_image_data, 0, invoice_image_data.length);
                    item_image_view.setImageBitmap(bmp);
                }


            }


        }catch (Exception e){
            e.printStackTrace();
        }


        image_dialog.show();

    }


    // if user is offline get pending reason from dbhelper
    public void  get_offline_pendingReasons(String CallType){

       if (CallType.equals("SERVICE CALL")) {

           getdatabygroupcode("ZSER07");

       } else if (CallType.equals("MANDATORY CALLS")) {
           getdatabygroupcode("ZMAN07");

       } else if (CallType.equals("COURTESY VISIT")) {

           getdatabygroupcode("ZFOC07");

       } else if (CallType.equals("INSTALLATION CALL")) {

           getdatabygroupcode("ZINT07");
//           remarkurl = AllUrl.baseUrl + "Reasons/pendingReasons?pendingReasone.CodeGroup=ZINT07";
       } else if (CallType.equals("DEALER DEFECTIVE REQUEST")) {
           getdatabygroupcode("ZDD07");
          // remarkurl = AllUrl.baseUrl + "Reasons/pendingReasons?pendingReasone.CodeGroup=ZDD07";
       } else if (CallType.equals("REINSTALLLATION ORDER")) {
           getdatabygroupcode("ZRIN07");
          // remarkurl = AllUrl.baseUrl + "Reasons/pendingReasons?pendingReasone.CodeGroup=ZRIN07";
       } else if (CallType.equals("REWORK ORDER")) {
           getdatabygroupcode("ZREW07");
          // remarkurl = AllUrl.baseUrl + "Reasons/pendingReasons?pendingReasone.CodeGroup=ZREW07";
       }

   }


   //  ----------------------------- get pending reason from dbhelper --------------------------------
    public void  getdatabygroupcode(String code){
      //  System.out.println(code);

       try {
                Cursor c_pendingReasons ;

                c_pendingReasons=dbhelper.fetch_pending_reasone(code);

                if (c_pendingReasons != null) {

                   if (c_pendingReasons.moveToFirst()) {

                       do {

                           final int recordid = c_pendingReasons.getInt(c_pendingReasons.getColumnIndex("recordid"));
                          // System.out.println("recordid in pending-->" + recordid);
                           String Codegroup = c_pendingReasons.getString(c_pendingReasons.getColumnIndex("Codegroup"));
                           String Data = c_pendingReasons.getString(c_pendingReasons.getColumnIndex("Data"));

                         //  System.out.println("Pending reason data-->"+Data);

                           try {
                               JSONArray jsonArray = new JSONArray(Data);
                               remarklist = new ArrayList<>();
                               remarkmap = new HashMap<>();

                               for (int i = 0; i < jsonArray.length(); i++) {

                                   JSONObject rmobj = jsonArray.getJSONObject(i);
                                   CodeGroup = rmobj.getString("CodeGroup");
                                   String Code = rmobj.getString("Code");
                                   String Reason = rmobj.getString("Reason");
                                   remarklist.add(Reason);
                                   remarkmap.put(Reason, Code);
                               }
                               ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(CustomerDetailsActivity.this, android.R.layout.simple_spinner_dropdown_item, remarklist);
                               spnr_remark.setAdapter(arrayAdapter);
                               // spnr_remark.setSelection(0,false);
                               spnr_remark.setOnItemSelectedListener(CustomerDetailsActivity.this);

                           } catch (Exception e) {
                               e.printStackTrace();

                           }

                       } while (c_pendingReasons.moveToNext());

                         c_pendingReasons.close();

                   }
               } else {

               }
       } catch (Exception e) {
           e.printStackTrace();
       }
   }


   //  --------------------- get prevois image from server  --------------------------------------
    public void getuploaddoc(){

          if (CheckConnectivity.getInstance(this).isOnline()) {

              RequestQueue queue = Volley.newRequestQueue(this);
              //String url = AllUrl.loginUrl+"?url=http://centurionbattery.in/development&username="+username+"&password="+password;
              String url = AllUrl.baseUrl+"uploadedDocByApp/getdoc?model.AppDocUpload.TicketNo="+TicketNo;

           //   System.out.println("get image url-->  " + url);
              StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                      new Response.Listener<String>() {
                          @Override
                          public void onResponse(String response) {


                              try{

                                  JSONArray jsonArray = new JSONArray(response);

                                  for (int i = 0; i < jsonArray.length(); i++) {

                                      JSONObject obj = jsonArray.getJSONObject(i);
                                      serialnourl = obj.getString("SerialPhoto");
                                      oduurl = obj.getString("ODUSerialPhoto");
                                      invioceurl = obj.getString("InvoicePhto");


//                                      Glide.with(CustomerDetailsActivity.this)
//                                                  .load(serialnourl)
//                                                  .into(view_serialno);

                                      Picasso.get()
                                              .load(serialnourl)
//                            .placeholder(R.drawable.user_placeholder)
//                            .error(R.drawable.user_placeholder_error)
                                              .into(view_serialno);


//                                      Glide.with(CustomerDetailsActivity.this)
//                                              .load(oduurl)
//                                              .into(view_oduserialno);

                                      Picasso.get()
                                              .load(oduurl)
//                            .placeholder(R.drawable.user_placeholder)
//                            .error(R.drawable.user_placeholder_error)
                                              .into(view_oduserialno);

//                                      Glide.with(CustomerDetailsActivity.this)
//                                              .load(invioceurl)
//                                              .into(view_invioce);

                                      Picasso.get()
                                              .load(invioceurl)
//                            .placeholder(R.drawable.user_placeholder)
//                            .error(R.drawable.user_placeholder_error)
                                              .into(view_invioce);



//                                      "SerialPhoto": "https://crmapi.ifbhub.com/ClientDocument/2002778771invoice.png",
//                                              "ODUSerialPhoto": "https://crmapi.ifbhub.com/ClientDocument/2002778771oduserial.png",
//                                              "InvoicePhto": "https://crmapi.ifbhub.com/ClientDocument/2002778771serial.png",

                                  }


                              }catch(Exception e){


                                  e.printStackTrace();
                              }

                          }
                      }, new Response.ErrorListener() {
                  @Override
                  public void onErrorResponse(VolleyError error) {

                  }
              });


              int socketTimeout = 10000; //10 seconds - change to what you want
              RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
              stringRequest.setRetryPolicy(policy);
              queue.add(stringRequest);

          } else {

              //showerror("Please Select Status");
             // Toast.makeText(this, "Ooops! Internet Connection Error", Toast.LENGTH_SHORT).show();
          }
      }



  // -------------------- check essential added or not (Submit time check essential add or not) --------------
    public  boolean check_essential_empty(){

        boolean success;
        if ( essential_add_models.size()==0){

            success=true;
        }
        else{
            success=false;
        }
        return  success;
    }


    // ------------------------- open dialog if user not added any essentrial  ------------------------
    public void popupessential(){

        final Dialog dialog = new Dialog(CustomerDetailsActivity.this);

        dialog.setContentView(R.layout.popupessentialnotsale);
        Button skip=dialog.findViewById(R.id.popup_btn_skip);
        Button ok=dialog.findViewById(R.id.popup_btn_ok);

        // if user click on skip buttton
        skip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

                try{

                    //check user select any status (pending or soft close )

                    if (spnr_status.equals("Select status")) {

                        showerror("Please Select Status");
                       // Toast.makeText(CustomerDetailsActivity.this, "Select status", Toast.LENGTH_SHORT).show();
                    }

                    //open confirm dialog for send data
                    else{

                        showConfirmDialog(CustomerDetailsActivity.this,"Service Order Update","Do you want to submit");
                    }

                }catch (Exception e){
                    e.printStackTrace();
                }
            }

        });

        // if user click on ok button go to essential tab

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ActiveEssTab();
                dialog.dismiss();

            }
        });

        dialog.show();
    }


    @Override
    protected void onPause() {
        super.onPause();

    }

    @Override
    protected void onPostResume() {
        super.onPostResume();

    }
//  ------------- calculation shelf life date as per essential usage -------------------------
    public void getcal(){

        if (!shelflife.equals("") && !shelflife.equals("0") && !shelflife.equals("As per usage/Standard")){
            ll_ess_cal.setVisibility(View.VISIBLE);
            String enddate= Valuefilter.Enddate(shelflife,essuses,quentity);
            tv_ess_calculation.setText(enddate);
        }
        else {
            ll_ess_cal.setVisibility(View.GONE);
        }

    }

    public byte[] getFileDataFromDrawable(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 80, byteArrayOutputStream);
        return byteArrayOutputStream.toByteArray();
    }

    //csv file creation section ...

    // ---------------------- getting all data and change as per crm data ------------------------

    public void createcsv(String smsstatus,int subid){

        finaljsonArray =new JSONArray();

        if (work_status.equals("E0008")){
            remarkcode="";
        }

        st_feedback=et_feedback.getText().toString();

        st_icr_no=et_icr_no.getText().toString();
        String icrdates= tv_icr_date.getText().toString();
        String redate=tv_select_date.getText().toString();
        String retime=tv_select_time.getText().toString();
        String dops=tv_DOP.getText().toString();
        String dois=tv_DOI.getText().toString();

       // insert other details in to local db for show the data
        dbhelper.insert_others_details(TicketNo,Status,SerialNo,dops,dois,icrdates,st_icr_no,st_feedback,nomen,residence,redate,retime,spnr_status,remark,"");

        //csv= Environment.getExternalStorageDirectory().getAbsolutePath() + "/"+TicketNo+".csv";

        String rescheduledates=sdate+""+stime;

        if (rescheduledates.equals("00000000000000")){

            rescheduledate="";
        }
        else{

            rescheduledate=sdate+""+stime;
        }

        //"FL","TL","MW","DW","CD","AC","BIH","BIO"

        // getting fcustomer other details data from list

        for (int pr=0;pr<add_product_models.size();pr++){

            String product=add_product_models.get(pr).getProduct();
            String company=add_product_models.get(pr).getMachine();
            String year=add_product_models.get(pr).getYear();
            dbhelper.insert_save_home(TicketNo,Status,product,year,company);

            switch (add_product_models.get(pr).getProduct()){

                case "FL":
                    // zz_fl=add_product_models.get(pr).getProduct();
                    zz_fl="X";
                    zz_flbrand=getbrand(add_product_models.get(pr).getMachine());
                    zz_mt5fl=getyear(add_product_models.get(pr).getYear());

                    break;

                case "TL":
                    zz_tl="X";
                    zz_tlbrand=getbrand(add_product_models.get(pr).getMachine());
                    zz_mt5tl=getyear(add_product_models.get(pr).getYear());
                    break;

                case "MW":

                    zz_mw="X";
                    zz_mwbrand=getbrand(add_product_models.get(pr).getMachine());
                    zz_mt5mw=getyear(add_product_models.get(pr).getYear());
                    break;
                case  "DW":
                    zz_dw="X";
                    zz_dwbrand=getbrand(add_product_models.get(pr).getMachine());
                    zz_mt5dw=getyear(add_product_models.get(pr).getYear());
                    break;

                case  "CD":
                    //zz_cd,zz_cdbrand,zz_mt5cd
                    zz_cd="X";
                    zz_cdbrand=getbrand(add_product_models.get(pr).getMachine());
                    zz_mt5cd=getyear(add_product_models.get(pr).getYear());
                    break;

                case  "AC":
                    //  zz_ac,zz_acbrand,zz_mt5ac
                    zz_ac="X";
                    zz_acbrand=getbrand(add_product_models.get(pr).getMachine());
                    zz_mt5ac=getyear(add_product_models.get(pr).getYear());
                    break;

                case  "BIH":
                    //  zz_bih,zz_bihbrand,zz_mt5bih
                    zz_bih="X";
                    zz_bihbrand=getbrand(add_product_models.get(pr).getMachine());
                    zz_mt5bih=getyear(add_product_models.get(pr).getYear());
                    break;

                case  "BIO":
                    //  zz_bio,zz_biobrand,zz_mt5bio
                    zz_bio="X";
                    zz_biobrand=getbrand(add_product_models.get(pr).getMachine());
                    zz_mt5bio=getyear(add_product_models.get(pr).getYear());
                    break;

                default:
                    break;
            }

        }

        try {

            //   data.add(new String[]{"orderid","franchise_bp","proces_type","serial_no","odu_serial_no","dop","doi","status","status_reason","notes","eta","rechecked_date","rescheduled_date","ICR_no","ICR_Date","spare_flag","product_code","spare_serno","pending_flag","quantity","unit","itemno","zz_bp","zz_residence","zz_members","zz_fl","zz_flbrand","zz_mt5fl","zz_tl","zz_tlbrand","zz_mt5tl","zz_mw","zz_mwbrand","zz_mt5mw","zz_dw","zz_dwbrand","zz_mt5dw","zz_cd","zz_cdbrand","zz_mt5cd","zz_ac","zz_acbrand","zz_mt5ac","zz_bih","zz_bihbrand","zz_mt5bih","zz_bio","zz_biobrand","zz_mt5bio"});


//           getting all list size (essential ,spare ,prevois spare and essential
            int partsize=models.size();
            int esssize=essential_add_models.size();
            int penspare= pendingSpares.size();

            //total count how many row created
            totallinecount=partsize+esssize+penspare;

            if (partsize == 0 && esssize == 0 && penspare == 0){

                // insert value into json array

                createjson(PartnerId,TicketNo,Franchise,proces_type,SerialNo,oduserno,DOP,DOI,work_status,remarkcode,st_feedback,"00000000",rechaeck_date,rescheduledate,st_icr_no,st_icr_date,"","","","","","","",CustomerCode, residen,nomen,zz_fl,zz_flbrand,zz_mt5fl,zz_tl,zz_tlbrand,zz_mt5tl,zz_mw,zz_mwbrand,zz_mt5mw,zz_dw,zz_dwbrand,zz_mt5dw,zz_cd,zz_cdbrand,zz_mt5cd,zz_ac,zz_acbrand,zz_mt5ac,zz_bih,zz_bihbrand,zz_mt5bih,zz_bio,zz_biobrand,zz_mt5bio,flagstatus, st_feedback);

            }
            else {

                if (penspare !=0){

                    for (int pre=0;pre<pendingSpares.size();pre++){

                        String psflag=pendingSpares.get(pre).getFlags();
                        String pspartname=pendingSpares.get(pre).getPartName();
                        String pspartcode=pendingSpares.get(pre).getPartCode();
                        String psqty=pendingSpares.get(pre).getQty();
                        String pending_fla=pendingSpares.get(pre).getPending_fla();
                        eta=Parsedates(pendingSpares.get(pre).getETA());
                        String itemno=(pendingSpares.get(pre).getItemno());
                        // System.out.println("peta-->"+eta);

                        if (eta.equals("19000101")){

                            eta="00000000";
                        }

                        String pflag="";

                        if (pending_fla.equals("Yes")){
                            pflag="X";
                        }
                        else if( pending_fla.equals("No")){

                            pflag="";
                        }
                        //  data.add(new String[]{TicketNo,Franchise,proces_type,SerialNo,oduserno, DOP, DOI, work_status, remarkcode, st_feedback, eta, rechaeck_date, rescheduledate,st_icr_no, st_icr_date, psflag, pspartcode,"",pflag, psqty, "PCS", itemno, CustomerCode, residen,nomen, zz_fl, zz_flbrand, zz_mt5fl, zz_tl, zz_tlbrand, zz_mt5tl, zz_mw, zz_mwbrand, zz_mt5mw, zz_dw, zz_dwbrand, zz_mt5dw, zz_cd, zz_cdbrand, zz_mt5cd, zz_ac, zz_acbrand, zz_mt5ac, zz_bih, zz_bihbrand, zz_mt5bih, zz_bio, zz_biobrand, zz_mt5bio});
                        createjson(PartnerId,TicketNo,Franchise,proces_type,SerialNo,oduserno, DOP, DOI, work_status, remarkcode, st_feedback, eta, rechaeck_date, rescheduledate,st_icr_no, st_icr_date, psflag, pspartcode,"",pflag, psqty, "PCS", itemno, CustomerCode, residen,nomen, zz_fl, zz_flbrand, zz_mt5fl, zz_tl, zz_tlbrand, zz_mt5tl, zz_mw, zz_mwbrand, zz_mt5mw, zz_dw, zz_dwbrand, zz_mt5dw, zz_cd, zz_cdbrand, zz_mt5cd, zz_ac, zz_acbrand, zz_mt5ac, zz_bih, zz_bihbrand, zz_mt5bih, zz_bio, zz_biobrand, zz_mt5bio,"", st_feedback);
                        dbhelper.insert_spare(TicketNo,Status,pspartname,pspartcode,pending_fla,psqty);

                    }
                }
                if (partsize != 0){
                    for (int p=0;p < partsize; p++) {

                        String sflag = models.get(p).getFlag();
                        String scode = models.get(p).getDescription();
                        String sqty = models.get(p).getCount();
                        String spartname=models.get(p).getItemname();
                        String sp_not_founds=models.get(p).getCheck();

                        //  (String Ticketno,String Status,String Sname,String Scode,String Sflag,String Sqty){
                        dbhelper.insert_spare(TicketNo,Status,spartname,scode,sp_not_founds,sqty);


                        if (spartname.equals("NA")){

                            createjson(PartnerId,TicketNo,Franchise,proces_type, SerialNo,oduserno, DOP, DOI, work_status, remarkcode, st_feedback, "00000000",rechaeck_date, rescheduledate,st_icr_no, st_icr_date, sflag, scode,"","", sqty, "PCS", "", CustomerCode, residen,nomen, zz_fl, zz_flbrand, zz_mt5fl, zz_tl, zz_tlbrand, zz_mt5tl, zz_mw, zz_mwbrand, zz_mt5mw, zz_dw, zz_dwbrand, zz_mt5dw, zz_cd, zz_cdbrand, zz_mt5cd, zz_ac, zz_acbrand, zz_mt5ac, zz_bih, zz_bihbrand, zz_mt5bih, zz_bio, zz_biobrand, zz_mt5bio,"", st_feedback);


                            // data.add(new String[]{PartnerId,TicketNo,Franchise,proces_type, SerialNo,oduserno, DOP, DOI, work_status, remarkcode, st_feedback, "00000000",rechaeck_date, rescheduledate,st_icr_no, st_icr_date, sflag, scode,"","", sqty, "PCS", "", CustomerCode, residen,nomen, zz_fl, zz_flbrand, zz_mt5fl, zz_tl, zz_tlbrand, zz_mt5tl, zz_mw, zz_mwbrand, zz_mt5mw, zz_dw, zz_dwbrand, zz_mt5dw, zz_cd, zz_cdbrand, zz_mt5cd, zz_ac, zz_acbrand, zz_mt5ac, zz_bih, zz_bihbrand, zz_mt5bih, zz_bio, zz_biobrand, zz_mt5bio,flag});
                        }
                        else if(sp_not_founds.equals("Yes")){

                            //    data.add(new String[]{PartnerId,TicketNo,Franchise,proces_type, SerialNo,oduserno, DOP, DOI, work_status, remarkcode, st_feedback, "00000000",rechaeck_date, rescheduledate,st_icr_no, st_icr_date, sflag, scode,"","X", sqty, "PCS", "", CustomerCode, residen,nomen, zz_fl, zz_flbrand, zz_mt5fl, zz_tl, zz_tlbrand, zz_mt5tl, zz_mw, zz_mwbrand, zz_mt5mw, zz_dw, zz_dwbrand, zz_mt5dw, zz_cd, zz_cdbrand, zz_mt5cd, zz_ac, zz_acbrand, zz_mt5ac, zz_bih, zz_bihbrand, zz_mt5bih, zz_bio, zz_biobrand, zz_mt5bio,flag});

                            createjson(PartnerId,TicketNo,Franchise,proces_type, SerialNo,oduserno, DOP, DOI, work_status, remarkcode, st_feedback, "00000000",rechaeck_date, rescheduledate,st_icr_no, st_icr_date, sflag, scode,"","X", sqty, "PCS", "", CustomerCode, residen,nomen, zz_fl, zz_flbrand, zz_mt5fl, zz_tl, zz_tlbrand, zz_mt5tl, zz_mw, zz_mwbrand, zz_mt5mw, zz_dw, zz_dwbrand, zz_mt5dw, zz_cd, zz_cdbrand, zz_mt5cd, zz_ac, zz_acbrand, zz_mt5ac, zz_bih, zz_bihbrand, zz_mt5bih, zz_bio, zz_biobrand, zz_mt5bio,"", st_feedback);

                        }
                        else {
//                            data.add(new String[]{PartnerId,TicketNo,Franchise,proces_type, SerialNo,oduserno, DOP, DOI, work_status, remarkcode, st_feedback,"00000000",rechaeck_date, rescheduledate,st_icr_no, st_icr_date, sflag, scode,"","", sqty, "PCS", "", CustomerCode, residen,nomen, zz_fl, zz_flbrand, zz_mt5fl, zz_tl, zz_tlbrand, zz_mt5tl, zz_mw, zz_mwbrand, zz_mt5mw, zz_dw, zz_dwbrand, zz_mt5dw, zz_cd, zz_cdbrand, zz_mt5cd, zz_ac, zz_acbrand, zz_mt5ac, zz_bih, zz_bihbrand, zz_mt5bih, zz_bio, zz_biobrand, zz_mt5bio,flag});


                            createjson(PartnerId,TicketNo,Franchise,proces_type, SerialNo,oduserno, DOP, DOI, work_status, remarkcode, st_feedback,"00000000",rechaeck_date, rescheduledate,st_icr_no, st_icr_date, sflag, scode,"","", sqty, "PCS", "", CustomerCode, residen,nomen, zz_fl, zz_flbrand, zz_mt5fl, zz_tl, zz_tlbrand, zz_mt5tl, zz_mw, zz_mwbrand, zz_mt5mw, zz_dw, zz_dwbrand, zz_mt5dw, zz_cd, zz_cdbrand, zz_mt5cd, zz_ac, zz_acbrand, zz_mt5ac, zz_bih, zz_bihbrand, zz_mt5bih, zz_bio, zz_biobrand, zz_mt5bio,"", st_feedback);

                        }
                    }
                }

                if (esssize != 0){

                    for (int e=0;e<essential_add_models.size();e++){

                        String eflag=essential_add_models.get(e).getFlag();
                        String ecode=essential_add_models.get(e).getEcode();
                        String eqty=essential_add_models.get(e).getEquentity();
                        String esname=essential_add_models.get(e).getEname();
                        String etype=essential_add_models.get(e).getItemtype();
                        dbhelper.insert_save_ess(TicketNo,Status,esname,ecode,eqty,etype);

                        if (esname.equals("NA")){

                            //  data.add(new String[]{PartnerId,TicketNo,Franchise,proces_type,SerialNo,oduserno,DOP,DOI,work_status,remarkcode,st_feedback,eta,rechaeck_date,rescheduledate,st_icr_no,st_icr_date,eflag,"",ecode,"",eqty,"PCS","",CustomerCode,residen,nomen,zz_fl,zz_flbrand,zz_mt5fl,zz_tl,zz_tlbrand,zz_mt5tl,zz_mw,zz_mwbrand,zz_mt5mw,zz_dw,zz_dwbrand,zz_mt5dw,zz_cd,zz_cdbrand,zz_mt5cd,zz_ac,zz_acbrand,zz_mt5ac,zz_bih,zz_bihbrand,zz_mt5bih,zz_bio,zz_biobrand,zz_mt5bio,""});
                            createjson(PartnerId,TicketNo,Franchise,proces_type,SerialNo,oduserno,DOP,DOI,work_status,remarkcode,st_feedback,eta,rechaeck_date,rescheduledate,st_icr_no,st_icr_date,eflag,"",ecode,"",eqty,"PCS","",CustomerCode,residen,nomen,zz_fl,zz_flbrand,zz_mt5fl,zz_tl,zz_tlbrand,zz_mt5tl,zz_mw,zz_mwbrand,zz_mt5mw,zz_dw,zz_dwbrand,zz_mt5dw,zz_cd,zz_cdbrand,zz_mt5cd,zz_ac,zz_acbrand,zz_mt5ac,zz_bih,zz_bihbrand,zz_mt5bih,zz_bio,zz_biobrand,zz_mt5bio,"",st_feedback);

                        }
                        else {

                            createjson(PartnerId,TicketNo,Franchise,proces_type,SerialNo,oduserno,DOP,DOI,work_status,remarkcode,st_feedback,eta,rechaeck_date,rescheduledate,st_icr_no,st_icr_date,eflag,ecode,"","",eqty,"PCS","",CustomerCode,residen,nomen,zz_fl,zz_flbrand,zz_mt5fl,zz_tl,zz_tlbrand,zz_mt5tl,zz_mw,zz_mwbrand,zz_mt5mw,zz_dw,zz_dwbrand,zz_mt5dw,zz_cd,zz_cdbrand,zz_mt5cd,zz_ac,zz_acbrand,zz_mt5ac,zz_bih,zz_bihbrand,zz_mt5bih,zz_bio,zz_biobrand,zz_mt5bio,"",st_feedback);


                            //  data.add(new String[]{PartnerId,TicketNo,Franchise,proces_type,SerialNo,oduserno,DOP,DOI,work_status,remarkcode,st_feedback,eta,rechaeck_date,rescheduledate,st_icr_no,st_icr_date,eflag,ecode,"","",eqty,"PCS","",CustomerCode,residen,nomen,zz_fl,zz_flbrand,zz_mt5fl,zz_tl,zz_tlbrand,zz_mt5tl,zz_mw,zz_mwbrand,zz_mt5mw,zz_dw,zz_dwbrand,zz_mt5dw,zz_cd,zz_cdbrand,zz_mt5cd,zz_ac,zz_acbrand,zz_mt5ac,zz_bih,zz_bihbrand,zz_mt5bih,zz_bio,zz_biobrand,zz_mt5bio,""});
                        }

                    }

                }
            }

        } catch (Exception e) {
            e.printStackTrace();

        }
    }

    // -------------------------- creating final json array one by one -----------------------------

    public void createjson(String TechnicianCode,String TicketNo,String franchise_bp,String CallType,String serial_no,String odu_serial_no,String DOP,String DOY,String Status,String status_reason,String notes,String eta,String rechecked_date,String rescheduled_date,String ICR_no,String ICR_Date,String spare_flag,String product_code,String spare_serno,String pending_flag,String quantity,String unit,String itemno,String zz_bp,String zz_residence,String zz_members,String zz_fl,String zz_flbrand,String zz_mt5fl,String zz_tl,String zz_tlbrand,String zz_mt5tl,String zz_mw,String zz_mwbrand,String zz_mt5mw,String zz_dw,String zz_dwbrand,String zz_mt5dw,String zz_cd,String zz_cdbrand,String zz_mt5cd,String zz_ac,String zz_acbrand,String zz_mt5ac,String zz_bih,String zz_bihbrand,String zz_mt5bih,String zz_bio,String zz_biobrand,String zz_mt5bio,String status_flag,String remarks){

        try{

            JSONObject jsonObject=new JSONObject();

            if (finaljsonArray.length()==0 && Status.equals("E0008")){

                status_flag="H";
            }
            else{
                status_flag="";
            }

            // TechnicianCode,orderid,franchise_bp,CallType,serial_no,
            jsonObject.put("TechnicianCode",TechnicianCode);
            jsonObject.put("TicketNo",TicketNo);
            jsonObject.put("franchise_bp",franchise_bp);
            jsonObject.put("CallType",CallType);
            jsonObject.put("serial_no",serial_no);

            // odu_serial_no,DOP,DOI,Status,status_reason,
            jsonObject.put("odu_serial_no",odu_serial_no);
            jsonObject.put("DOP",DOP);
            jsonObject.put("DOI",DOI);
            jsonObject.put("Status",Status);
            jsonObject.put("status_reason",status_reason);

            // notes,eta,rechecked_date,rescheduled_date,

            jsonObject.put("notes",notes);
            jsonObject.put("eta",eta);
            jsonObject.put("rechecked_date",rechecked_date);
            jsonObject.put("rescheduled_date",rescheduled_date);

            // ICR_no,ICR_Date,spare_flag,product_code,

            jsonObject.put("ICR_no",ICR_no);
            jsonObject.put("ICR_Date",ICR_Date);
            jsonObject.put("spare_flag",spare_flag);
            jsonObject.put("product_code",product_code);

            // spare_serno,pending_flag,quantity,unit,itemno,

            jsonObject.put("spare_serno",spare_serno);
            jsonObject.put("pending_flag",pending_flag);
            jsonObject.put("quantity",quantity);
            jsonObject.put("unit",unit);
            jsonObject.put("itemno",itemno);

            // zz_bp,zz_residence,zz_members,zz_fl,zz_flbrand,
            jsonObject.put("zz_bp",zz_bp);
            jsonObject.put("zz_residence",zz_residence);
            jsonObject.put("zz_members",zz_members);
            jsonObject.put("zz_fl",zz_fl);
            jsonObject.put("zz_flbrand",zz_flbrand);

            // zz_mt5fl,zz_tl,zz_tlbrand,
            jsonObject.put("zz_mt5fl",zz_mt5fl);
            jsonObject.put("zz_tl",zz_tl);
            jsonObject.put("zz_tlbrand",zz_tlbrand);

            // zz_mt5tl,zz_mw,zz_mwbrand,zz_mt5mw,zz_dw,

            jsonObject.put("zz_mt5tl",zz_mt5tl);
            jsonObject.put("zz_mw",zz_mw);
            jsonObject.put("zz_mwbrand",zz_mwbrand);
            jsonObject.put("zz_mt5mw",zz_mt5mw);
            jsonObject.put("zz_dw",zz_dw);

            // zz_dwbrand,zz_mt5dw,zz_cd,zz_cdbrand,zz_mt5cd,
            jsonObject.put("zz_dwbrand",zz_dwbrand);
            jsonObject.put("zz_mt5dw",zz_mt5dw);
            jsonObject.put("zz_cd",zz_cd);
            jsonObject.put("zz_cdbrand",zz_cdbrand);
            jsonObject.put("zz_mt5cd",zz_mt5cd);

            // zz_ac,zz_acbrand,zz_mt5ac,zz_bih,zz_bihbrand,

            jsonObject.put("zz_ac",zz_ac);
            jsonObject.put("zz_acbrand",zz_acbrand);
            jsonObject.put("zz_mt5ac",zz_mt5ac);
            jsonObject.put("zz_bih",zz_bih);
            jsonObject.put("zz_bihbrand",zz_bihbrand);

            // zz_mt5bih,zz_bio,zz_biobrand,zz_mt5bio,status_flag,remarks

            jsonObject.put("zz_mt5bih",zz_mt5bih);
            jsonObject.put("zz_bio",zz_bio);
            jsonObject.put("zz_biobrand",zz_biobrand);
            jsonObject.put("zz_mt5bio",zz_mt5bio);
            jsonObject.put("status_flag",status_flag);
            jsonObject.put("remarks","");
            jsonObject.put("recheck_rsn","");

            finaljsonArray.put(jsonObject);

            System.out.println(finaljsonArray.toString());

            System.out.println(totallinecount +" and "+finaljsonArray.length() );


         // inactive submit button
            btn_status.setClickable(false);

            // submit data into server
            if (totallinecount==finaljsonArray.length()){

                if (CheckConnectivity.getInstance(this).isOnline()) {
                    // submit data into server
                    submitfinaldata(finaljsonArray);
                   //   dbhelper.insert_read_data(TicketNo,tss,ChangeDate,Status,spnr_status);
                }
                else {
                    dataforoffline();
             }
            }
            else if(totallinecount ==0){

                if (CheckConnectivity.getInstance(this).isOnline()) {
                    submitfinaldata(finaljsonArray);
                 //   dbhelper.insert_read_data(TicketNo,tss,ChangeDate,Status,spnr_status);
                }
                else {
                    dataforoffline();
                }

            }
        }catch (Exception e){

            e.printStackTrace();
        }
    }

    // ------------------ Insert no imagge value into all image data ---------------------------

    public class Compressimage extends AsyncTask<Void, Void, Void> {
        protected Void doInBackground(Void... params) {
            try {

                Thread.sleep(3000);
                imagebitmap = BitmapFactory.decodeResource(getResources(), R.drawable.noimage);
                ByteArrayOutputStream byteArrayOutputStreams = new ByteArrayOutputStream();
                imagebitmap .compress(Bitmap.CompressFormat.PNG, 80, byteArrayOutputStreams);

                invoice_image_data= byteArrayOutputStreams.toByteArray();
                seraialno_image_data=byteArrayOutputStreams.toByteArray();
                oduserialno_image_data=byteArrayOutputStreams.toByteArray();
                customersign_data=byteArrayOutputStreams.toByteArray();

            } catch (Exception e) {

            }
            return null;
        }
        protected void onPostExecute(Void v) {


        }
    }

    // ----------------------------- after scan serial no check serial no is valid or not ------------------

    @Override
    public void modelresult(String output) {

        System.out.println("model result-->"+output);

        boolean b=output.contains("Result=1");
        if (b){

        }else{
            Alert alert=new Alert();
            alert.showDialog(CustomerDetailsActivity.this,"Serial No Error","Serial No is not Valid.\n Essentials and Spares can't be added");
            ll_essential.setClickable(false);
            ll_spare.setClickable(false);
            ll_sales.setClickable(false);

            // As serial no not valid. \nEssential can't be added

        }
    }

    //  --------------------- Submit final data into server  -----------------------

    public void submitfinaldata(JSONArray jsonArray){

        String url=AllUrl.baseUrl+"ZTECHSO/AddNewZTechSO";

        System.out.println(url);

        RequestQueue requestQueue = Volley.newRequestQueue(this);

        final String requestBody = jsonArray.toString();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.i("VOLLEY", response);
                System.out.println(response);

                if (response.equals("200")){

                    // if data insert success then insert submit ticket detais
                    dbhelper.insert_read_data(TicketNo,tss,ChangeDate,Status,spnr_status);

                    closeticket("Data Saved SuccessFully");
                    errorDetails.Errorlog(CustomerDetailsActivity.this,"File%20Upload", TAG,"Data%20Upload%20done",response,mobile_no,TicketNo,"S",mobile_details,dbversion,tss);

                }
                else {
                    // if data insert success then insert submit ticket detais
                    dbhelper.insert_read_data(TicketNo,tss,ChangeDate,Status,spnr_status);
                    errorDetails.Errorlog(CustomerDetailsActivity.this,"File%20Upload", TAG,"Data%20upload%20error",response,mobile_no,TicketNo,"S",mobile_details,dbversion,tss);
                    // if data submit time error find save data for offline
                    dataforoffline();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dbhelper.insert_read_data(TicketNo,tss,ChangeDate,Status,spnr_status);
                errorDetails.Errorlog(CustomerDetailsActivity.this,"File%20Upload", TAG,"Data%20upload%20error","other%20errror",mobile_no,TicketNo,"S",mobile_details,dbversion,tss);
                // if data submit time error find save data for offline
                dataforoffline();

            }
        })
        {
            @Override
            public String getBodyContentType() {
                return "application/json; charset=utf-8";
            }

            @Override
            public byte[] getBody() throws AuthFailureError {
                try {
                    return requestBody == null ? null : requestBody.getBytes("utf-8");
                } catch (UnsupportedEncodingException uee) {
                    VolleyLog.wtf("Unsupported Encoding while trying to get the bytes of %s using %s", requestBody, "utf-8");
                    return null;
                }
            }

            @Override
            protected Response<String> parseNetworkResponse(NetworkResponse response) {
                String responseString = "";
                if (response != null) {
                    responseString = String.valueOf(response.statusCode);
                    // can get more details such as response.headers
                }
                return Response.success(responseString, HttpHeaderParser.parseCacheHeaders(response));
            }
        };

        requestQueue.add(stringRequest);

    }

     // ---------------------- for closing  animation --------------------------------------
    public void closeticket(String result){

        tv_error_message.setVisibility(View.VISIBLE);
        tv_error_message.setText(result);

        Animation animation;
        animation = AnimationUtils.loadAnimation(CustomerDetailsActivity.this, R.anim.slide_down);
        tv_error_message.startAnimation(animation);

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            public void run() {
                // yourMethod();
                tv_error_message.setAnimation(null);
                tv_error_message.setVisibility(View.GONE);
                startActivity(new Intent(CustomerDetailsActivity.this,MainActivity.class));
                finish();
            }
        }, 2000);   //5 seconds

    }

    // -------------------------- save oofline data into local db and submit the data ------------------
    public void dataforoffline(){

        boolean status=dbhelper.insert_offlineservice_data(TicketNo,Valuefilter.getdate(),finaljsonArray.toString(),ticketdetails);
        if (status){
            dbhelper.insert_read_data(TicketNo,tss,ChangeDate,Status,spnr_status);
            errorDetails.Errorlog(CustomerDetailsActivity.this,"File%20save", TAG,"Data%20save%20in%20localdb",""+status,mobile_no,TicketNo,"S",mobile_details,dbversion,tss);

            closeticket("Offline Data Saved Successfully");

        }
        else {
            errorDetails.Errorlog(CustomerDetailsActivity.this,"File%20save", TAG,"Data%20save%20in%20localdb","false",mobile_no,TicketNo,"S",mobile_details,dbversion,tss);

            tv_error_message.setVisibility(View.VISIBLE);

            tv_error_message.setText("Offline Data Not saved. Please Reclick On Submit Button");
            btn_status.setEnabled(true);

            Animation animation;
            animation = AnimationUtils.loadAnimation(CustomerDetailsActivity.this, R.anim.slide_down);
            tv_error_message.startAnimation(animation);

            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                public void run() {
                    // yourMethod();
                    tv_error_message.setAnimation(null);
                    tv_error_message.setVisibility(View.GONE);

                }
            }, 2000);
        }

    }

    //  --------------------------  for show any type of message ----------------------------
    public void showerror(String message){
        tv_error_message.setVisibility(View.VISIBLE);

        tv_error_message.setText(message);

        Animation animation;
        animation = AnimationUtils.loadAnimation(CustomerDetailsActivity.this, R.anim.slide_down);
        tv_error_message.startAnimation(animation);


        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            public void run() {
                // yourMethod();
                tv_error_message.setAnimation(null);
                tv_error_message.setVisibility(View.GONE);

            }
        }, 5000);   //5 seconds
    }


    //   -------------------------------  updateessential and add into local db --------------------------------
    public void updateessential(View view){

        errorDetails.Errorlog(CustomerDetailsActivity.this,"Click%20on%essential%20update", TAG,"click","click",mobile_no,TicketNo,"C",mobile_details,dbversion,tss);


        if (CheckConnectivity.getInstance(this).isOnline()) {

            progressBar.setVisibility(View.VISIBLE);
            RequestQueue queue = Volley.newRequestQueue(this);
            String url = AllUrl.baseUrl + "addacc?addacc.FrCode=" + FrCode;

            System.out.println("get all sales-->  " + url);
            StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            progressBar.setVisibility(View.GONE);

                            System.out.println("ess details-->" + response);
                            if (response == null){

                            }
                            else {

                                try {
                                    JSONArray jsonArray = new JSONArray(response);
                                    System.out.println(jsonArray.toString());

                                    dbhelper.deleteess();

                                    dbhelper.insert_ess_data("-- select essential --", "", "" , "0", "0", "", "");

                                    for (int i = 0; i < jsonArray.length(); i++) {

                                        JSONObject essobj = jsonArray.getJSONObject(i);

                                        if (Boolean.valueOf(dbhelper.insert_ess_data(essobj.getString("ComponentDescription"), essobj.getString("Component"), "Z" + essobj.getString("ItemType"), essobj.getString("accessories_stock"), essobj.getString("additives_stock"), essobj.getString("ShelfLife"), "")).booleanValue()) {

                                        }
                                    }
                                    getess();
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                    progressBar.setVisibility(View.GONE);
                    showerror("Please try again later ");
                }
            });
// Add the request to the RequestQueue.
            queue.add(stringRequest);

        } else {

          //  ll_nointernet.setVisibility(View.VISIBLE);
            showerror("Please check internet connection");
        }
    }


    // ------------------------ geting amc details if machine status in amc ---------------------------
    public void getamcdetails(String srno){

        if (CheckConnectivity.getInstance(this).isOnline()) {

            progressBar.setVisibility(View.VISIBLE);
            RequestQueue queue = Volley.newRequestQueue(this);
            // https://sapsecurity.ifbhub.com/api/AMC/getAmcDetailsBySerialNo?model.amc.Srno=012228130220008870

            String url = AllUrl.baseUrl + "AMC/getAmcDetailsBySerialNo?model.amc.Srno="+srno;

            System.out.println("get all sales-->  " + url);
            StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            progressBar.setVisibility(View.GONE);

                            System.out.println("ess details-->" + response);
                            if (response == null){

                            }
                            else {

                                try {

                                    JSONObject object=new JSONObject(response);

                                    String status=object.getString("Status");

                                    if (status.equals("true")) {

                                        String data = object.getString("Data");
                                        JSONArray array = new JSONArray(data);

                                        for (int i = 0; i < 1; i++) {

                                            JSONObject jsonObject = array.getJSONObject(i);

                                            String AMCType=jsonObject.getString("AMCType");
                                            String AMC_end_dat=jsonObject.getString("AMC_end_dat");
                                            String AMCNo=jsonObject.getString("AMCNo");

                                            tv_amcno.setText(AMCNo);
                                            tv_amcdate.setText(AMC_end_dat);
                                            tv_amcduration.setText(AMCType);

                                        }
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                    progressBar.setVisibility(View.GONE);
                }
            });
// Add the request to the RequestQueue.
            queue.add(stringRequest);

        } else {


        }
    }


    public void createbill(View view){



        Gson gson=new Gson();


        String sparedata=gson.toJson(models);
        String essentialdata=gson.toJson(essential_add_models);


        startActivity(new Intent(CustomerDetailsActivity.this, CreateBill.class)
        .putExtra("spare",sparedata)
        .putExtra("essential",essentialdata));

    }
}