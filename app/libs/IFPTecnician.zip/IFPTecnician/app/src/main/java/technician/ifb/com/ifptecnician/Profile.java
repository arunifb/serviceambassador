package technician.ifb.com.ifptecnician;

import android.app.Activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;

import android.os.Handler;
import android.provider.MediaStore;
import android.support.design.widget.BottomSheetBehavior;
import android.support.design.widget.BottomSheetDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.mikhaellopez.circularimageview.CircularImageView;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import technician.ifb.com.ifptecnician.allurl.AllUrl;
import technician.ifb.com.ifptecnician.internet.CheckConnectivity;
import technician.ifb.com.ifptecnician.session.SessionManager;

public class Profile extends AppCompatActivity implements View.OnClickListener{

    LinearLayout ll_changepassword;
    SessionManager sessionManager;
    String name,email,mobile,FrCode;
    TextView tv_mobileno,tv_name,tv_email;
    CircularImageView civ_pimage;
    private BottomSheetBehavior sheetBehavior;
    LinearLayout bottom_sheet;
    public static final int PROFILE_IMAGE_CAPTURE = 21;
    public static final int PROFILE_IMAGE_GALLERY= 22;
    LinearLayout ll_open_camera,ll_open_gallery,ll_main_photo;
    TextView tv_photo_cancel;
    BottomSheetDialog dialoggg;

    int serverResponseCode = 0;

    /**********  File Path *************/
    final String uploadFilePath="" ;
    final String uploadFileName ="";

    private String upload_URL=AllUrl.baseUrl+"ProfileImageUpload/ImageUpload";
    String PartnerId, EmailId, Name, passsword, mobileno,subscriptionIds,imageurl="";
    //"https://crmapi.ifbhub.com/api/doc/uploaddoc?model.AppDocUpload.TicketNo="+TicketNo+"&model.AppDocUpload.SerialPhoto="+ seraialno_image_data+"&model.AppDocUpload.ODUSerialPhoto="+oduserialno_image_data+"&model.AppDocUpload.InvoicePhto="+invoice_image_data+"&model.AppDocUpload.UploadDate="+tss+"";
    private RequestQueue rQueue;
    private ArrayList<HashMap<String, String>> arraylist;
    ProgressBar progressbar;
    TextView  tv_error;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


        tv_error=findViewById(R.id.tv_error_message);

        ll_changepassword=findViewById(R.id.ll_changepassword);
        ll_changepassword.setOnClickListener(this);

        progressbar=findViewById(R.id.taskProcessing);

        sessionManager=new SessionManager(getApplicationContext());

        HashMap<String, String> user = sessionManager.getUserDetails();
        name=user.get(SessionManager.KEY_Name);
        email=user.get(SessionManager.KEY_EmailId);
        mobile=user.get(SessionManager.KEY_mobileno);
        FrCode=user.get(SessionManager.KEY_FrCode);
        passsword=user.get(SessionManager.KEY_passsword);
        imageurl=user.get(SessionManager.KEY_PROFILE_URL);
        PartnerId=user.get(SessionManager.KEY_PartnerId);

        System.out.println(name +"  "+email);

        civ_pimage=findViewById(R.id.civ_pimage);
        civ_pimage.setOnClickListener(this);

        try {

            if (imageurl.equals("")){

            }
            else{

                       Picasso.get()
                        .load(imageurl)
//                            .placeholder(R.drawable.user_placeholder)
//                            .error(R.drawable.user_placeholder_error)
                        .into(civ_pimage);
            }

        }
        catch (Exception e){


            e.printStackTrace();
        }



        tv_mobileno=findViewById(R.id.tv_mobileno);
        tv_name=findViewById(R.id.tv_name);
        tv_email=findViewById(R.id.tv_email);
        tv_mobileno.setText(mobile);
        tv_name.setText(name);
        tv_email.setText(email);

        dialoggg = new BottomSheetDialog(this);

    }

    @Override
    public void onClick(View v) {

        switch (v.getId()){

            case R.id.ll_changepassword:
                startActivity(new Intent(Profile.this,ChangePassword.class));
                break;

            case R.id.civ_pimage:

                showBottomSheetDialog();
             //   pickFromGallery();
                break;

            case  R.id.ll_open_camera:
                launchCameraIntent();
                dialoggg.dismiss();

                break;
            case  R.id.ll_open_gallery:
                pickFromGallery();
                dialoggg.dismiss();

                break;
            case R.id.tv_photo_cancel:
               // ll_main_photo.setVisibility(View.GONE);
                dialoggg.dismiss();
                break;


        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    private void launchCameraIntent() {
        Intent intent = new Intent(Profile.this, ImagePickerActivity.class);
        intent.putExtra(ImagePickerActivity.INTENT_IMAGE_PICKER_OPTION, ImagePickerActivity.REQUEST_IMAGE_CAPTURE);

        // setting aspect ratio
        intent.putExtra(ImagePickerActivity.INTENT_LOCK_ASPECT_RATIO, true);
        intent.putExtra(ImagePickerActivity.INTENT_ASPECT_RATIO_X, 1); // 16x9, 1x1, 3:4, 3:2
        intent.putExtra(ImagePickerActivity.INTENT_ASPECT_RATIO_Y, 1);

        // setting maximum bitmap width and height
        intent.putExtra(ImagePickerActivity.INTENT_SET_BITMAP_MAX_WIDTH_HEIGHT, true);
        intent.putExtra(ImagePickerActivity.INTENT_BITMAP_MAX_WIDTH, 500);
        intent.putExtra(ImagePickerActivity.INTENT_BITMAP_MAX_HEIGHT, 500);
        startActivityForResult(intent, PROFILE_IMAGE_CAPTURE);

    }


    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {

            case PROFILE_IMAGE_CAPTURE:
                if (resultCode == Activity.RESULT_OK) {
                    Uri uri = data.getParcelableExtra("path");
                    try {

                        Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), uri);
                        // Bitmap converetdImage = getResizedBitmap(bitmap, 80);
                        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                        bitmap.compress(Bitmap.CompressFormat.PNG, 80, byteArrayOutputStream);
                        byte [] profile_image_data= byteArrayOutputStream.toByteArray();
                        civ_pimage.setImageBitmap(bitmap);


                        if (CheckConnectivity.getInstance(Profile.this).isOnline()) {

                            uploadImage(bitmap);
                        }
                        else {
                            showpop("No internet connection!!");

                        }



                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

                break;

            case PROFILE_IMAGE_GALLERY:
                if (resultCode == Activity.RESULT_OK) {
                    Uri uri = data.getParcelableExtra("path");
                    try {


                        System.out.println("uri-->"+uri);
                       // upload(uri);

                        Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), uri);
                        // Bitmap converetdImage = getResizedBitmap(bitmap, 80);
                        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                        bitmap.compress(Bitmap.CompressFormat.PNG, 80, byteArrayOutputStream);
                        byte [] profile_image_data= byteArrayOutputStream.toByteArray();
                        civ_pimage.setImageBitmap(bitmap);

                        uploadImage(bitmap);


                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

                break;
        }
    }

    private void pickFromGallery() {

        Intent intent = new Intent(Profile.this, ImagePickerActivity.class);
        intent.putExtra(ImagePickerActivity.INTENT_IMAGE_PICKER_OPTION,1);

        // setting aspect ratio
        intent.putExtra(ImagePickerActivity.INTENT_LOCK_ASPECT_RATIO, true);
        intent.putExtra(ImagePickerActivity.INTENT_ASPECT_RATIO_X, 1); // 16x9, 1x1, 3:4, 3:2
        intent.putExtra(ImagePickerActivity.INTENT_ASPECT_RATIO_Y, 1);

        // setting maximum bitmap width and height
        intent.putExtra(ImagePickerActivity.INTENT_SET_BITMAP_MAX_WIDTH_HEIGHT, true);
        intent.putExtra(ImagePickerActivity.INTENT_BITMAP_MAX_WIDTH, 500);
        intent.putExtra(ImagePickerActivity.INTENT_BITMAP_MAX_HEIGHT, 500);
        startActivityForResult(intent, PROFILE_IMAGE_GALLERY);
    }


    public void showBottomSheetDialog() {
        View view = getLayoutInflater().inflate(R.layout.photo_popup, null);

        dialoggg.setContentView(view);
        ll_open_camera=dialoggg.findViewById(R.id.ll_open_camera);
        ll_open_camera.setOnClickListener(this);
        ll_open_gallery=dialoggg.findViewById(R.id.ll_open_gallery);
        ll_open_gallery.setOnClickListener(this);
        ll_main_photo=dialoggg.findViewById(R.id.ll_main_photo);

        tv_photo_cancel=dialoggg.findViewById(R.id.tv_photo_cancel);
        tv_photo_cancel.setOnClickListener(this);

        dialoggg.show();
    }


    private void uploadImage(final Bitmap bitmap){

        progressbar.setVisibility(View.VISIBLE);
        VolleyMultipartRequest volleyMultipartRequest = new VolleyMultipartRequest(Request.Method.POST, upload_URL,
                new Response.Listener<NetworkResponse>() {
                    @Override
                    public void onResponse(NetworkResponse response) {

                        System.out.println(response);
                        Log.d("ressssssoo",new String(response.data));
                        rQueue.getCache().clear();

                        System.out.println(response.statusCode);
                        progressbar.setVisibility(View.GONE);

                        if (response.statusCode==200){

                            showpop("Profile picture upload successfully done ");
                            UserLogin();
                        }
                        else {

                            showpop("Please try again later");
                         //   Toast.makeText(Profile.this, "Please Try Again ...", Toast.LENGTH_SHORT).show();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        progressbar.setVisibility(View.GONE);
                    }
                }) {


            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("PartnerId", PartnerId); // add string parameters
                params.put("ClientDocs", "ClientDocs");
                System.out.println(params);
                return params;
            }

            @Override
            protected Map<String, DataPart> getByteData() {
                Map<String, DataPart> params = new HashMap<>();
                long imagename = System.currentTimeMillis();
                params.put("test", new DataPart(imagename + ".jpeg", getFileDataFromDrawable(bitmap)));
                System.out.println(params);

                return params;
            }
        };


        volleyMultipartRequest.setRetryPolicy(new DefaultRetryPolicy(
                0,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        rQueue = Volley.newRequestQueue(Profile.this);
        rQueue.add(volleyMultipartRequest);
    }

    public byte[] getFileDataFromDrawable(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 80, byteArrayOutputStream);
        return byteArrayOutputStream.toByteArray();
    }

    public void UserLogin() {


        if (CheckConnectivity.getInstance(this).isOnline()) {

            progressbar.setVisibility(View.VISIBLE);
            RequestQueue queue = Volley.newRequestQueue(this);
            //String url = AllUrl.loginUrl+"?url=http://centurionbattery.in/development&username="+username+"&password="+password;
            String url = AllUrl.baseUrl+"user/validateuser?mobileno=" + mobile + "&password=" + passsword;

            System.out.println("get all sales-->  " + url);
            StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            progressbar.setVisibility(View.GONE);

                                try {

                                    JSONArray jsonArray = new JSONArray(response);


                                    System.out.println(response);

                                    //  if (object.get(get"Message"))
                                    for (int i = 0; i < jsonArray.length(); i++) {

                                        JSONObject obj = jsonArray.getJSONObject(i);

                                        PartnerId = obj.getString("PartnerId");
                                        if (PartnerId.equals("")) {

                                            } else {
                                            FrCode = obj.getString("FrCode");
                                            EmailId = obj.getString("EmailId");
                                            Name = obj.getString("Name");
                                            passsword = obj.getString("Password");
                                            mobileno = obj.getString("Mobileno");
                                            String url=obj.getString("URL");
                                            sessionManager.createLoginSession(PartnerId, FrCode, EmailId, Name, passsword, mobileno,url);

                                        }

                                    }

                                } catch (Exception e) {
                                    e.printStackTrace();

                                }
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                    progressbar.setVisibility(View.GONE);

                }
            });

            queue.add(stringRequest);

        } else {


        }
    }



    public void showpop(String text){

        tv_error.setText(text);
        tv_error.setVisibility(View.VISIBLE);
        Animation animation;
        animation = AnimationUtils.loadAnimation(Profile.this, R.anim.slide_down);
        tv_error.startAnimation(animation);

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            public void run() {
                tv_error.setAnimation(null);
                tv_error.setVisibility(View.GONE);
            }
        }, 5000);
    }

}


