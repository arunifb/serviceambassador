package technician.ifb.com.ifptecnician.utility;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class DateTimeFilter {


    public static String check_notification(String AssignDate){
        String status="";
        System.out.println(AssignDate);
        AssignDate="02/04/2020 12:46:09 PM";

        try {

            Calendar now = Calendar.getInstance();
            now.add(Calendar.MINUTE, -30);
            Date x = now.getTime();

            SimpleDateFormat formats=new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a",Locale.ENGLISH);
            Date dts=formats.parse(AssignDate);

//            DateFormat cdf=new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
//             String currentdate=cdf.format(now.getTime());
//             Calendar calendar=Calendar.getInstance();
//             calendar.setTime(cdf.parse(AssignDate));
//             String assdate=cdf.format(calendar.getTime());


            System.out.println(x +" "+dts);


            if (x.before(dts)) {
                status="true";
            }
            else {
                status="false";
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return status;
    }
}
