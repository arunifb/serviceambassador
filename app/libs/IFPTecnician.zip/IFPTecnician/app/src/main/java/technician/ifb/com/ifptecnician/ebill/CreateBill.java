package technician.ifb.com.ifptecnician.ebill;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.widget.TextView;

import com.google.gson.JsonArray;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

import technician.ifb.com.ifptecnician.MyDividerItemDecoration;
import technician.ifb.com.ifptecnician.R;
import technician.ifb.com.ifptecnician.model.Add_item_model;
import technician.ifb.com.ifptecnician.model.Essential_add_model;
import technician.ifb.com.ifptecnician.stock.StockAdapter;

public class CreateBill extends AppCompatActivity implements EbillAdapter.TotalAdapterListener{
    
    String sparedata,essentialdata;
    EbillModel ebillModel;
    ArrayList<EbillModel> ebillModels=new ArrayList<>();
    EbillAdapter ebillAdapter;
    RecyclerView rv_bill;
    TextView tv_totalbill;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_bill);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Create Bill");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        tv_totalbill=findViewById(R.id.tv_totalbill);

        rv_bill=findViewById(R.id.rv_bill);
        Intent in = getIntent();


        sparedata=in.getStringExtra("spare");
        essentialdata=in.getStringExtra("essential");
        System.out.println("spare data -->"+sparedata);
        System.out.println("Essntial data -->"+essentialdata);

        try{


            ebillModel=new EbillModel();
            ebillModel.setAmount("0");
            ebillModel.setCode("");
            ebillModel.setName("Service charge");
            ebillModel.setQty("1");
            ebillModels.add(ebillModel);


            ebillModel=new EbillModel();
            ebillModel.setAmount("0");
            ebillModel.setCode("");
            ebillModel.setName("Amc charge");
            ebillModel.setQty("1");
            ebillModels.add(ebillModel);

            if (sparedata.length()!=0){

                JSONArray jsonArray=new JSONArray(sparedata);

                for (int i=0;i<jsonArray.length();i++){

                    ebillModel=new EbillModel();
                    JSONObject jsonObject=jsonArray.getJSONObject(i);

                    ebillModel.setAmount("0");
                    ebillModel.setName(jsonObject.getString("itemname"));
                    ebillModel.setCode(jsonObject.getString("description"));
                    ebillModel.setQty(jsonObject.getString("count"));

                    ebillModels.add(ebillModel);
                }

            }


            if (essentialdata.length()!=0){

                JSONArray jsonArrays=new JSONArray(essentialdata);


                for (int j=0;j<jsonArrays.length();j++){

                    ebillModel=new EbillModel();
                    JSONObject jsonObject=jsonArrays.getJSONObject(j);

                    ebillModel.setAmount("0");
                    ebillModel.setName(jsonObject.getString("ename"));
                    ebillModel.setCode(jsonObject.getString("ecode"));
                    ebillModel.setQty(jsonObject.getString("equentity"));

                    ebillModels.add(ebillModel);
                }



                ebillAdapter=new EbillAdapter(this, ebillModels,this);
                rv_bill.setLayoutManager(new LinearLayoutManager(this));

                RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
                rv_bill.setLayoutManager(mLayoutManager);
                rv_bill.setItemAnimator(new DefaultItemAnimator());
                rv_bill.addItemDecoration(new MyDividerItemDecoration(this, DividerItemDecoration.VERTICAL, 0));
                rv_bill.setAdapter(ebillAdapter);
            }

        }catch (Exception e){

            e.printStackTrace();
        }

    }

    @Override
    public void onContactSelected(EbillModel ebillModel) {

        double sum = 0;
        for(int i = 0; i <ebillModels.size(); i++) {
            String price = ebillModels.get(i).getAmount();
            sum += Double.parseDouble(price);
            System.out.println("Sum-->"+sum);
            tv_totalbill.setText("\u20B9 "+sum);
        }

    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}