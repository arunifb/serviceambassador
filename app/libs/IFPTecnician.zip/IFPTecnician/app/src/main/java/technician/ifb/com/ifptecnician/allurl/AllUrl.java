package technician.ifb.com.ifptecnician.allurl;

import android.Manifest;
import android.content.pm.PackageManager;
import android.support.v4.content.ContextCompat;
import android.telephony.TelephonyManager;
import android.widget.Toast;

public class AllUrl {


    public static final String IS_USER_LOGIN = "IsUserLoggedIn";
    public static String KEY_PASSWORD = null;
    public static String USER_NAME="USER_NAME";
    public static String baseUrl;
    public static String loginUrl;
    public static String MOBILE_DETAILS;
//    public static String APP_VERSION="";
//    public static String APP_SERVER_VERTION="";
//
//
//    public static void setAppVersion(String appVersion) {
//        APP_VERSION = appVersion;
//    }
//
//    public static void setAppServerVertion(String appServerVertion) {
//        APP_SERVER_VERTION = appServerVertion;
//    }

    static {
      //  baseUrl="https://crmapi.ifbhub.com/api/";
        baseUrl="https://sapsecurity.ifbhub.com/api/";
        loginUrl = baseUrl +"validateUser";
        USER_NAME = "user_name";
        KEY_PASSWORD = "password";
        MOBILE_DETAILS ="mobile_details";
//        APP_VERSION="v2.3.1";
//        APP_SERVER_VERTION="2.3.1";
    }
}
