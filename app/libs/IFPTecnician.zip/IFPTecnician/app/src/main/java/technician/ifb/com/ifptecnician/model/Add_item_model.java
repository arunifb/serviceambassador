package technician.ifb.com.ifptecnician.model;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Add_item_model implements Serializable {

    String itemname,description,count,flag,Check,eta;



//              "PartName": "EVALENA CONTROLLER EVA AQUA SX - 6008",
//              "PartCode": "UF221ECPCB020",
//              "Qty": "1",
//              "itemno": "0000000020",
//              "spare_serno": null,
//              "pending_fla": ""

    int stockqty;

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public String getItemname() {
        return itemname;
    }

    public void setItemname(String itemname) {
        this.itemname = itemname;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }

    public String getCheck() {
        return Check;
    }

    public void setCheck(String check) {
        Check = check;
    }

    public int getStockqty() {
        return stockqty;
    }

    public void setStockqty(int stockqty) {
        this.stockqty = stockqty;
    }

    public String getEta() {
        return eta;
    }

    public void setEta(String eta) {
        this.eta = eta;
    }
}
