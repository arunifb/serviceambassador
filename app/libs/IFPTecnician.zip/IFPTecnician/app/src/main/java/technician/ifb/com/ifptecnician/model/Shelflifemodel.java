package technician.ifb.com.ifptecnician.model;

public class Shelflifemodel {

    String name,qty,consume,shelflife,esscode;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getQty() {
        return qty;
    }

    public void setQty(String qty) {
        this.qty = qty;
    }

    public String getConsume() {
        return consume;
    }

    public void setConsume(String consume) {
        this.consume = consume;
    }

    public String getShelflife() {
        return shelflife;
    }

    public void setShelflife(String shelflife) {
        this.shelflife = shelflife;
    }

    public String getEsscode() {
        return esscode;
    }

    public void setEsscode(String esscode) {
        this.esscode = esscode;
    }
}
