package technician.ifb.com.ifptecnician.ebill;

public class EbillModel {

    String name,amount,code,qty;

    public String getName() {
        return name;
    }

    public String getAmount() {
        return amount;
    }

    public String getCode() {
        return code;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getQty() {
        return qty;
    }

    public void setQty(String qty) {
        this.qty = qty;
    }
}
