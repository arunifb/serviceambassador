package technician.ifb.com.ifptecnician.model;

public class Add_Product_Model {

    String product,machine,year;

    public void setProduct(String product) {
        this.product = product;
    }

    public void setMachine(String machine) {
        this.machine = machine;
    }

    public void setYear(String year) {
        this.year = year;
    }


    public String getProduct() {
        return product;
    }

    public String getMachine() {
        return machine;
    }

    public String getYear() {
        return year;
    }
}
