package technician.ifb.com.ifptecnician.alert;

public class SmsAlertDialog {


}
