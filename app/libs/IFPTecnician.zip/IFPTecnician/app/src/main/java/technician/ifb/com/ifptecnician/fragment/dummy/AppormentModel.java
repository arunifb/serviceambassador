package technician.ifb.com.ifptecnician.fragment.dummy;

public class AppormentModel {


    String TicketNo,Branch,Franchise,CallType,Status,
            Product,Model,serial_no,MachinStatus,DOP,DOI,PendingReason,CallBookDate,AssignDate,ClosedDate, CancelledDate ,
            TechnicianCode,TechName,CustomerCode,CustomerName,PinCode,TelePhone,RCNNo,MobileNo,
            Street,City,State,Address,NO126,ServiceType,Email,Priority,Ageing,odu_ser_no,FGCode,ProblemDescription,ChangeDate;

    public String getTicketNo() {
        return TicketNo;
    }

    public String getBranch() {
        return Branch;
    }

    public String getFranchise() {
        return Franchise;
    }

    public String getCallType() {
        return CallType;
    }

    public String getStatus() {
        return Status;
    }

    public String getProduct() {
        return Product;
    }

    public String getModel() {
        return Model;
    }

    public String getSerial_no() {
        return serial_no;
    }

    public String getMachinStatus() {
        return MachinStatus;
    }

    public String getDOP() {
        return DOP;
    }

    public String getDOI() {
        return DOI;
    }

    public String getPendingReason() {
        return PendingReason;
    }

    public String getCallBookDate() {
        return CallBookDate;
    }

    public String getAssignDate() {
        return AssignDate;
    }

    public String getClosedDate() {
        return ClosedDate;
    }

    public String getCancelledDate() {
        return CancelledDate;
    }

    public String getTechnicianCode() {
        return TechnicianCode;
    }

    public String getTechName() {
        return TechName;
    }

    public String getCustomerCode() {
        return CustomerCode;
    }

    public String getCustomerName() {
        return CustomerName;
    }

    public String getPinCode() {
        return PinCode;
    }

    public String getTelePhone() {
        return TelePhone;
    }

    public String getRCNNo() {
        return RCNNo;
    }

    public String getMobileNo() {
        return MobileNo;
    }

    public String getStreet() {
        return Street;
    }

    public String getCity() {
        return City;
    }

    public String getState() {
        return State;
    }

    public String getAddress() {
        return Address;
    }

    public String getNO126() {
        return NO126;
    }

    public String getServiceType() {
        return ServiceType;
    }

    public String getEmail() {
        return Email;
    }

    public String getPriority() {
        return Priority;
    }

    public String getAgeing() {
        return Ageing;
    }

    public String getOdu_ser_no() {
        return odu_ser_no;
    }

    public String getFGCode() {
        return FGCode;
    }

    public String getProblemDescription() {
        return ProblemDescription;
    }

    public String getChangeDate() {
        return ChangeDate;
    }
}
