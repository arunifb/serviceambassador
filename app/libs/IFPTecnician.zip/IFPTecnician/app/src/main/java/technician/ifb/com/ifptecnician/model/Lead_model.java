package technician.ifb.com.ifptecnician.model;

public class Lead_model {

    String LeadNo, TechCode, FrCode, StartDate, EndDate, LeadType, Customer, Address, Phone,
            Status, Product, Model, Quantity, EssName, EssCode, AccName, AccCode, SerialNo;

    public String getLeadNo() {
        return LeadNo;
    }

    public String getTechCode() {
        return TechCode;
    }

    public String getFrCode() {
        return FrCode;
    }

    public String getStartDate() {
        return StartDate;
    }

    public String getEndDate() {
        return EndDate;
    }

    public String getLeadType() {
        return LeadType;
    }

    public String getCustomer() {
        return Customer;
    }

    public String getAddress() {
        return Address;
    }

    public String getPhone() {
        return Phone;
    }

    public String getStatus() {
        return Status;
    }

    public String getProduct() {
        return Product;
    }

    public String getModel() {
        return Model;
    }

    public String getQuantity() {
        return Quantity;
    }

    public String getEssName() {
        return EssName;
    }

    public String getEssCode() {
        return EssCode;
    }

    public String getAccName() {
        return AccName;
    }

    public String getAccCode() {
        return AccCode;
    }

    public String getSerialNo() {
        return SerialNo;
    }
}
