package technician.ifb.com.ifptecnician.utility;

public class CallSmsApi {

   public static String Smsapi(String refno,String smstype,String mobile){

       String response="";


       return response;
   }

}
