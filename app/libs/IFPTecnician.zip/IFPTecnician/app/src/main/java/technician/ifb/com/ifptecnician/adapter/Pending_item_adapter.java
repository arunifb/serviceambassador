package technician.ifb.com.ifptecnician.adapter;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import technician.ifb.com.ifptecnician.CustomerDetailsActivity;
import technician.ifb.com.ifptecnician.R;
import technician.ifb.com.ifptecnician.fragment.dummy.SalesModel;
import technician.ifb.com.ifptecnician.model.Add_item_model;
import technician.ifb.com.ifptecnician.model.PendingSpare;
import technician.ifb.com.ifptecnician.offlinedata.Dbhelper;
import technician.ifb.com.ifptecnician.utility.NumberPickerDialog;

public class Pending_item_adapter extends BaseAdapter implements NumberPicker.OnValueChangeListener {

    private ArrayList<PendingSpare> dataSet;
    int[] numValues;
    Context mContext;
    LayoutInflater layoutInflater;
    private Add_item_adapter.ContactsFilter contactsFilter;
    List<Integer> hiddenItems = new ArrayList<>();
    String quentity="0";
    int pos;
    Dbhelper dbhelper;
    String partname;
    String pen;
    int sqty,current_qty;

    public Pending_item_adapter(ArrayList<PendingSpare> dataSet, Context context) {
        // super(context, R.layout.item_leads_list, data);
        this.dataSet = dataSet;
        this.mContext=context;
        dbhelper=new Dbhelper(context);
        layoutInflater=LayoutInflater.from(this.mContext);
    }

    @Override
    public int getCount() {
        return dataSet.size();
    }

    @Override
    public Object getItem(int position) {
        return dataSet.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position,View convertView, ViewGroup parent) {
        final ViewHolder holder;
        if(convertView==null)
        {
            convertView=layoutInflater.inflate(R.layout.item_add_view,parent,false);
            holder=new ViewHolder(convertView);
            convertView.setTag(holder);
        }
        else
        {
            holder=(ViewHolder)convertView.getTag();
        }

        final PendingSpare dataSets=dataSet.get(position);


        holder.tv_partname.setText(dataSets.getPartName());
        holder.tv_partcode.setText(dataSets.getPartCode());
        holder.tv_quentity.setText(dataSets.getQty());
        holder.tv_spare_not_found.setText(dataSets.getPending_fla());
//
//        holder.tv_spare_not_found.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                pos=position;
//                current_qty=Integer.valueOf(dataSets.getQty());
//                partname=dataSets.getPartName();
//                pen=dataSets.getPending_fla();
//                openpopup();
//
//            }
//        });

//        holder.tv_quentity.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                pen=dataSets.getPending_fla();
//                partname=dataSets.getPartName();
//                pos=position;
//                showNumberPicker(v);
//            }
//        });
        if (dataSets.getFlags().equals("D")){

            holder.added_spare_card.setBackgroundColor(Color.LTGRAY);
        }

        holder.btn_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hiddenItems.add(position);
                dataSets.setFlags("D");
                dataSets.setPending_fla("");
                holder.btn_delete.setVisibility(View.INVISIBLE);
                holder.tv_spare_not_found.setVisibility(View.INVISIBLE);
                holder.tv_quentity.setVisibility(View.INVISIBLE);
               // holder.ll_main.setVisibility(View.GONE);
                holder.added_spare_card.setCardBackgroundColor(Color.LTGRAY);
                notifyDataSetChanged();
            }
        });

        return convertView;
    }

    private static class ViewHolder {
        TextView tv_partname,tv_partcode,tv_quentity,tv_spare_not_found;
        Button btn_delete;
        LinearLayout ll_main;
        CardView added_spare_card;
        public ViewHolder(View view){

            // tv_materialcategory=(TextView)view.findViewById(R.id.tv_materialcategory);

            tv_partname=(TextView)view.findViewById(R.id.tv_part_name);
            tv_partcode=(TextView)view.findViewById(R.id.tv_part_code);
            tv_quentity=(TextView)view.findViewById(R.id.tv_par_quentity);
            btn_delete=(Button)view.findViewById(R.id.btn_delete);
            tv_spare_not_found=view.findViewById(R.id.tv_spare_not_found);
            added_spare_card=view.findViewById(R.id.added_spare_card);
            ll_main=view.findViewById(R.id.item_pending_spare_ll_main);
        }
    }

    @Override
    public void onValueChange(NumberPicker picker, int oldVal, int newVal) {


        Cursor bcursor;
        System.out.println("partname-->"+partname);

        try{

            bcursor=dbhelper.get_Single_Bom_Data(partname);

            if (bcursor != null) {

                if (bcursor.moveToFirst()) {

                    do {

                       final int recordid = bcursor.getInt(bcursor.getColumnIndex("recordid"));
                        //  System.out.println("recordid-->" + recordid);
                        String ComponentDescription = bcursor.getString(bcursor.getColumnIndex("ComponentDescription"));
                        String good_stock=bcursor.getString(bcursor.getColumnIndex("good_stock"));
                        String refurbished_stock=bcursor.getString(bcursor.getColumnIndex("refurbished_stock"));

                        int goodstock=string_to_int(good_stock);
                        int refurbishedstock=string_to_int(refurbished_stock);

                        if (goodstock < refurbishedstock){

//                            tv_bom_qty.setText(refurbished_stock);
                           sqty=refurbishedstock;

                           if (picker.getValue() <= sqty && pen.equals("No")){
                               quentity = String.valueOf(picker.getValue());
                               dataSet.get(pos).setQty(quentity);
                               dataSet.get(pos).setFlags("U");
                               notifyDataSetChanged();
                           }
                           else if (picker.getValue() > sqty && pen.equals("Yes")){

                               quentity = String.valueOf(picker.getValue());
                               dataSet.get(pos).setQty(quentity);
                               dataSet.get(pos).setFlags("U");
                               notifyDataSetChanged();
                           }
                           else if(picker.getValue() > sqty){

                               quentity = String.valueOf(picker.getValue());
                               dataSet.get(pos).setQty(quentity);
                               dataSet.get(pos).setFlags("U");
                               dataSet.get(pos).setPending_fla("Yes");
                               notifyDataSetChanged();

                                Toast.makeText(mContext, "Stock Quentity "+sqty, Toast.LENGTH_SHORT).show();
                           }

                           else if (picker.getValue() <= sqty){

                               quentity = String.valueOf(picker.getValue());
                               dataSet.get(pos).setQty(quentity);
                               dataSet.get(pos).setFlags("U");
                               dataSet.get(pos).setPending_fla("No");

                               notifyDataSetChanged();

                               Toast.makeText(mContext, "Stock Quentity "+sqty, Toast.LENGTH_SHORT).show();

                           }
                        }
                        else {
                               sqty=goodstock;

                            if (picker.getValue() <= sqty && pen.equals("No")){

                                quentity = String.valueOf(picker.getValue());
                                dataSet.get(pos).setQty(quentity);
                                dataSet.get(pos).setFlags("U");
                                notifyDataSetChanged();
                            }
                            else if (picker.getValue() > sqty && pen.equals("Yes")){

                                quentity = String.valueOf(picker.getValue());
                                dataSet.get(pos).setQty(quentity);
                                dataSet.get(pos).setFlags("U");
                                notifyDataSetChanged();
                            }

                            else if(picker.getValue() > sqty){

                                quentity = String.valueOf(picker.getValue());
                                dataSet.get(pos).setQty(quentity);
                                dataSet.get(pos).setFlags("U");
                                dataSet.get(pos).setPending_fla("Yes");
                                notifyDataSetChanged();

                                Toast.makeText(mContext, "Stock Quentity "+sqty, Toast.LENGTH_SHORT).show();
                            }

                            else if (picker.getValue() <= sqty){

                                quentity = String.valueOf(picker.getValue());
                                dataSet.get(pos).setQty(quentity);
                                dataSet.get(pos).setFlags("U");
                                dataSet.get(pos).setPending_fla("No");
                                notifyDataSetChanged();

                                Toast.makeText(mContext, "Stock Quentity "+sqty, Toast.LENGTH_SHORT).show();

                            }
                            else{
                                Toast.makeText(mContext, "Stock Quentity "+sqty, Toast.LENGTH_SHORT).show();
                            }
                        }

                    } while (bcursor.moveToNext());

                       bcursor.close();
                }
            }
            else {

                quentity = String.valueOf(picker.getValue());
                dataSet.get(pos).setQty(quentity);
                dataSet.get(pos).setFlags("U");
                notifyDataSetChanged();
            }


        }catch (Exception e){


            e.printStackTrace();
        }
    }

    public void showNumberPicker(View view) {
        NumberPickerDialog newFragment = new NumberPickerDialog();
        newFragment.setValueChangeListener(this);
        newFragment.show( ((AppCompatActivity)mContext).getSupportFragmentManager(), "time picker");
    }

    public void  openpopup(){

        final Dialog dialog = new Dialog(mContext);

        dialog.setContentView(R.layout.pending_spare_popup);

        Button save=dialog.findViewById(R.id.pop_btn_save);
        Button cancel=dialog.findViewById(R.id.pop_btn_close);
        TextView tv_yes=dialog.findViewById(R.id.pop_tv_yes);
        TextView tv_no=dialog.findViewById(R.id.pop_tv_no);

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                dialog.dismiss();
            }
        });

        tv_yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Cursor bcursorno;
                System.out.println("partname-->"+partname);

                try{

                    bcursorno=dbhelper.get_Single_Bom_Data(partname);

                    if (bcursorno != null) {

                        if (bcursorno.moveToFirst()) {

                            do {

                             String good_stock=bcursorno.getString(bcursorno.getColumnIndex("good_stock"));
                                String refurbished_stock=bcursorno.getString(bcursorno.getColumnIndex("refurbished_stock"));

                                int goodstock=string_to_int(good_stock);
                                int refurbishedstock=string_to_int(refurbished_stock);

                                if (goodstock < refurbishedstock){

//                            tv_bom_qty.setText(refurbished_stock);
                                    sqty=refurbishedstock;

                                    if (  sqty < current_qty ){

                                        dataSet.get(pos).setFlags("U");
                                        dataSet.get(pos).setPending_fla("Yes");
                                        notifyDataSetChanged();
                                        dialog.dismiss();
                                    }

                                    else {

                                        Toast.makeText(mContext, "Stock quantity "+sqty, Toast.LENGTH_SHORT).show();
                                    }

                                }
                                else {
                                    sqty=goodstock;

                                    if ( sqty < current_qty){

                                        dataSet.get(pos).setFlags("U");
                                        dataSet.get(pos).setPending_fla("Yes");
                                        notifyDataSetChanged();
                                        dialog.dismiss();
                                    }

                                    else
                                    {
                                        Toast.makeText(mContext, "Stock quantity "+sqty, Toast.LENGTH_SHORT).show();
                                    }

                                }

                            } while (bcursorno.moveToNext());

                            bcursorno.close();
                        }
                    }
                    else {

                        dataSet.get(pos).setFlags("U");
                        dataSet.get(pos).setPending_fla("Yes");
                        notifyDataSetChanged();
                        dialog.dismiss();
                    }


                }catch (Exception e){


                }


            }
        });

        tv_no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Cursor bcursors;
                System.out.println("partname-->"+partname);

                try{

                    bcursors=dbhelper.get_Single_Bom_Data(partname);

                    if (bcursors != null) {

                        if (bcursors.moveToFirst()) {

                            do {

                                String good_stock=bcursors.getString(bcursors.getColumnIndex("good_stock"));
                                String refurbished_stock=bcursors.getString(bcursors.getColumnIndex("refurbished_stock"));

                                int goodstock=string_to_int(good_stock);
                                int refurbishedstock=string_to_int(refurbished_stock);

                                if (goodstock < refurbishedstock){

//                            tv_bom_qty.setText(refurbished_stock);
                                    sqty=refurbishedstock;

                                    if (sqty==current_qty || current_qty<sqty ){

                                        dataSet.get(pos).setFlags("U");
                                        dataSet.get(pos).setPending_fla("No");
                                        notifyDataSetChanged();
                                        dialog.dismiss();
                                    }

                                    else {

                                        Toast.makeText(mContext, "Stock quantity "+sqty, Toast.LENGTH_SHORT).show();
                                    }

                                }
                                else {
                                    sqty=goodstock;

                                    if (sqty==current_qty || current_qty<sqty){

                                        dataSet.get(pos).setFlags("U");
                                        dataSet.get(pos).setPending_fla("No");
                                        notifyDataSetChanged();
                                        dialog.dismiss();
                                    }

                                    else
                                    {
                                        Toast.makeText(mContext, "Stock quantity "+sqty, Toast.LENGTH_SHORT).show();
                                    }

                                }

                            } while (bcursors.moveToNext());

                            bcursors.close();
                        }
                    }
                    else {

                        dataSet.get(pos).setFlags("U");
                        dataSet.get(pos).setPending_fla("No");
                        notifyDataSetChanged();
                        dialog.dismiss();
                    }


                }catch (Exception e){


                }



            }
        });

        dialog.show();

    }

    public int string_to_int(String Numbers){
        int no=0;
        no= Integer.parseInt(Numbers);

        return no;
    }

}


